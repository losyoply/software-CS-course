
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/ai/NavWanderAgent.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '5353eyD4YdHSLFpesp5kvKK', 'NavWanderAgent');
// scripts/ai/NavWanderAgent.ts

// Learn TypeScript:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/typescript.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/life-cycle-callbacks.html
Object.defineProperty(exports, "__esModule", { value: true });
var IInputControls_1 = require("../input/IInputControls");
var Agent_1 = require("./Agent");
var WaypointGraph_1 = require("./navigation/WaypointGraph");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
//*||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||*\\
// TODO (3.3): Complete NavWanderAgent's behaviour using NavWanderer.
// [SPECIFICATIONS]
// - Check out the other agents to figure out what's missing, and connect
//   everything together!
//*||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||*\\
var NavWanderAgent = /** @class */ (function (_super) {
    __extends(NavWanderAgent, _super);
    function NavWanderAgent() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.attack = IInputControls_1.ButtonState.Rest;
        _this.interact = IInputControls_1.ButtonState.Rest;
        _this.waypointGraph = null;
        return _this;
        // update (dt) {}
    }
    Object.defineProperty(NavWanderAgent.prototype, "horizontalAxis", {
        get: function () {
            //#region [YOUR IMPLEMENTATION HERE]
            return 0;
            //#endregion
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(NavWanderAgent.prototype, "verticalAxis", {
        get: function () {
            //#region [YOUR IMPLEMENTATION HERE]
            return 0;
            //#endregion
        },
        enumerable: false,
        configurable: true
    });
    //#region [YOUR IMPLEMENTATION HERE]
    //#endregion
    NavWanderAgent.prototype.agentUpdate = function (dt) {
        //#region [YOUR IMPLEMENTATION HERE]
        //#endregion
    };
    // LIFE-CYCLE CALLBACKS:
    NavWanderAgent.prototype.onLoad = function () {
        //#region [YOUR IMPLEMENTATION HERE]
        //#endregion
    };
    NavWanderAgent.prototype.start = function () {
        //#region [YOUR IMPLEMENTATION HERE]
        //#endregion
    };
    __decorate([
        property(WaypointGraph_1.default)
    ], NavWanderAgent.prototype, "waypointGraph", void 0);
    NavWanderAgent = __decorate([
        ccclass
    ], NavWanderAgent);
    return NavWanderAgent;
}(Agent_1.default));
exports.default = NavWanderAgent;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcYWlcXE5hdldhbmRlckFnZW50LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7OztBQUFBLG9CQUFvQjtBQUNwQixrRkFBa0Y7QUFDbEYseUZBQXlGO0FBQ3pGLG1CQUFtQjtBQUNuQiw0RkFBNEY7QUFDNUYsbUdBQW1HO0FBQ25HLDhCQUE4QjtBQUM5Qiw0RkFBNEY7QUFDNUYsbUdBQW1HOztBQUVuRywwREFBc0U7QUFDdEUsaUNBQTRCO0FBQzVCLDREQUF1RDtBQUdqRCxJQUFBLEtBQXNCLEVBQUUsQ0FBQyxVQUFVLEVBQWxDLE9BQU8sYUFBQSxFQUFFLFFBQVEsY0FBaUIsQ0FBQztBQUUxQyw0RUFBNEU7QUFDNUUscUVBQXFFO0FBQ3JFLG1CQUFtQjtBQUNuQix5RUFBeUU7QUFDekUseUJBQXlCO0FBQ3pCLDRFQUE0RTtBQUc1RTtJQUNZLGtDQUFLO0lBRGpCO1FBQUEscUVBMkNDO1FBN0JHLFlBQU0sR0FBZ0IsNEJBQVcsQ0FBQyxJQUFJLENBQUM7UUFDdkMsY0FBUSxHQUFnQiw0QkFBVyxDQUFDLElBQUksQ0FBQztRQUV6QyxtQkFBYSxHQUFrQixJQUFJLENBQUM7O1FBeUJwQyxpQkFBaUI7SUFDckIsQ0FBQztJQXZDRyxzQkFBVywwQ0FBYzthQUF6QjtZQUNJLG9DQUFvQztZQUNwQyxPQUFPLENBQUMsQ0FBQztZQUNULFlBQVk7UUFDaEIsQ0FBQzs7O09BQUE7SUFDRCxzQkFBVyx3Q0FBWTthQUF2QjtZQUNJLG9DQUFvQztZQUNwQyxPQUFPLENBQUMsQ0FBQztZQUNULFlBQVk7UUFDaEIsQ0FBQzs7O09BQUE7SUFNRCxvQ0FBb0M7SUFFcEMsWUFBWTtJQUNGLG9DQUFXLEdBQXJCLFVBQXNCLEVBQVU7UUFDNUIsb0NBQW9DO1FBRXBDLFlBQVk7SUFDaEIsQ0FBQztJQUVELHdCQUF3QjtJQUV4QiwrQkFBTSxHQUFOO1FBQ0ksb0NBQW9DO1FBRXBDLFlBQVk7SUFDaEIsQ0FBQztJQUVELDhCQUFLLEdBQUw7UUFDSSxvQ0FBb0M7UUFFcEMsWUFBWTtJQUNoQixDQUFDO0lBdkJEO1FBREMsUUFBUSxDQUFDLHVCQUFhLENBQUM7eURBQ1k7SUFqQm5CLGNBQWM7UUFEbEMsT0FBTztPQUNhLGNBQWMsQ0EyQ2xDO0lBQUQscUJBQUM7Q0EzQ0QsQUEyQ0MsQ0ExQ1csZUFBSyxHQTBDaEI7a0JBM0NvQixjQUFjIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy8gTGVhcm4gVHlwZVNjcmlwdDpcbi8vICAtIFtDaGluZXNlXSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL3poL3NjcmlwdGluZy90eXBlc2NyaXB0Lmh0bWxcbi8vICAtIFtFbmdsaXNoXSBodHRwOi8vd3d3LmNvY29zMmQteC5vcmcvZG9jcy9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvdHlwZXNjcmlwdC5odG1sXG4vLyBMZWFybiBBdHRyaWJ1dGU6XG4vLyAgLSBbQ2hpbmVzZV0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC96aC9zY3JpcHRpbmcvcmVmZXJlbmNlL2F0dHJpYnV0ZXMuaHRtbFxuLy8gIC0gW0VuZ2xpc2hdIGh0dHA6Ly93d3cuY29jb3MyZC14Lm9yZy9kb2NzL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9yZWZlcmVuY2UvYXR0cmlidXRlcy5odG1sXG4vLyBMZWFybiBsaWZlLWN5Y2xlIGNhbGxiYWNrczpcbi8vICAtIFtDaGluZXNlXSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL3poL3NjcmlwdGluZy9saWZlLWN5Y2xlLWNhbGxiYWNrcy5odG1sXG4vLyAgLSBbRW5nbGlzaF0gaHR0cDovL3d3dy5jb2NvczJkLXgub3JnL2RvY3MvY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcblxuaW1wb3J0IHsgQnV0dG9uU3RhdGUsIElJbnB1dENvbnRyb2xzIH0gZnJvbSBcIi4uL2lucHV0L0lJbnB1dENvbnRyb2xzXCI7XG5pbXBvcnQgQWdlbnQgZnJvbSBcIi4vQWdlbnRcIjtcbmltcG9ydCBXYXlwb2ludEdyYXBoIGZyb20gXCIuL25hdmlnYXRpb24vV2F5cG9pbnRHcmFwaFwiO1xuaW1wb3J0IHsgTmF2V2FuZGVyZXIgfSBmcm9tIFwiLi9zdHJhdGVnaWVzL05hdldhbmRlcmVyXCI7XG5cbmNvbnN0IHtjY2NsYXNzLCBwcm9wZXJ0eX0gPSBjYy5fZGVjb3JhdG9yO1xuXG4vLyp8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8KlxcXFxcbi8vIFRPRE8gKDMuMyk6IENvbXBsZXRlIE5hdldhbmRlckFnZW50J3MgYmVoYXZpb3VyIHVzaW5nIE5hdldhbmRlcmVyLlxuLy8gW1NQRUNJRklDQVRJT05TXVxuLy8gLSBDaGVjayBvdXQgdGhlIG90aGVyIGFnZW50cyB0byBmaWd1cmUgb3V0IHdoYXQncyBtaXNzaW5nLCBhbmQgY29ubmVjdFxuLy8gICBldmVyeXRoaW5nIHRvZ2V0aGVyIVxuLy8qfHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fCpcXFxcXG5cbkBjY2NsYXNzXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBOYXZXYW5kZXJBZ2VudFxuICAgIGV4dGVuZHMgQWdlbnQgXG4gICAgaW1wbGVtZW50cyBJSW5wdXRDb250cm9sc3tcbiAgICBcbiAgICBwdWJsaWMgZ2V0IGhvcml6b250YWxBeGlzKCk6IG51bWJlciB7XG4gICAgICAgIC8vI3JlZ2lvbiBbWU9VUiBJTVBMRU1FTlRBVElPTiBIRVJFXVxuICAgICAgICByZXR1cm4gMDtcbiAgICAgICAgLy8jZW5kcmVnaW9uXG4gICAgfVxuICAgIHB1YmxpYyBnZXQgdmVydGljYWxBeGlzKCk6IG51bWJlciB7XG4gICAgICAgIC8vI3JlZ2lvbiBbWU9VUiBJTVBMRU1FTlRBVElPTiBIRVJFXVxuICAgICAgICByZXR1cm4gMDtcbiAgICAgICAgLy8jZW5kcmVnaW9uXG4gICAgfVxuICAgIGF0dGFjazogQnV0dG9uU3RhdGUgPSBCdXR0b25TdGF0ZS5SZXN0O1xuICAgIGludGVyYWN0OiBCdXR0b25TdGF0ZSA9IEJ1dHRvblN0YXRlLlJlc3Q7XG4gICAgQHByb3BlcnR5KFdheXBvaW50R3JhcGgpXG4gICAgd2F5cG9pbnRHcmFwaDogV2F5cG9pbnRHcmFwaCA9IG51bGw7XG5cbiAgICAvLyNyZWdpb24gW1lPVVIgSU1QTEVNRU5UQVRJT04gSEVSRV1cbiAgICBcbiAgICAvLyNlbmRyZWdpb25cbiAgICBwcm90ZWN0ZWQgYWdlbnRVcGRhdGUoZHQ6IG51bWJlcik6IHZvaWQge1xuICAgICAgICAvLyNyZWdpb24gW1lPVVIgSU1QTEVNRU5UQVRJT04gSEVSRV1cbiAgICAgICAgXG4gICAgICAgIC8vI2VuZHJlZ2lvblxuICAgIH1cblxuICAgIC8vIExJRkUtQ1lDTEUgQ0FMTEJBQ0tTOlxuXG4gICAgb25Mb2FkKCkge1xuICAgICAgICAvLyNyZWdpb24gW1lPVVIgSU1QTEVNRU5UQVRJT04gSEVSRV1cbiAgICAgICAgXG4gICAgICAgIC8vI2VuZHJlZ2lvblxuICAgIH1cblxuICAgIHN0YXJ0ICgpIHtcbiAgICAgICAgLy8jcmVnaW9uIFtZT1VSIElNUExFTUVOVEFUSU9OIEhFUkVdXG4gICAgICAgIFxuICAgICAgICAvLyNlbmRyZWdpb25cbiAgICB9XG5cbiAgICAvLyB1cGRhdGUgKGR0KSB7fVxufVxuIl19