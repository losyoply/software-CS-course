
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/ai/navigation/WaypointGraph.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '52cf3NZr8ZAxKRQwnrrDfzI', 'WaypointGraph');
// scripts/ai/navigation/WaypointGraph.ts

// Learn TypeScript:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/typescript.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/life-cycle-callbacks.html
Object.defineProperty(exports, "__esModule", { value: true });
var Waypoint_1 = require("./Waypoint");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var WaypointGraph = /** @class */ (function (_super) {
    __extends(WaypointGraph, _super);
    function WaypointGraph() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.adjacencyList = [];
        _this._shortestDistanceMatrix = null;
        _this._shortestPathMatrix = null;
        return _this;
    }
    WaypointGraph.prototype.addWaypoint = function (waypoint) {
        this.adjacencyList.push(waypoint);
        this._shortestDistanceMatrix = null;
        this._shortestPathMatrix = null;
    };
    Object.defineProperty(WaypointGraph.prototype, "shortestDistanceMatrix", {
        /** The shortest distance matrix of the graph. Query by concatenating the uuid of the two waypoints.
         *
         * Example:
         * `waypointGraph.shortestDistanceMatrix.get(waypointA.uuid + waypointB.uuid)` returns
         * the shortest distance on the graph `waypointGraph` between `waypointA` and `waypointB`.
         */
        get: function () {
            if (!this._shortestDistanceMatrix)
                this.allPairsShortestPath();
            return this._shortestDistanceMatrix;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(WaypointGraph.prototype, "shortestPathMatrix", {
        /** The shortest path matrix of the graph. Query by concatenating the uuid of the two waypoints.
         *
         * Example:
         * `waypointGraph.shortestPathMatrix.get(waypointA.uuid + waypointB.uuid)` returns
         * the next waypoint on the shortest path between `waypointA` and `waypointB` on
         * the graph `waypointGraph`.
         */
        get: function () {
            if (!this._shortestPathMatrix)
                this.allPairsShortestPath();
            return this._shortestPathMatrix;
        },
        enumerable: false,
        configurable: true
    });
    //*||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||*\\
    // TODO (4.1): Complete allPairsShortestPath using the Floyd-Warshall algorithm.
    // [SPECIFICATIONS]
    // - Implement the Floyd-Warshall algorithm.
    // - Index into the "matrices" by concatenating the uuid of the two waypoints.
    //   - Ex. 1: this._shortestPathMatrix.get(waypointA.uuid + waypointB.uuid)
    //   - Ex. 2: this._shortestDistanceMatrix.set(waypointA.uuid + waypointB.uuid, Infinity)
    //   - Do not worry about time complexity (for our purposes you can consider indexing 
    //     into a map as an operation that takes constant (O(1)) time)
    // - You can iterate through this.adjacencyList to get every Waypoint (vertex) on the graph.
    // - You can use the template below or follow your own understanding of the algorithm.
    //*||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||*\\
    /**
     * Computes all pairs shortest path for the waypoint graph, and cache the results
     * in the matrices _shortestDistanceMatrix and _shortestPathMatrix.
     */
    WaypointGraph.prototype.allPairsShortestPath = function () {
        // Floyd-Warshall algorithm
        this._shortestDistanceMatrix = new Map();
        this._shortestPathMatrix = new Map();
        // Initialization
        // Hint: You can use a waypoint's adjacentWaypoints and distances to get
        // the waypoint's out-edges!
        // ie. waypointA.adjacentWaypoints[0]'s distance from waypointA is equal to
        // waypointA.distances[0].
        // BEGIN PSEUDOCODE
        // For each pair of waypoints (A, B) in the waypoint graph:
        // 	 If B is adjacent to A, set shortestDistanceMatrix(A, B) to the weight of edge (A, B),
        //   and shortestPathMatrix(A, B) to B.
        //   Otherwise:
        //	   If A and B are the same, set shortestDistanceMatrix(A, B) to 0, and 
        //     shortestPathMatrix(A, B) to A.
        //	   Otherwise, set shortestDistanceMatrix(A, B) to Infinity, and
        //	   shortestPathMatrix(A, B) to null.
        // END PSEUDOCODE 
        // Core algorithm
        // BEGIN PSEUDOCODE
        // For each waypoint C in the waypoint graph:
        //   For each pair of waypoints (A, B) in the waypoint graph:
        // 	   Denote the current shortest path between A and B as AB,
        //	   the current shortest path between A and C as AC,
        //	   and the current shortest path between C and B as CB.
        //     If length of AB is greater than length of AC and CB combined,
        //	   update AB such that shortestDistanceMatrix(A, B) is length of AC + CB,
        //	   and shortestPathMatrix(A, B) is C.
        // END PSEUDOCODE 
    };
    /**
     * Utility method. You can use this to double-check your allPairsShortestPath implementation.
     */
    WaypointGraph.prototype.printShortestPathMatrix = function () {
        for (var _i = 0, _a = this.adjacencyList; _i < _a.length; _i++) {
            var from = _a[_i];
            for (var _b = 0, _c = this.adjacencyList; _b < _c.length; _b++) {
                var to = _c[_b];
                console.log(this.node.name + ": Shortest path from " + from.name + " to " + to.name + " is through " + this.shortestPathMatrix.get(from.uuid + to.uuid).name);
            }
        }
    };
    // LIFE-CYCLE CALLBACKS:
    WaypointGraph.prototype.onLoad = function () {
        this.adjacencyList = this.node.getComponentsInChildren(Waypoint_1.default);
    };
    WaypointGraph.prototype.start = function () {
    };
    WaypointGraph = __decorate([
        ccclass
    ], WaypointGraph);
    return WaypointGraph;
}(cc.Component));
exports.default = WaypointGraph;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcYWlcXG5hdmlnYXRpb25cXFdheXBvaW50R3JhcGgudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsb0JBQW9CO0FBQ3BCLGtGQUFrRjtBQUNsRix5RkFBeUY7QUFDekYsbUJBQW1CO0FBQ25CLDRGQUE0RjtBQUM1RixtR0FBbUc7QUFDbkcsOEJBQThCO0FBQzlCLDRGQUE0RjtBQUM1RixtR0FBbUc7O0FBRW5HLHVDQUFrQztBQUU1QixJQUFBLEtBQXNCLEVBQUUsQ0FBQyxVQUFVLEVBQWxDLE9BQU8sYUFBQSxFQUFFLFFBQVEsY0FBaUIsQ0FBQztBQUcxQztJQUEyQyxpQ0FBWTtJQUF2RDtRQUFBLHFFQXVHQztRQXRHVSxtQkFBYSxHQUFlLEVBQUUsQ0FBQztRQU05Qiw2QkFBdUIsR0FBd0IsSUFBSSxDQUFDO1FBQ3BELHlCQUFtQixHQUEwQixJQUFJLENBQUM7O0lBK0Y5RCxDQUFDO0lBckdVLG1DQUFXLEdBQWxCLFVBQW1CLFFBQWtCO1FBQ2pDLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQ2xDLElBQUksQ0FBQyx1QkFBdUIsR0FBRyxJQUFJLENBQUM7UUFDcEMsSUFBSSxDQUFDLG1CQUFtQixHQUFHLElBQUksQ0FBQztJQUNwQyxDQUFDO0lBU0Qsc0JBQVcsaURBQXNCO1FBTmpDOzs7OztXQUtHO2FBQ0g7WUFDSSxJQUFJLENBQUMsSUFBSSxDQUFDLHVCQUF1QjtnQkFBRSxJQUFJLENBQUMsb0JBQW9CLEVBQUUsQ0FBQztZQUMvRCxPQUFPLElBQUksQ0FBQyx1QkFBdUIsQ0FBQztRQUN4QyxDQUFDOzs7T0FBQTtJQVFELHNCQUFXLDZDQUFrQjtRQVA3Qjs7Ozs7O1dBTUc7YUFDSDtZQUNJLElBQUksQ0FBQyxJQUFJLENBQUMsbUJBQW1CO2dCQUFFLElBQUksQ0FBQyxvQkFBb0IsRUFBRSxDQUFDO1lBQzNELE9BQU8sSUFBSSxDQUFDLG1CQUFtQixDQUFDO1FBQ3BDLENBQUM7OztPQUFBO0lBR0QsNEVBQTRFO0lBQzVFLGdGQUFnRjtJQUNoRixtQkFBbUI7SUFDbkIsNENBQTRDO0lBQzVDLDhFQUE4RTtJQUM5RSwyRUFBMkU7SUFDM0UseUZBQXlGO0lBQ3pGLHNGQUFzRjtJQUN0RixrRUFBa0U7SUFDbEUsNEZBQTRGO0lBQzVGLHNGQUFzRjtJQUN0Riw0RUFBNEU7SUFDNUU7OztPQUdHO0lBQ0ssNENBQW9CLEdBQTVCO1FBQ0ksMkJBQTJCO1FBQzNCLElBQUksQ0FBQyx1QkFBdUIsR0FBRyxJQUFJLEdBQUcsRUFBa0IsQ0FBQztRQUN6RCxJQUFJLENBQUMsbUJBQW1CLEdBQUcsSUFBSSxHQUFHLEVBQW9CLENBQUM7UUFDdkQsaUJBQWlCO1FBQ2pCLHdFQUF3RTtRQUN4RSw0QkFBNEI7UUFDNUIsMkVBQTJFO1FBQzNFLDBCQUEwQjtRQUVoQyxtQkFBbUI7UUFDbkIsMkRBQTJEO1FBQzNELDBGQUEwRjtRQUMxRix1Q0FBdUM7UUFDdkMsZUFBZTtRQUNmLDBFQUEwRTtRQUMxRSxxQ0FBcUM7UUFDckMsa0VBQWtFO1FBQ2xFLHVDQUF1QztRQUN2QyxrQkFBa0I7UUFFWixpQkFBaUI7UUFDdkIsbUJBQW1CO1FBQ25CLDZDQUE2QztRQUM3Qyw2REFBNkQ7UUFDN0QsOERBQThEO1FBQzlELHNEQUFzRDtRQUN0RCwwREFBMEQ7UUFDMUQsb0VBQW9FO1FBQ3BFLDRFQUE0RTtRQUM1RSx3Q0FBd0M7UUFDeEMsa0JBQWtCO0lBQ2hCLENBQUM7SUFDRDs7T0FFRztJQUNLLCtDQUF1QixHQUEvQjtRQUNJLEtBQWlCLFVBQWtCLEVBQWxCLEtBQUEsSUFBSSxDQUFDLGFBQWEsRUFBbEIsY0FBa0IsRUFBbEIsSUFBa0IsRUFBRTtZQUFoQyxJQUFJLElBQUksU0FBQTtZQUNULEtBQWUsVUFBa0IsRUFBbEIsS0FBQSxJQUFJLENBQUMsYUFBYSxFQUFsQixjQUFrQixFQUFsQixJQUFrQixFQUFFO2dCQUE5QixJQUFJLEVBQUUsU0FBQTtnQkFDUCxPQUFPLENBQUMsR0FBRyxDQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSw2QkFBd0IsSUFBSSxDQUFDLElBQUksWUFBTyxFQUFFLENBQUMsSUFBSSxvQkFBZSxJQUFJLENBQUMsa0JBQWtCLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxDQUFDLElBQU0sQ0FBQyxDQUFDO2FBQ3ZKO1NBQ0o7SUFDTCxDQUFDO0lBRUQsd0JBQXdCO0lBRXhCLDhCQUFNLEdBQU47UUFDSSxJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsdUJBQXVCLENBQUMsa0JBQVEsQ0FBQyxDQUFDO0lBQ3JFLENBQUM7SUFFRCw2QkFBSyxHQUFMO0lBR0EsQ0FBQztJQXJHZ0IsYUFBYTtRQURqQyxPQUFPO09BQ2EsYUFBYSxDQXVHakM7SUFBRCxvQkFBQztDQXZHRCxBQXVHQyxDQXZHMEMsRUFBRSxDQUFDLFNBQVMsR0F1R3REO2tCQXZHb0IsYUFBYSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8vIExlYXJuIFR5cGVTY3JpcHQ6XG4vLyAgLSBbQ2hpbmVzZV0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC96aC9zY3JpcHRpbmcvdHlwZXNjcmlwdC5odG1sXG4vLyAgLSBbRW5nbGlzaF0gaHR0cDovL3d3dy5jb2NvczJkLXgub3JnL2RvY3MvY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3R5cGVzY3JpcHQuaHRtbFxuLy8gTGVhcm4gQXR0cmlidXRlOlxuLy8gIC0gW0NoaW5lc2VdIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvemgvc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcbi8vICAtIFtFbmdsaXNoXSBodHRwOi8vd3d3LmNvY29zMmQteC5vcmcvZG9jcy9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvcmVmZXJlbmNlL2F0dHJpYnV0ZXMuaHRtbFxuLy8gTGVhcm4gbGlmZS1jeWNsZSBjYWxsYmFja3M6XG4vLyAgLSBbQ2hpbmVzZV0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC96aC9zY3JpcHRpbmcvbGlmZS1jeWNsZS1jYWxsYmFja3MuaHRtbFxuLy8gIC0gW0VuZ2xpc2hdIGh0dHA6Ly93d3cuY29jb3MyZC14Lm9yZy9kb2NzL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9saWZlLWN5Y2xlLWNhbGxiYWNrcy5odG1sXG5cbmltcG9ydCBXYXlwb2ludCBmcm9tIFwiLi9XYXlwb2ludFwiO1xuXG5jb25zdCB7Y2NjbGFzcywgcHJvcGVydHl9ID0gY2MuX2RlY29yYXRvcjtcblxuQGNjY2xhc3NcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIFdheXBvaW50R3JhcGggZXh0ZW5kcyBjYy5Db21wb25lbnQge1xuICAgIHB1YmxpYyBhZGphY2VuY3lMaXN0OiBXYXlwb2ludFtdID0gW107XG4gICAgcHVibGljIGFkZFdheXBvaW50KHdheXBvaW50OiBXYXlwb2ludCk6IHZvaWQge1xuICAgICAgICB0aGlzLmFkamFjZW5jeUxpc3QucHVzaCh3YXlwb2ludCk7XG4gICAgICAgIHRoaXMuX3Nob3J0ZXN0RGlzdGFuY2VNYXRyaXggPSBudWxsO1xuICAgICAgICB0aGlzLl9zaG9ydGVzdFBhdGhNYXRyaXggPSBudWxsO1xuICAgIH1cbiAgICBwcml2YXRlIF9zaG9ydGVzdERpc3RhbmNlTWF0cml4OiBNYXA8c3RyaW5nLCBudW1iZXI+ID0gbnVsbDtcbiAgICBwcml2YXRlIF9zaG9ydGVzdFBhdGhNYXRyaXg6IE1hcDxzdHJpbmcsIFdheXBvaW50PiA9IG51bGw7XG4gICAgLyoqIFRoZSBzaG9ydGVzdCBkaXN0YW5jZSBtYXRyaXggb2YgdGhlIGdyYXBoLiBRdWVyeSBieSBjb25jYXRlbmF0aW5nIHRoZSB1dWlkIG9mIHRoZSB0d28gd2F5cG9pbnRzLlxuICAgICAqIFxuICAgICAqIEV4YW1wbGU6XG4gICAgICogYHdheXBvaW50R3JhcGguc2hvcnRlc3REaXN0YW5jZU1hdHJpeC5nZXQod2F5cG9pbnRBLnV1aWQgKyB3YXlwb2ludEIudXVpZClgIHJldHVybnNcbiAgICAgKiB0aGUgc2hvcnRlc3QgZGlzdGFuY2Ugb24gdGhlIGdyYXBoIGB3YXlwb2ludEdyYXBoYCBiZXR3ZWVuIGB3YXlwb2ludEFgIGFuZCBgd2F5cG9pbnRCYC5cbiAgICAgKi9cbiAgICBwdWJsaWMgZ2V0IHNob3J0ZXN0RGlzdGFuY2VNYXRyaXgoKTogTWFwPHN0cmluZywgbnVtYmVyPntcbiAgICAgICAgaWYgKCF0aGlzLl9zaG9ydGVzdERpc3RhbmNlTWF0cml4KSB0aGlzLmFsbFBhaXJzU2hvcnRlc3RQYXRoKCk7XG4gICAgICAgIHJldHVybiB0aGlzLl9zaG9ydGVzdERpc3RhbmNlTWF0cml4O1xuICAgIH1cbiAgICAvKiogVGhlIHNob3J0ZXN0IHBhdGggbWF0cml4IG9mIHRoZSBncmFwaC4gUXVlcnkgYnkgY29uY2F0ZW5hdGluZyB0aGUgdXVpZCBvZiB0aGUgdHdvIHdheXBvaW50cy5cbiAgICAgKiBcbiAgICAgKiBFeGFtcGxlOlxuICAgICAqIGB3YXlwb2ludEdyYXBoLnNob3J0ZXN0UGF0aE1hdHJpeC5nZXQod2F5cG9pbnRBLnV1aWQgKyB3YXlwb2ludEIudXVpZClgIHJldHVybnNcbiAgICAgKiB0aGUgbmV4dCB3YXlwb2ludCBvbiB0aGUgc2hvcnRlc3QgcGF0aCBiZXR3ZWVuIGB3YXlwb2ludEFgIGFuZCBgd2F5cG9pbnRCYCBvblxuICAgICAqIHRoZSBncmFwaCBgd2F5cG9pbnRHcmFwaGAuXG4gICAgICovXG4gICAgcHVibGljIGdldCBzaG9ydGVzdFBhdGhNYXRyaXgoKTogTWFwPHN0cmluZywgV2F5cG9pbnQ+e1xuICAgICAgICBpZiAoIXRoaXMuX3Nob3J0ZXN0UGF0aE1hdHJpeCkgdGhpcy5hbGxQYWlyc1Nob3J0ZXN0UGF0aCgpO1xuICAgICAgICByZXR1cm4gdGhpcy5fc2hvcnRlc3RQYXRoTWF0cml4O1xuICAgIH1cblxuICAgIFxuICAgIC8vKnx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHwqXFxcXFxuICAgIC8vIFRPRE8gKDQuMSk6IENvbXBsZXRlIGFsbFBhaXJzU2hvcnRlc3RQYXRoIHVzaW5nIHRoZSBGbG95ZC1XYXJzaGFsbCBhbGdvcml0aG0uXG4gICAgLy8gW1NQRUNJRklDQVRJT05TXVxuICAgIC8vIC0gSW1wbGVtZW50IHRoZSBGbG95ZC1XYXJzaGFsbCBhbGdvcml0aG0uXG4gICAgLy8gLSBJbmRleCBpbnRvIHRoZSBcIm1hdHJpY2VzXCIgYnkgY29uY2F0ZW5hdGluZyB0aGUgdXVpZCBvZiB0aGUgdHdvIHdheXBvaW50cy5cbiAgICAvLyAgIC0gRXguIDE6IHRoaXMuX3Nob3J0ZXN0UGF0aE1hdHJpeC5nZXQod2F5cG9pbnRBLnV1aWQgKyB3YXlwb2ludEIudXVpZClcbiAgICAvLyAgIC0gRXguIDI6IHRoaXMuX3Nob3J0ZXN0RGlzdGFuY2VNYXRyaXguc2V0KHdheXBvaW50QS51dWlkICsgd2F5cG9pbnRCLnV1aWQsIEluZmluaXR5KVxuICAgIC8vICAgLSBEbyBub3Qgd29ycnkgYWJvdXQgdGltZSBjb21wbGV4aXR5IChmb3Igb3VyIHB1cnBvc2VzIHlvdSBjYW4gY29uc2lkZXIgaW5kZXhpbmcgXG4gICAgLy8gICAgIGludG8gYSBtYXAgYXMgYW4gb3BlcmF0aW9uIHRoYXQgdGFrZXMgY29uc3RhbnQgKE8oMSkpIHRpbWUpXG4gICAgLy8gLSBZb3UgY2FuIGl0ZXJhdGUgdGhyb3VnaCB0aGlzLmFkamFjZW5jeUxpc3QgdG8gZ2V0IGV2ZXJ5IFdheXBvaW50ICh2ZXJ0ZXgpIG9uIHRoZSBncmFwaC5cbiAgICAvLyAtIFlvdSBjYW4gdXNlIHRoZSB0ZW1wbGF0ZSBiZWxvdyBvciBmb2xsb3cgeW91ciBvd24gdW5kZXJzdGFuZGluZyBvZiB0aGUgYWxnb3JpdGhtLlxuICAgIC8vKnx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHwqXFxcXFxuICAgIC8qKlxuICAgICAqIENvbXB1dGVzIGFsbCBwYWlycyBzaG9ydGVzdCBwYXRoIGZvciB0aGUgd2F5cG9pbnQgZ3JhcGgsIGFuZCBjYWNoZSB0aGUgcmVzdWx0c1xuICAgICAqIGluIHRoZSBtYXRyaWNlcyBfc2hvcnRlc3REaXN0YW5jZU1hdHJpeCBhbmQgX3Nob3J0ZXN0UGF0aE1hdHJpeC5cbiAgICAgKi9cbiAgICBwcml2YXRlIGFsbFBhaXJzU2hvcnRlc3RQYXRoKCkge1xuICAgICAgICAvLyBGbG95ZC1XYXJzaGFsbCBhbGdvcml0aG1cbiAgICAgICAgdGhpcy5fc2hvcnRlc3REaXN0YW5jZU1hdHJpeCA9IG5ldyBNYXA8c3RyaW5nLCBudW1iZXI+KCk7XG4gICAgICAgIHRoaXMuX3Nob3J0ZXN0UGF0aE1hdHJpeCA9IG5ldyBNYXA8c3RyaW5nLCBXYXlwb2ludD4oKTtcbiAgICAgICAgLy8gSW5pdGlhbGl6YXRpb25cbiAgICAgICAgLy8gSGludDogWW91IGNhbiB1c2UgYSB3YXlwb2ludCdzIGFkamFjZW50V2F5cG9pbnRzIGFuZCBkaXN0YW5jZXMgdG8gZ2V0XG4gICAgICAgIC8vIHRoZSB3YXlwb2ludCdzIG91dC1lZGdlcyFcbiAgICAgICAgLy8gaWUuIHdheXBvaW50QS5hZGphY2VudFdheXBvaW50c1swXSdzIGRpc3RhbmNlIGZyb20gd2F5cG9pbnRBIGlzIGVxdWFsIHRvXG4gICAgICAgIC8vIHdheXBvaW50QS5kaXN0YW5jZXNbMF0uXG5cdFx0XG5cdFx0Ly8gQkVHSU4gUFNFVURPQ09ERVxuXHRcdC8vIEZvciBlYWNoIHBhaXIgb2Ygd2F5cG9pbnRzIChBLCBCKSBpbiB0aGUgd2F5cG9pbnQgZ3JhcGg6XG5cdFx0Ly8gXHQgSWYgQiBpcyBhZGphY2VudCB0byBBLCBzZXQgc2hvcnRlc3REaXN0YW5jZU1hdHJpeChBLCBCKSB0byB0aGUgd2VpZ2h0IG9mIGVkZ2UgKEEsIEIpLFxuXHRcdC8vICAgYW5kIHNob3J0ZXN0UGF0aE1hdHJpeChBLCBCKSB0byBCLlxuXHRcdC8vICAgT3RoZXJ3aXNlOlxuXHRcdC8vXHQgICBJZiBBIGFuZCBCIGFyZSB0aGUgc2FtZSwgc2V0IHNob3J0ZXN0RGlzdGFuY2VNYXRyaXgoQSwgQikgdG8gMCwgYW5kIFxuXHRcdC8vICAgICBzaG9ydGVzdFBhdGhNYXRyaXgoQSwgQikgdG8gQS5cblx0XHQvL1x0ICAgT3RoZXJ3aXNlLCBzZXQgc2hvcnRlc3REaXN0YW5jZU1hdHJpeChBLCBCKSB0byBJbmZpbml0eSwgYW5kXG5cdFx0Ly9cdCAgIHNob3J0ZXN0UGF0aE1hdHJpeChBLCBCKSB0byBudWxsLlxuXHRcdC8vIEVORCBQU0VVRE9DT0RFIFxuXG4gICAgICAgIC8vIENvcmUgYWxnb3JpdGhtXG5cdFx0Ly8gQkVHSU4gUFNFVURPQ09ERVxuXHRcdC8vIEZvciBlYWNoIHdheXBvaW50IEMgaW4gdGhlIHdheXBvaW50IGdyYXBoOlxuXHRcdC8vICAgRm9yIGVhY2ggcGFpciBvZiB3YXlwb2ludHMgKEEsIEIpIGluIHRoZSB3YXlwb2ludCBncmFwaDpcblx0XHQvLyBcdCAgIERlbm90ZSB0aGUgY3VycmVudCBzaG9ydGVzdCBwYXRoIGJldHdlZW4gQSBhbmQgQiBhcyBBQixcblx0XHQvL1x0ICAgdGhlIGN1cnJlbnQgc2hvcnRlc3QgcGF0aCBiZXR3ZWVuIEEgYW5kIEMgYXMgQUMsXG5cdFx0Ly9cdCAgIGFuZCB0aGUgY3VycmVudCBzaG9ydGVzdCBwYXRoIGJldHdlZW4gQyBhbmQgQiBhcyBDQi5cblx0XHQvLyAgICAgSWYgbGVuZ3RoIG9mIEFCIGlzIGdyZWF0ZXIgdGhhbiBsZW5ndGggb2YgQUMgYW5kIENCIGNvbWJpbmVkLFxuXHRcdC8vXHQgICB1cGRhdGUgQUIgc3VjaCB0aGF0IHNob3J0ZXN0RGlzdGFuY2VNYXRyaXgoQSwgQikgaXMgbGVuZ3RoIG9mIEFDICsgQ0IsXG5cdFx0Ly9cdCAgIGFuZCBzaG9ydGVzdFBhdGhNYXRyaXgoQSwgQikgaXMgQy5cblx0XHQvLyBFTkQgUFNFVURPQ09ERSBcbiAgICB9XG4gICAgLyoqXG4gICAgICogVXRpbGl0eSBtZXRob2QuIFlvdSBjYW4gdXNlIHRoaXMgdG8gZG91YmxlLWNoZWNrIHlvdXIgYWxsUGFpcnNTaG9ydGVzdFBhdGggaW1wbGVtZW50YXRpb24uXG4gICAgICovXG4gICAgcHJpdmF0ZSBwcmludFNob3J0ZXN0UGF0aE1hdHJpeCgpIHtcbiAgICAgICAgZm9yIChsZXQgZnJvbSBvZiB0aGlzLmFkamFjZW5jeUxpc3QpIHtcbiAgICAgICAgICAgIGZvciAobGV0IHRvIG9mIHRoaXMuYWRqYWNlbmN5TGlzdCkgeyBcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhgJHt0aGlzLm5vZGUubmFtZX06IFNob3J0ZXN0IHBhdGggZnJvbSAke2Zyb20ubmFtZX0gdG8gJHt0by5uYW1lfSBpcyB0aHJvdWdoICR7dGhpcy5zaG9ydGVzdFBhdGhNYXRyaXguZ2V0KGZyb20udXVpZCArIHRvLnV1aWQpLm5hbWV9YCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAvLyBMSUZFLUNZQ0xFIENBTExCQUNLUzpcblxuICAgIG9uTG9hZCgpIHtcbiAgICAgICAgdGhpcy5hZGphY2VuY3lMaXN0ID0gdGhpcy5ub2RlLmdldENvbXBvbmVudHNJbkNoaWxkcmVuKFdheXBvaW50KTtcbiAgICB9XG5cbiAgICBzdGFydCgpIHtcbiAgICAgICAgXG5cbiAgICB9XG5cbn1cbiJdfQ==