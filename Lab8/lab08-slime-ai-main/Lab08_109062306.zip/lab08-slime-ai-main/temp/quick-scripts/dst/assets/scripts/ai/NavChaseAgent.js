
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/ai/NavChaseAgent.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '7aebaBbk2VOq7Q1SbCYHVIr', 'NavChaseAgent');
// scripts/ai/NavChaseAgent.ts

// Learn TypeScript:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/typescript.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/life-cycle-callbacks.html
Object.defineProperty(exports, "__esModule", { value: true });
var IInputControls_1 = require("../input/IInputControls");
var Agent_1 = require("./Agent");
var WaypointGraph_1 = require("./navigation/WaypointGraph");
var NavChaser_1 = require("./strategies/NavChaser");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var NavChaseAgent = /** @class */ (function (_super) {
    __extends(NavChaseAgent, _super);
    function NavChaseAgent() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.attack = IInputControls_1.ButtonState.Rest;
        _this.interact = IInputControls_1.ButtonState.Rest;
        _this.waypointGraph = null;
        _this.runTowards = null;
        _this._navChaser = null;
        return _this;
        // update (dt) {}
    }
    Object.defineProperty(NavChaseAgent.prototype, "horizontalAxis", {
        get: function () {
            if (!this._navChaser)
                return 0;
            return this._navChaser.horizontalAxis;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(NavChaseAgent.prototype, "verticalAxis", {
        get: function () {
            if (!this._navChaser)
                return 0;
            return this._navChaser.verticalAxis;
        },
        enumerable: false,
        configurable: true
    });
    NavChaseAgent.prototype.agentUpdate = function (dt) {
        this._navChaser.update(dt);
    };
    // LIFE-CYCLE CALLBACKS:
    NavChaseAgent.prototype.onLoad = function () {
        this._navChaser = new NavChaser_1.NavChaser(this, this.waypointGraph, this.runTowards);
    };
    NavChaseAgent.prototype.start = function () {
        this._navChaser.start();
    };
    __decorate([
        property(WaypointGraph_1.default)
    ], NavChaseAgent.prototype, "waypointGraph", void 0);
    __decorate([
        property(cc.Node)
    ], NavChaseAgent.prototype, "runTowards", void 0);
    NavChaseAgent = __decorate([
        ccclass
    ], NavChaseAgent);
    return NavChaseAgent;
}(Agent_1.default));
exports.default = NavChaseAgent;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcYWlcXE5hdkNoYXNlQWdlbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsb0JBQW9CO0FBQ3BCLGtGQUFrRjtBQUNsRix5RkFBeUY7QUFDekYsbUJBQW1CO0FBQ25CLDRGQUE0RjtBQUM1RixtR0FBbUc7QUFDbkcsOEJBQThCO0FBQzlCLDRGQUE0RjtBQUM1RixtR0FBbUc7O0FBRW5HLDBEQUFzRTtBQUN0RSxpQ0FBNEI7QUFDNUIsNERBQXVEO0FBQ3ZELG9EQUFtRDtBQUc3QyxJQUFBLEtBQXNCLEVBQUUsQ0FBQyxVQUFVLEVBQWxDLE9BQU8sYUFBQSxFQUFFLFFBQVEsY0FBaUIsQ0FBQztBQUcxQztJQUNZLGlDQUFLO0lBRGpCO1FBQUEscUVBdUNDO1FBM0JHLFlBQU0sR0FBZ0IsNEJBQVcsQ0FBQyxJQUFJLENBQUM7UUFDdkMsY0FBUSxHQUFnQiw0QkFBVyxDQUFDLElBQUksQ0FBQztRQUV6QyxtQkFBYSxHQUFrQixJQUFJLENBQUM7UUFFcEMsZ0JBQVUsR0FBWSxJQUFJLENBQUM7UUFFbkIsZ0JBQVUsR0FBYyxJQUFJLENBQUM7O1FBbUJyQyxpQkFBaUI7SUFDckIsQ0FBQztJQW5DRyxzQkFBVyx5Q0FBYzthQUF6QjtZQUNJLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVTtnQkFBRSxPQUFPLENBQUMsQ0FBQztZQUMvQixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFBO1FBQ3pDLENBQUM7OztPQUFBO0lBQ0Qsc0JBQVcsdUNBQVk7YUFBdkI7WUFDSSxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVU7Z0JBQUUsT0FBTyxDQUFDLENBQUM7WUFDL0IsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQTtRQUN2QyxDQUFDOzs7T0FBQTtJQVNTLG1DQUFXLEdBQXJCLFVBQXNCLEVBQVU7UUFDNUIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLENBQUM7SUFDL0IsQ0FBQztJQUVELHdCQUF3QjtJQUV4Qiw4QkFBTSxHQUFOO1FBQ0ksSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLHFCQUFTLENBQzNCLElBQUksRUFDSixJQUFJLENBQUMsYUFBYSxFQUNsQixJQUFJLENBQUMsVUFBVSxDQUNsQixDQUFDO0lBQ04sQ0FBQztJQUVELDZCQUFLLEdBQUw7UUFDSSxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssRUFBRSxDQUFDO0lBQzVCLENBQUM7SUFyQkQ7UUFEQyxRQUFRLENBQUMsdUJBQWEsQ0FBQzt3REFDWTtJQUVwQztRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDO3FEQUNTO0lBakJWLGFBQWE7UUFEakMsT0FBTztPQUNhLGFBQWEsQ0F1Q2pDO0lBQUQsb0JBQUM7Q0F2Q0QsQUF1Q0MsQ0F0Q1csZUFBSyxHQXNDaEI7a0JBdkNvQixhQUFhIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy8gTGVhcm4gVHlwZVNjcmlwdDpcbi8vICAtIFtDaGluZXNlXSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL3poL3NjcmlwdGluZy90eXBlc2NyaXB0Lmh0bWxcbi8vICAtIFtFbmdsaXNoXSBodHRwOi8vd3d3LmNvY29zMmQteC5vcmcvZG9jcy9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvdHlwZXNjcmlwdC5odG1sXG4vLyBMZWFybiBBdHRyaWJ1dGU6XG4vLyAgLSBbQ2hpbmVzZV0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC96aC9zY3JpcHRpbmcvcmVmZXJlbmNlL2F0dHJpYnV0ZXMuaHRtbFxuLy8gIC0gW0VuZ2xpc2hdIGh0dHA6Ly93d3cuY29jb3MyZC14Lm9yZy9kb2NzL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9yZWZlcmVuY2UvYXR0cmlidXRlcy5odG1sXG4vLyBMZWFybiBsaWZlLWN5Y2xlIGNhbGxiYWNrczpcbi8vICAtIFtDaGluZXNlXSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL3poL3NjcmlwdGluZy9saWZlLWN5Y2xlLWNhbGxiYWNrcy5odG1sXG4vLyAgLSBbRW5nbGlzaF0gaHR0cDovL3d3dy5jb2NvczJkLXgub3JnL2RvY3MvY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcblxuaW1wb3J0IHsgSUlucHV0Q29udHJvbHMsIEJ1dHRvblN0YXRlIH0gZnJvbSBcIi4uL2lucHV0L0lJbnB1dENvbnRyb2xzXCI7XG5pbXBvcnQgQWdlbnQgZnJvbSBcIi4vQWdlbnRcIjtcbmltcG9ydCBXYXlwb2ludEdyYXBoIGZyb20gXCIuL25hdmlnYXRpb24vV2F5cG9pbnRHcmFwaFwiO1xuaW1wb3J0IHsgTmF2Q2hhc2VyIH0gZnJvbSBcIi4vc3RyYXRlZ2llcy9OYXZDaGFzZXJcIjtcbmltcG9ydCB7IE5hdldhbmRlcmVyIH0gZnJvbSBcIi4vc3RyYXRlZ2llcy9OYXZXYW5kZXJlclwiO1xuXG5jb25zdCB7Y2NjbGFzcywgcHJvcGVydHl9ID0gY2MuX2RlY29yYXRvcjtcblxuQGNjY2xhc3NcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIE5hdkNoYXNlQWdlbnRcbiAgICBleHRlbmRzIEFnZW50IFxuICAgIGltcGxlbWVudHMgSUlucHV0Q29udHJvbHN7XG4gICAgXG4gICAgcHVibGljIGdldCBob3Jpem9udGFsQXhpcygpOiBudW1iZXIgeyBcbiAgICAgICAgaWYgKCF0aGlzLl9uYXZDaGFzZXIpIHJldHVybiAwO1xuICAgICAgICByZXR1cm4gdGhpcy5fbmF2Q2hhc2VyLmhvcml6b250YWxBeGlzXG4gICAgfVxuICAgIHB1YmxpYyBnZXQgdmVydGljYWxBeGlzKCk6IG51bWJlciB7XG4gICAgICAgIGlmICghdGhpcy5fbmF2Q2hhc2VyKSByZXR1cm4gMDtcbiAgICAgICAgcmV0dXJuIHRoaXMuX25hdkNoYXNlci52ZXJ0aWNhbEF4aXNcbiAgICB9XG4gICAgYXR0YWNrOiBCdXR0b25TdGF0ZSA9IEJ1dHRvblN0YXRlLlJlc3Q7XG4gICAgaW50ZXJhY3Q6IEJ1dHRvblN0YXRlID0gQnV0dG9uU3RhdGUuUmVzdDtcbiAgICBAcHJvcGVydHkoV2F5cG9pbnRHcmFwaClcbiAgICB3YXlwb2ludEdyYXBoOiBXYXlwb2ludEdyYXBoID0gbnVsbDtcbiAgICBAcHJvcGVydHkoY2MuTm9kZSlcbiAgICBydW5Ub3dhcmRzOiBjYy5Ob2RlID0gbnVsbDtcblxuICAgIHByaXZhdGUgX25hdkNoYXNlcjogTmF2Q2hhc2VyID0gbnVsbDtcbiAgICBwcm90ZWN0ZWQgYWdlbnRVcGRhdGUoZHQ6IG51bWJlcik6IHZvaWQge1xuICAgICAgICB0aGlzLl9uYXZDaGFzZXIudXBkYXRlKGR0KTtcbiAgICB9XG5cbiAgICAvLyBMSUZFLUNZQ0xFIENBTExCQUNLUzpcblxuICAgIG9uTG9hZCgpIHtcbiAgICAgICAgdGhpcy5fbmF2Q2hhc2VyID0gbmV3IE5hdkNoYXNlcihcbiAgICAgICAgICAgIHRoaXMsXG4gICAgICAgICAgICB0aGlzLndheXBvaW50R3JhcGgsXG4gICAgICAgICAgICB0aGlzLnJ1blRvd2FyZHNcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBzdGFydCgpIHtcbiAgICAgICAgdGhpcy5fbmF2Q2hhc2VyLnN0YXJ0KCk7XG4gICAgfVxuXG4gICAgLy8gdXBkYXRlIChkdCkge31cbn1cbiJdfQ==