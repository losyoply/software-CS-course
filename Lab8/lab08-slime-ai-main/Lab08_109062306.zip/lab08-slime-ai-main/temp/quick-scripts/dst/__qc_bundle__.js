
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/__qc_index__.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}
require('./assets/migration/use_reversed_rotateTo');
require('./assets/scripts/ActorController');
require('./assets/scripts/MapManager');
require('./assets/scripts/ai/Agent');
require('./assets/scripts/ai/NavChaseAgent');
require('./assets/scripts/ai/NavWanderAgent');
require('./assets/scripts/ai/ShyAgent');
require('./assets/scripts/ai/TODO5');
require('./assets/scripts/ai/WanderAgent');
require('./assets/scripts/ai/navigation/Waypoint');
require('./assets/scripts/ai/navigation/WaypointGraph');
require('./assets/scripts/ai/strategies/AgentStrategy');
require('./assets/scripts/ai/strategies/Coward');
require('./assets/scripts/ai/strategies/NavChaser');
require('./assets/scripts/ai/strategies/NavWanderer');
require('./assets/scripts/ai/strategies/Navigator');
require('./assets/scripts/ai/strategies/Wanderer');
require('./assets/scripts/camera/CameraTransposer');
require('./assets/scripts/input/Controller');
require('./assets/scripts/input/IInputControls');
require('./assets/scripts/input/KeyboardControls');
require('./assets/scripts/utilities/ZSortOnLoad');
require('./assets/scripts/utilities/ZSorter');

                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/ai/navigation/WaypointGraph.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '52cf3NZr8ZAxKRQwnrrDfzI', 'WaypointGraph');
// scripts/ai/navigation/WaypointGraph.ts

// Learn TypeScript:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/typescript.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/life-cycle-callbacks.html
Object.defineProperty(exports, "__esModule", { value: true });
var Waypoint_1 = require("./Waypoint");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var WaypointGraph = /** @class */ (function (_super) {
    __extends(WaypointGraph, _super);
    function WaypointGraph() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.adjacencyList = [];
        _this._shortestDistanceMatrix = null;
        _this._shortestPathMatrix = null;
        return _this;
    }
    WaypointGraph.prototype.addWaypoint = function (waypoint) {
        this.adjacencyList.push(waypoint);
        this._shortestDistanceMatrix = null;
        this._shortestPathMatrix = null;
    };
    Object.defineProperty(WaypointGraph.prototype, "shortestDistanceMatrix", {
        /** The shortest distance matrix of the graph. Query by concatenating the uuid of the two waypoints.
         *
         * Example:
         * `waypointGraph.shortestDistanceMatrix.get(waypointA.uuid + waypointB.uuid)` returns
         * the shortest distance on the graph `waypointGraph` between `waypointA` and `waypointB`.
         */
        get: function () {
            if (!this._shortestDistanceMatrix)
                this.allPairsShortestPath();
            return this._shortestDistanceMatrix;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(WaypointGraph.prototype, "shortestPathMatrix", {
        /** The shortest path matrix of the graph. Query by concatenating the uuid of the two waypoints.
         *
         * Example:
         * `waypointGraph.shortestPathMatrix.get(waypointA.uuid + waypointB.uuid)` returns
         * the next waypoint on the shortest path between `waypointA` and `waypointB` on
         * the graph `waypointGraph`.
         */
        get: function () {
            if (!this._shortestPathMatrix)
                this.allPairsShortestPath();
            return this._shortestPathMatrix;
        },
        enumerable: false,
        configurable: true
    });
    //*||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||*\\
    // TODO (4.1): Complete allPairsShortestPath using the Floyd-Warshall algorithm.
    // [SPECIFICATIONS]
    // - Implement the Floyd-Warshall algorithm.
    // - Index into the "matrices" by concatenating the uuid of the two waypoints.
    //   - Ex. 1: this._shortestPathMatrix.get(waypointA.uuid + waypointB.uuid)
    //   - Ex. 2: this._shortestDistanceMatrix.set(waypointA.uuid + waypointB.uuid, Infinity)
    //   - Do not worry about time complexity (for our purposes you can consider indexing 
    //     into a map as an operation that takes constant (O(1)) time)
    // - You can iterate through this.adjacencyList to get every Waypoint (vertex) on the graph.
    // - You can use the template below or follow your own understanding of the algorithm.
    //*||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||*\\
    /**
     * Computes all pairs shortest path for the waypoint graph, and cache the results
     * in the matrices _shortestDistanceMatrix and _shortestPathMatrix.
     */
    WaypointGraph.prototype.allPairsShortestPath = function () {
        // Floyd-Warshall algorithm
        this._shortestDistanceMatrix = new Map();
        this._shortestPathMatrix = new Map();
        // Initialization
        // Hint: You can use a waypoint's adjacentWaypoints and distances to get
        // the waypoint's out-edges!
        // ie. waypointA.adjacentWaypoints[0]'s distance from waypointA is equal to
        // waypointA.distances[0].
        // BEGIN PSEUDOCODE
        // For each pair of waypoints (A, B) in the waypoint graph:
        // 	 If B is adjacent to A, set shortestDistanceMatrix(A, B) to the weight of edge (A, B),
        //   and shortestPathMatrix(A, B) to B.
        //   Otherwise:
        //	   If A and B are the same, set shortestDistanceMatrix(A, B) to 0, and 
        //     shortestPathMatrix(A, B) to A.
        //	   Otherwise, set shortestDistanceMatrix(A, B) to Infinity, and
        //	   shortestPathMatrix(A, B) to null.
        // END PSEUDOCODE 
        // Core algorithm
        // BEGIN PSEUDOCODE
        // For each waypoint C in the waypoint graph:
        //   For each pair of waypoints (A, B) in the waypoint graph:
        // 	   Denote the current shortest path between A and B as AB,
        //	   the current shortest path between A and C as AC,
        //	   and the current shortest path between C and B as CB.
        //     If length of AB is greater than length of AC and CB combined,
        //	   update AB such that shortestDistanceMatrix(A, B) is length of AC + CB,
        //	   and shortestPathMatrix(A, B) is C.
        // END PSEUDOCODE 
    };
    /**
     * Utility method. You can use this to double-check your allPairsShortestPath implementation.
     */
    WaypointGraph.prototype.printShortestPathMatrix = function () {
        for (var _i = 0, _a = this.adjacencyList; _i < _a.length; _i++) {
            var from = _a[_i];
            for (var _b = 0, _c = this.adjacencyList; _b < _c.length; _b++) {
                var to = _c[_b];
                console.log(this.node.name + ": Shortest path from " + from.name + " to " + to.name + " is through " + this.shortestPathMatrix.get(from.uuid + to.uuid).name);
            }
        }
    };
    // LIFE-CYCLE CALLBACKS:
    WaypointGraph.prototype.onLoad = function () {
        this.adjacencyList = this.node.getComponentsInChildren(Waypoint_1.default);
    };
    WaypointGraph.prototype.start = function () {
    };
    WaypointGraph = __decorate([
        ccclass
    ], WaypointGraph);
    return WaypointGraph;
}(cc.Component));
exports.default = WaypointGraph;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcYWlcXG5hdmlnYXRpb25cXFdheXBvaW50R3JhcGgudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsb0JBQW9CO0FBQ3BCLGtGQUFrRjtBQUNsRix5RkFBeUY7QUFDekYsbUJBQW1CO0FBQ25CLDRGQUE0RjtBQUM1RixtR0FBbUc7QUFDbkcsOEJBQThCO0FBQzlCLDRGQUE0RjtBQUM1RixtR0FBbUc7O0FBRW5HLHVDQUFrQztBQUU1QixJQUFBLEtBQXNCLEVBQUUsQ0FBQyxVQUFVLEVBQWxDLE9BQU8sYUFBQSxFQUFFLFFBQVEsY0FBaUIsQ0FBQztBQUcxQztJQUEyQyxpQ0FBWTtJQUF2RDtRQUFBLHFFQXVHQztRQXRHVSxtQkFBYSxHQUFlLEVBQUUsQ0FBQztRQU05Qiw2QkFBdUIsR0FBd0IsSUFBSSxDQUFDO1FBQ3BELHlCQUFtQixHQUEwQixJQUFJLENBQUM7O0lBK0Y5RCxDQUFDO0lBckdVLG1DQUFXLEdBQWxCLFVBQW1CLFFBQWtCO1FBQ2pDLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQ2xDLElBQUksQ0FBQyx1QkFBdUIsR0FBRyxJQUFJLENBQUM7UUFDcEMsSUFBSSxDQUFDLG1CQUFtQixHQUFHLElBQUksQ0FBQztJQUNwQyxDQUFDO0lBU0Qsc0JBQVcsaURBQXNCO1FBTmpDOzs7OztXQUtHO2FBQ0g7WUFDSSxJQUFJLENBQUMsSUFBSSxDQUFDLHVCQUF1QjtnQkFBRSxJQUFJLENBQUMsb0JBQW9CLEVBQUUsQ0FBQztZQUMvRCxPQUFPLElBQUksQ0FBQyx1QkFBdUIsQ0FBQztRQUN4QyxDQUFDOzs7T0FBQTtJQVFELHNCQUFXLDZDQUFrQjtRQVA3Qjs7Ozs7O1dBTUc7YUFDSDtZQUNJLElBQUksQ0FBQyxJQUFJLENBQUMsbUJBQW1CO2dCQUFFLElBQUksQ0FBQyxvQkFBb0IsRUFBRSxDQUFDO1lBQzNELE9BQU8sSUFBSSxDQUFDLG1CQUFtQixDQUFDO1FBQ3BDLENBQUM7OztPQUFBO0lBR0QsNEVBQTRFO0lBQzVFLGdGQUFnRjtJQUNoRixtQkFBbUI7SUFDbkIsNENBQTRDO0lBQzVDLDhFQUE4RTtJQUM5RSwyRUFBMkU7SUFDM0UseUZBQXlGO0lBQ3pGLHNGQUFzRjtJQUN0RixrRUFBa0U7SUFDbEUsNEZBQTRGO0lBQzVGLHNGQUFzRjtJQUN0Riw0RUFBNEU7SUFDNUU7OztPQUdHO0lBQ0ssNENBQW9CLEdBQTVCO1FBQ0ksMkJBQTJCO1FBQzNCLElBQUksQ0FBQyx1QkFBdUIsR0FBRyxJQUFJLEdBQUcsRUFBa0IsQ0FBQztRQUN6RCxJQUFJLENBQUMsbUJBQW1CLEdBQUcsSUFBSSxHQUFHLEVBQW9CLENBQUM7UUFDdkQsaUJBQWlCO1FBQ2pCLHdFQUF3RTtRQUN4RSw0QkFBNEI7UUFDNUIsMkVBQTJFO1FBQzNFLDBCQUEwQjtRQUVoQyxtQkFBbUI7UUFDbkIsMkRBQTJEO1FBQzNELDBGQUEwRjtRQUMxRix1Q0FBdUM7UUFDdkMsZUFBZTtRQUNmLDBFQUEwRTtRQUMxRSxxQ0FBcUM7UUFDckMsa0VBQWtFO1FBQ2xFLHVDQUF1QztRQUN2QyxrQkFBa0I7UUFFWixpQkFBaUI7UUFDdkIsbUJBQW1CO1FBQ25CLDZDQUE2QztRQUM3Qyw2REFBNkQ7UUFDN0QsOERBQThEO1FBQzlELHNEQUFzRDtRQUN0RCwwREFBMEQ7UUFDMUQsb0VBQW9FO1FBQ3BFLDRFQUE0RTtRQUM1RSx3Q0FBd0M7UUFDeEMsa0JBQWtCO0lBQ2hCLENBQUM7SUFDRDs7T0FFRztJQUNLLCtDQUF1QixHQUEvQjtRQUNJLEtBQWlCLFVBQWtCLEVBQWxCLEtBQUEsSUFBSSxDQUFDLGFBQWEsRUFBbEIsY0FBa0IsRUFBbEIsSUFBa0IsRUFBRTtZQUFoQyxJQUFJLElBQUksU0FBQTtZQUNULEtBQWUsVUFBa0IsRUFBbEIsS0FBQSxJQUFJLENBQUMsYUFBYSxFQUFsQixjQUFrQixFQUFsQixJQUFrQixFQUFFO2dCQUE5QixJQUFJLEVBQUUsU0FBQTtnQkFDUCxPQUFPLENBQUMsR0FBRyxDQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSw2QkFBd0IsSUFBSSxDQUFDLElBQUksWUFBTyxFQUFFLENBQUMsSUFBSSxvQkFBZSxJQUFJLENBQUMsa0JBQWtCLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxDQUFDLElBQU0sQ0FBQyxDQUFDO2FBQ3ZKO1NBQ0o7SUFDTCxDQUFDO0lBRUQsd0JBQXdCO0lBRXhCLDhCQUFNLEdBQU47UUFDSSxJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsdUJBQXVCLENBQUMsa0JBQVEsQ0FBQyxDQUFDO0lBQ3JFLENBQUM7SUFFRCw2QkFBSyxHQUFMO0lBR0EsQ0FBQztJQXJHZ0IsYUFBYTtRQURqQyxPQUFPO09BQ2EsYUFBYSxDQXVHakM7SUFBRCxvQkFBQztDQXZHRCxBQXVHQyxDQXZHMEMsRUFBRSxDQUFDLFNBQVMsR0F1R3REO2tCQXZHb0IsYUFBYSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8vIExlYXJuIFR5cGVTY3JpcHQ6XG4vLyAgLSBbQ2hpbmVzZV0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC96aC9zY3JpcHRpbmcvdHlwZXNjcmlwdC5odG1sXG4vLyAgLSBbRW5nbGlzaF0gaHR0cDovL3d3dy5jb2NvczJkLXgub3JnL2RvY3MvY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3R5cGVzY3JpcHQuaHRtbFxuLy8gTGVhcm4gQXR0cmlidXRlOlxuLy8gIC0gW0NoaW5lc2VdIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvemgvc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcbi8vICAtIFtFbmdsaXNoXSBodHRwOi8vd3d3LmNvY29zMmQteC5vcmcvZG9jcy9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvcmVmZXJlbmNlL2F0dHJpYnV0ZXMuaHRtbFxuLy8gTGVhcm4gbGlmZS1jeWNsZSBjYWxsYmFja3M6XG4vLyAgLSBbQ2hpbmVzZV0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC96aC9zY3JpcHRpbmcvbGlmZS1jeWNsZS1jYWxsYmFja3MuaHRtbFxuLy8gIC0gW0VuZ2xpc2hdIGh0dHA6Ly93d3cuY29jb3MyZC14Lm9yZy9kb2NzL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9saWZlLWN5Y2xlLWNhbGxiYWNrcy5odG1sXG5cbmltcG9ydCBXYXlwb2ludCBmcm9tIFwiLi9XYXlwb2ludFwiO1xuXG5jb25zdCB7Y2NjbGFzcywgcHJvcGVydHl9ID0gY2MuX2RlY29yYXRvcjtcblxuQGNjY2xhc3NcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIFdheXBvaW50R3JhcGggZXh0ZW5kcyBjYy5Db21wb25lbnQge1xuICAgIHB1YmxpYyBhZGphY2VuY3lMaXN0OiBXYXlwb2ludFtdID0gW107XG4gICAgcHVibGljIGFkZFdheXBvaW50KHdheXBvaW50OiBXYXlwb2ludCk6IHZvaWQge1xuICAgICAgICB0aGlzLmFkamFjZW5jeUxpc3QucHVzaCh3YXlwb2ludCk7XG4gICAgICAgIHRoaXMuX3Nob3J0ZXN0RGlzdGFuY2VNYXRyaXggPSBudWxsO1xuICAgICAgICB0aGlzLl9zaG9ydGVzdFBhdGhNYXRyaXggPSBudWxsO1xuICAgIH1cbiAgICBwcml2YXRlIF9zaG9ydGVzdERpc3RhbmNlTWF0cml4OiBNYXA8c3RyaW5nLCBudW1iZXI+ID0gbnVsbDtcbiAgICBwcml2YXRlIF9zaG9ydGVzdFBhdGhNYXRyaXg6IE1hcDxzdHJpbmcsIFdheXBvaW50PiA9IG51bGw7XG4gICAgLyoqIFRoZSBzaG9ydGVzdCBkaXN0YW5jZSBtYXRyaXggb2YgdGhlIGdyYXBoLiBRdWVyeSBieSBjb25jYXRlbmF0aW5nIHRoZSB1dWlkIG9mIHRoZSB0d28gd2F5cG9pbnRzLlxuICAgICAqIFxuICAgICAqIEV4YW1wbGU6XG4gICAgICogYHdheXBvaW50R3JhcGguc2hvcnRlc3REaXN0YW5jZU1hdHJpeC5nZXQod2F5cG9pbnRBLnV1aWQgKyB3YXlwb2ludEIudXVpZClgIHJldHVybnNcbiAgICAgKiB0aGUgc2hvcnRlc3QgZGlzdGFuY2Ugb24gdGhlIGdyYXBoIGB3YXlwb2ludEdyYXBoYCBiZXR3ZWVuIGB3YXlwb2ludEFgIGFuZCBgd2F5cG9pbnRCYC5cbiAgICAgKi9cbiAgICBwdWJsaWMgZ2V0IHNob3J0ZXN0RGlzdGFuY2VNYXRyaXgoKTogTWFwPHN0cmluZywgbnVtYmVyPntcbiAgICAgICAgaWYgKCF0aGlzLl9zaG9ydGVzdERpc3RhbmNlTWF0cml4KSB0aGlzLmFsbFBhaXJzU2hvcnRlc3RQYXRoKCk7XG4gICAgICAgIHJldHVybiB0aGlzLl9zaG9ydGVzdERpc3RhbmNlTWF0cml4O1xuICAgIH1cbiAgICAvKiogVGhlIHNob3J0ZXN0IHBhdGggbWF0cml4IG9mIHRoZSBncmFwaC4gUXVlcnkgYnkgY29uY2F0ZW5hdGluZyB0aGUgdXVpZCBvZiB0aGUgdHdvIHdheXBvaW50cy5cbiAgICAgKiBcbiAgICAgKiBFeGFtcGxlOlxuICAgICAqIGB3YXlwb2ludEdyYXBoLnNob3J0ZXN0UGF0aE1hdHJpeC5nZXQod2F5cG9pbnRBLnV1aWQgKyB3YXlwb2ludEIudXVpZClgIHJldHVybnNcbiAgICAgKiB0aGUgbmV4dCB3YXlwb2ludCBvbiB0aGUgc2hvcnRlc3QgcGF0aCBiZXR3ZWVuIGB3YXlwb2ludEFgIGFuZCBgd2F5cG9pbnRCYCBvblxuICAgICAqIHRoZSBncmFwaCBgd2F5cG9pbnRHcmFwaGAuXG4gICAgICovXG4gICAgcHVibGljIGdldCBzaG9ydGVzdFBhdGhNYXRyaXgoKTogTWFwPHN0cmluZywgV2F5cG9pbnQ+e1xuICAgICAgICBpZiAoIXRoaXMuX3Nob3J0ZXN0UGF0aE1hdHJpeCkgdGhpcy5hbGxQYWlyc1Nob3J0ZXN0UGF0aCgpO1xuICAgICAgICByZXR1cm4gdGhpcy5fc2hvcnRlc3RQYXRoTWF0cml4O1xuICAgIH1cblxuICAgIFxuICAgIC8vKnx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHwqXFxcXFxuICAgIC8vIFRPRE8gKDQuMSk6IENvbXBsZXRlIGFsbFBhaXJzU2hvcnRlc3RQYXRoIHVzaW5nIHRoZSBGbG95ZC1XYXJzaGFsbCBhbGdvcml0aG0uXG4gICAgLy8gW1NQRUNJRklDQVRJT05TXVxuICAgIC8vIC0gSW1wbGVtZW50IHRoZSBGbG95ZC1XYXJzaGFsbCBhbGdvcml0aG0uXG4gICAgLy8gLSBJbmRleCBpbnRvIHRoZSBcIm1hdHJpY2VzXCIgYnkgY29uY2F0ZW5hdGluZyB0aGUgdXVpZCBvZiB0aGUgdHdvIHdheXBvaW50cy5cbiAgICAvLyAgIC0gRXguIDE6IHRoaXMuX3Nob3J0ZXN0UGF0aE1hdHJpeC5nZXQod2F5cG9pbnRBLnV1aWQgKyB3YXlwb2ludEIudXVpZClcbiAgICAvLyAgIC0gRXguIDI6IHRoaXMuX3Nob3J0ZXN0RGlzdGFuY2VNYXRyaXguc2V0KHdheXBvaW50QS51dWlkICsgd2F5cG9pbnRCLnV1aWQsIEluZmluaXR5KVxuICAgIC8vICAgLSBEbyBub3Qgd29ycnkgYWJvdXQgdGltZSBjb21wbGV4aXR5IChmb3Igb3VyIHB1cnBvc2VzIHlvdSBjYW4gY29uc2lkZXIgaW5kZXhpbmcgXG4gICAgLy8gICAgIGludG8gYSBtYXAgYXMgYW4gb3BlcmF0aW9uIHRoYXQgdGFrZXMgY29uc3RhbnQgKE8oMSkpIHRpbWUpXG4gICAgLy8gLSBZb3UgY2FuIGl0ZXJhdGUgdGhyb3VnaCB0aGlzLmFkamFjZW5jeUxpc3QgdG8gZ2V0IGV2ZXJ5IFdheXBvaW50ICh2ZXJ0ZXgpIG9uIHRoZSBncmFwaC5cbiAgICAvLyAtIFlvdSBjYW4gdXNlIHRoZSB0ZW1wbGF0ZSBiZWxvdyBvciBmb2xsb3cgeW91ciBvd24gdW5kZXJzdGFuZGluZyBvZiB0aGUgYWxnb3JpdGhtLlxuICAgIC8vKnx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHwqXFxcXFxuICAgIC8qKlxuICAgICAqIENvbXB1dGVzIGFsbCBwYWlycyBzaG9ydGVzdCBwYXRoIGZvciB0aGUgd2F5cG9pbnQgZ3JhcGgsIGFuZCBjYWNoZSB0aGUgcmVzdWx0c1xuICAgICAqIGluIHRoZSBtYXRyaWNlcyBfc2hvcnRlc3REaXN0YW5jZU1hdHJpeCBhbmQgX3Nob3J0ZXN0UGF0aE1hdHJpeC5cbiAgICAgKi9cbiAgICBwcml2YXRlIGFsbFBhaXJzU2hvcnRlc3RQYXRoKCkge1xuICAgICAgICAvLyBGbG95ZC1XYXJzaGFsbCBhbGdvcml0aG1cbiAgICAgICAgdGhpcy5fc2hvcnRlc3REaXN0YW5jZU1hdHJpeCA9IG5ldyBNYXA8c3RyaW5nLCBudW1iZXI+KCk7XG4gICAgICAgIHRoaXMuX3Nob3J0ZXN0UGF0aE1hdHJpeCA9IG5ldyBNYXA8c3RyaW5nLCBXYXlwb2ludD4oKTtcbiAgICAgICAgLy8gSW5pdGlhbGl6YXRpb25cbiAgICAgICAgLy8gSGludDogWW91IGNhbiB1c2UgYSB3YXlwb2ludCdzIGFkamFjZW50V2F5cG9pbnRzIGFuZCBkaXN0YW5jZXMgdG8gZ2V0XG4gICAgICAgIC8vIHRoZSB3YXlwb2ludCdzIG91dC1lZGdlcyFcbiAgICAgICAgLy8gaWUuIHdheXBvaW50QS5hZGphY2VudFdheXBvaW50c1swXSdzIGRpc3RhbmNlIGZyb20gd2F5cG9pbnRBIGlzIGVxdWFsIHRvXG4gICAgICAgIC8vIHdheXBvaW50QS5kaXN0YW5jZXNbMF0uXG5cdFx0XG5cdFx0Ly8gQkVHSU4gUFNFVURPQ09ERVxuXHRcdC8vIEZvciBlYWNoIHBhaXIgb2Ygd2F5cG9pbnRzIChBLCBCKSBpbiB0aGUgd2F5cG9pbnQgZ3JhcGg6XG5cdFx0Ly8gXHQgSWYgQiBpcyBhZGphY2VudCB0byBBLCBzZXQgc2hvcnRlc3REaXN0YW5jZU1hdHJpeChBLCBCKSB0byB0aGUgd2VpZ2h0IG9mIGVkZ2UgKEEsIEIpLFxuXHRcdC8vICAgYW5kIHNob3J0ZXN0UGF0aE1hdHJpeChBLCBCKSB0byBCLlxuXHRcdC8vICAgT3RoZXJ3aXNlOlxuXHRcdC8vXHQgICBJZiBBIGFuZCBCIGFyZSB0aGUgc2FtZSwgc2V0IHNob3J0ZXN0RGlzdGFuY2VNYXRyaXgoQSwgQikgdG8gMCwgYW5kIFxuXHRcdC8vICAgICBzaG9ydGVzdFBhdGhNYXRyaXgoQSwgQikgdG8gQS5cblx0XHQvL1x0ICAgT3RoZXJ3aXNlLCBzZXQgc2hvcnRlc3REaXN0YW5jZU1hdHJpeChBLCBCKSB0byBJbmZpbml0eSwgYW5kXG5cdFx0Ly9cdCAgIHNob3J0ZXN0UGF0aE1hdHJpeChBLCBCKSB0byBudWxsLlxuXHRcdC8vIEVORCBQU0VVRE9DT0RFIFxuXG4gICAgICAgIC8vIENvcmUgYWxnb3JpdGhtXG5cdFx0Ly8gQkVHSU4gUFNFVURPQ09ERVxuXHRcdC8vIEZvciBlYWNoIHdheXBvaW50IEMgaW4gdGhlIHdheXBvaW50IGdyYXBoOlxuXHRcdC8vICAgRm9yIGVhY2ggcGFpciBvZiB3YXlwb2ludHMgKEEsIEIpIGluIHRoZSB3YXlwb2ludCBncmFwaDpcblx0XHQvLyBcdCAgIERlbm90ZSB0aGUgY3VycmVudCBzaG9ydGVzdCBwYXRoIGJldHdlZW4gQSBhbmQgQiBhcyBBQixcblx0XHQvL1x0ICAgdGhlIGN1cnJlbnQgc2hvcnRlc3QgcGF0aCBiZXR3ZWVuIEEgYW5kIEMgYXMgQUMsXG5cdFx0Ly9cdCAgIGFuZCB0aGUgY3VycmVudCBzaG9ydGVzdCBwYXRoIGJldHdlZW4gQyBhbmQgQiBhcyBDQi5cblx0XHQvLyAgICAgSWYgbGVuZ3RoIG9mIEFCIGlzIGdyZWF0ZXIgdGhhbiBsZW5ndGggb2YgQUMgYW5kIENCIGNvbWJpbmVkLFxuXHRcdC8vXHQgICB1cGRhdGUgQUIgc3VjaCB0aGF0IHNob3J0ZXN0RGlzdGFuY2VNYXRyaXgoQSwgQikgaXMgbGVuZ3RoIG9mIEFDICsgQ0IsXG5cdFx0Ly9cdCAgIGFuZCBzaG9ydGVzdFBhdGhNYXRyaXgoQSwgQikgaXMgQy5cblx0XHQvLyBFTkQgUFNFVURPQ09ERSBcbiAgICB9XG4gICAgLyoqXG4gICAgICogVXRpbGl0eSBtZXRob2QuIFlvdSBjYW4gdXNlIHRoaXMgdG8gZG91YmxlLWNoZWNrIHlvdXIgYWxsUGFpcnNTaG9ydGVzdFBhdGggaW1wbGVtZW50YXRpb24uXG4gICAgICovXG4gICAgcHJpdmF0ZSBwcmludFNob3J0ZXN0UGF0aE1hdHJpeCgpIHtcbiAgICAgICAgZm9yIChsZXQgZnJvbSBvZiB0aGlzLmFkamFjZW5jeUxpc3QpIHtcbiAgICAgICAgICAgIGZvciAobGV0IHRvIG9mIHRoaXMuYWRqYWNlbmN5TGlzdCkgeyBcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhgJHt0aGlzLm5vZGUubmFtZX06IFNob3J0ZXN0IHBhdGggZnJvbSAke2Zyb20ubmFtZX0gdG8gJHt0by5uYW1lfSBpcyB0aHJvdWdoICR7dGhpcy5zaG9ydGVzdFBhdGhNYXRyaXguZ2V0KGZyb20udXVpZCArIHRvLnV1aWQpLm5hbWV9YCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAvLyBMSUZFLUNZQ0xFIENBTExCQUNLUzpcblxuICAgIG9uTG9hZCgpIHtcbiAgICAgICAgdGhpcy5hZGphY2VuY3lMaXN0ID0gdGhpcy5ub2RlLmdldENvbXBvbmVudHNJbkNoaWxkcmVuKFdheXBvaW50KTtcbiAgICB9XG5cbiAgICBzdGFydCgpIHtcbiAgICAgICAgXG5cbiAgICB9XG5cbn1cbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/ai/NavChaseAgent.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '7aebaBbk2VOq7Q1SbCYHVIr', 'NavChaseAgent');
// scripts/ai/NavChaseAgent.ts

// Learn TypeScript:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/typescript.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/life-cycle-callbacks.html
Object.defineProperty(exports, "__esModule", { value: true });
var IInputControls_1 = require("../input/IInputControls");
var Agent_1 = require("./Agent");
var WaypointGraph_1 = require("./navigation/WaypointGraph");
var NavChaser_1 = require("./strategies/NavChaser");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var NavChaseAgent = /** @class */ (function (_super) {
    __extends(NavChaseAgent, _super);
    function NavChaseAgent() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.attack = IInputControls_1.ButtonState.Rest;
        _this.interact = IInputControls_1.ButtonState.Rest;
        _this.waypointGraph = null;
        _this.runTowards = null;
        _this._navChaser = null;
        return _this;
        // update (dt) {}
    }
    Object.defineProperty(NavChaseAgent.prototype, "horizontalAxis", {
        get: function () {
            if (!this._navChaser)
                return 0;
            return this._navChaser.horizontalAxis;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(NavChaseAgent.prototype, "verticalAxis", {
        get: function () {
            if (!this._navChaser)
                return 0;
            return this._navChaser.verticalAxis;
        },
        enumerable: false,
        configurable: true
    });
    NavChaseAgent.prototype.agentUpdate = function (dt) {
        this._navChaser.update(dt);
    };
    // LIFE-CYCLE CALLBACKS:
    NavChaseAgent.prototype.onLoad = function () {
        this._navChaser = new NavChaser_1.NavChaser(this, this.waypointGraph, this.runTowards);
    };
    NavChaseAgent.prototype.start = function () {
        this._navChaser.start();
    };
    __decorate([
        property(WaypointGraph_1.default)
    ], NavChaseAgent.prototype, "waypointGraph", void 0);
    __decorate([
        property(cc.Node)
    ], NavChaseAgent.prototype, "runTowards", void 0);
    NavChaseAgent = __decorate([
        ccclass
    ], NavChaseAgent);
    return NavChaseAgent;
}(Agent_1.default));
exports.default = NavChaseAgent;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcYWlcXE5hdkNoYXNlQWdlbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsb0JBQW9CO0FBQ3BCLGtGQUFrRjtBQUNsRix5RkFBeUY7QUFDekYsbUJBQW1CO0FBQ25CLDRGQUE0RjtBQUM1RixtR0FBbUc7QUFDbkcsOEJBQThCO0FBQzlCLDRGQUE0RjtBQUM1RixtR0FBbUc7O0FBRW5HLDBEQUFzRTtBQUN0RSxpQ0FBNEI7QUFDNUIsNERBQXVEO0FBQ3ZELG9EQUFtRDtBQUc3QyxJQUFBLEtBQXNCLEVBQUUsQ0FBQyxVQUFVLEVBQWxDLE9BQU8sYUFBQSxFQUFFLFFBQVEsY0FBaUIsQ0FBQztBQUcxQztJQUNZLGlDQUFLO0lBRGpCO1FBQUEscUVBdUNDO1FBM0JHLFlBQU0sR0FBZ0IsNEJBQVcsQ0FBQyxJQUFJLENBQUM7UUFDdkMsY0FBUSxHQUFnQiw0QkFBVyxDQUFDLElBQUksQ0FBQztRQUV6QyxtQkFBYSxHQUFrQixJQUFJLENBQUM7UUFFcEMsZ0JBQVUsR0FBWSxJQUFJLENBQUM7UUFFbkIsZ0JBQVUsR0FBYyxJQUFJLENBQUM7O1FBbUJyQyxpQkFBaUI7SUFDckIsQ0FBQztJQW5DRyxzQkFBVyx5Q0FBYzthQUF6QjtZQUNJLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVTtnQkFBRSxPQUFPLENBQUMsQ0FBQztZQUMvQixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFBO1FBQ3pDLENBQUM7OztPQUFBO0lBQ0Qsc0JBQVcsdUNBQVk7YUFBdkI7WUFDSSxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVU7Z0JBQUUsT0FBTyxDQUFDLENBQUM7WUFDL0IsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQTtRQUN2QyxDQUFDOzs7T0FBQTtJQVNTLG1DQUFXLEdBQXJCLFVBQXNCLEVBQVU7UUFDNUIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLENBQUM7SUFDL0IsQ0FBQztJQUVELHdCQUF3QjtJQUV4Qiw4QkFBTSxHQUFOO1FBQ0ksSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLHFCQUFTLENBQzNCLElBQUksRUFDSixJQUFJLENBQUMsYUFBYSxFQUNsQixJQUFJLENBQUMsVUFBVSxDQUNsQixDQUFDO0lBQ04sQ0FBQztJQUVELDZCQUFLLEdBQUw7UUFDSSxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssRUFBRSxDQUFDO0lBQzVCLENBQUM7SUFyQkQ7UUFEQyxRQUFRLENBQUMsdUJBQWEsQ0FBQzt3REFDWTtJQUVwQztRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDO3FEQUNTO0lBakJWLGFBQWE7UUFEakMsT0FBTztPQUNhLGFBQWEsQ0F1Q2pDO0lBQUQsb0JBQUM7Q0F2Q0QsQUF1Q0MsQ0F0Q1csZUFBSyxHQXNDaEI7a0JBdkNvQixhQUFhIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy8gTGVhcm4gVHlwZVNjcmlwdDpcbi8vICAtIFtDaGluZXNlXSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL3poL3NjcmlwdGluZy90eXBlc2NyaXB0Lmh0bWxcbi8vICAtIFtFbmdsaXNoXSBodHRwOi8vd3d3LmNvY29zMmQteC5vcmcvZG9jcy9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvdHlwZXNjcmlwdC5odG1sXG4vLyBMZWFybiBBdHRyaWJ1dGU6XG4vLyAgLSBbQ2hpbmVzZV0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC96aC9zY3JpcHRpbmcvcmVmZXJlbmNlL2F0dHJpYnV0ZXMuaHRtbFxuLy8gIC0gW0VuZ2xpc2hdIGh0dHA6Ly93d3cuY29jb3MyZC14Lm9yZy9kb2NzL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9yZWZlcmVuY2UvYXR0cmlidXRlcy5odG1sXG4vLyBMZWFybiBsaWZlLWN5Y2xlIGNhbGxiYWNrczpcbi8vICAtIFtDaGluZXNlXSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL3poL3NjcmlwdGluZy9saWZlLWN5Y2xlLWNhbGxiYWNrcy5odG1sXG4vLyAgLSBbRW5nbGlzaF0gaHR0cDovL3d3dy5jb2NvczJkLXgub3JnL2RvY3MvY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcblxuaW1wb3J0IHsgSUlucHV0Q29udHJvbHMsIEJ1dHRvblN0YXRlIH0gZnJvbSBcIi4uL2lucHV0L0lJbnB1dENvbnRyb2xzXCI7XG5pbXBvcnQgQWdlbnQgZnJvbSBcIi4vQWdlbnRcIjtcbmltcG9ydCBXYXlwb2ludEdyYXBoIGZyb20gXCIuL25hdmlnYXRpb24vV2F5cG9pbnRHcmFwaFwiO1xuaW1wb3J0IHsgTmF2Q2hhc2VyIH0gZnJvbSBcIi4vc3RyYXRlZ2llcy9OYXZDaGFzZXJcIjtcbmltcG9ydCB7IE5hdldhbmRlcmVyIH0gZnJvbSBcIi4vc3RyYXRlZ2llcy9OYXZXYW5kZXJlclwiO1xuXG5jb25zdCB7Y2NjbGFzcywgcHJvcGVydHl9ID0gY2MuX2RlY29yYXRvcjtcblxuQGNjY2xhc3NcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIE5hdkNoYXNlQWdlbnRcbiAgICBleHRlbmRzIEFnZW50IFxuICAgIGltcGxlbWVudHMgSUlucHV0Q29udHJvbHN7XG4gICAgXG4gICAgcHVibGljIGdldCBob3Jpem9udGFsQXhpcygpOiBudW1iZXIgeyBcbiAgICAgICAgaWYgKCF0aGlzLl9uYXZDaGFzZXIpIHJldHVybiAwO1xuICAgICAgICByZXR1cm4gdGhpcy5fbmF2Q2hhc2VyLmhvcml6b250YWxBeGlzXG4gICAgfVxuICAgIHB1YmxpYyBnZXQgdmVydGljYWxBeGlzKCk6IG51bWJlciB7XG4gICAgICAgIGlmICghdGhpcy5fbmF2Q2hhc2VyKSByZXR1cm4gMDtcbiAgICAgICAgcmV0dXJuIHRoaXMuX25hdkNoYXNlci52ZXJ0aWNhbEF4aXNcbiAgICB9XG4gICAgYXR0YWNrOiBCdXR0b25TdGF0ZSA9IEJ1dHRvblN0YXRlLlJlc3Q7XG4gICAgaW50ZXJhY3Q6IEJ1dHRvblN0YXRlID0gQnV0dG9uU3RhdGUuUmVzdDtcbiAgICBAcHJvcGVydHkoV2F5cG9pbnRHcmFwaClcbiAgICB3YXlwb2ludEdyYXBoOiBXYXlwb2ludEdyYXBoID0gbnVsbDtcbiAgICBAcHJvcGVydHkoY2MuTm9kZSlcbiAgICBydW5Ub3dhcmRzOiBjYy5Ob2RlID0gbnVsbDtcblxuICAgIHByaXZhdGUgX25hdkNoYXNlcjogTmF2Q2hhc2VyID0gbnVsbDtcbiAgICBwcm90ZWN0ZWQgYWdlbnRVcGRhdGUoZHQ6IG51bWJlcik6IHZvaWQge1xuICAgICAgICB0aGlzLl9uYXZDaGFzZXIudXBkYXRlKGR0KTtcbiAgICB9XG5cbiAgICAvLyBMSUZFLUNZQ0xFIENBTExCQUNLUzpcblxuICAgIG9uTG9hZCgpIHtcbiAgICAgICAgdGhpcy5fbmF2Q2hhc2VyID0gbmV3IE5hdkNoYXNlcihcbiAgICAgICAgICAgIHRoaXMsXG4gICAgICAgICAgICB0aGlzLndheXBvaW50R3JhcGgsXG4gICAgICAgICAgICB0aGlzLnJ1blRvd2FyZHNcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBzdGFydCgpIHtcbiAgICAgICAgdGhpcy5fbmF2Q2hhc2VyLnN0YXJ0KCk7XG4gICAgfVxuXG4gICAgLy8gdXBkYXRlIChkdCkge31cbn1cbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/MapManager.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '56abcqTCflF1ovXRwOJOS4e', 'MapManager');
// scripts/MapManager.ts

// Learn TypeScript:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/typescript.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/life-cycle-callbacks.html
Object.defineProperty(exports, "__esModule", { value: true });
var ZSortOnLoad_1 = require("./utilities/ZSortOnLoad");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var MapManager = /** @class */ (function (_super) {
    __extends(MapManager, _super);
    function MapManager() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.objectLayerNode = null;
        _this.actorLayerNode = null;
        return _this;
        // update (dt) {}
    }
    MapManager_1 = MapManager;
    Object.defineProperty(MapManager, "Instance", {
        get: function () {
            return MapManager_1.instance;
        },
        enumerable: false,
        configurable: true
    });
    // LIFE-CYCLE CALLBACKS:
    MapManager.prototype.onLoad = function () {
        cc.director.getPhysicsManager().enabled = true;
        MapManager_1.instance = this;
        this.objectLayerNode.addComponent(ZSortOnLoad_1.default);
    };
    MapManager.prototype.start = function () {
        var actors = [];
        for (var _i = 0, _a = this.actorLayerNode.children; _i < _a.length; _i++) {
            var actor = _a[_i];
            actors.push(actor);
        }
        for (var _b = 0, actors_1 = actors; _b < actors_1.length; _b++) {
            var actor = actors_1[_b];
            // Possibly an engine bug: A node's world position can change after reparenting.
            // That's why we have to fix the position manually here.
            // Bad API :(
            var worldPosBefore = actor.convertToWorldSpaceAR(cc.Vec2.ZERO);
            actor.setParent(this.objectLayerNode);
            actor.setPosition(actor.parent.convertToNodeSpaceAR(worldPosBefore));
        }
    };
    var MapManager_1;
    MapManager.instance = null;
    __decorate([
        property(cc.Node)
    ], MapManager.prototype, "objectLayerNode", void 0);
    __decorate([
        property(cc.Node)
    ], MapManager.prototype, "actorLayerNode", void 0);
    MapManager = MapManager_1 = __decorate([
        ccclass
    ], MapManager);
    return MapManager;
}(cc.Component));
exports.default = MapManager;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcTWFwTWFuYWdlci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7QUFBQSxvQkFBb0I7QUFDcEIsa0ZBQWtGO0FBQ2xGLHlGQUF5RjtBQUN6RixtQkFBbUI7QUFDbkIsNEZBQTRGO0FBQzVGLG1HQUFtRztBQUNuRyw4QkFBOEI7QUFDOUIsNEZBQTRGO0FBQzVGLG1HQUFtRzs7QUFFbkcsdURBQWtEO0FBRTVDLElBQUEsS0FBc0IsRUFBRSxDQUFDLFVBQVUsRUFBbEMsT0FBTyxhQUFBLEVBQUUsUUFBUSxjQUFpQixDQUFDO0FBRzFDO0lBQXdDLDhCQUFZO0lBQXBEO1FBQUEscUVBb0NDO1FBN0JHLHFCQUFlLEdBQVksSUFBSSxDQUFDO1FBRWhDLG9CQUFjLEdBQVksSUFBSSxDQUFDOztRQTBCL0IsaUJBQWlCO0lBQ3JCLENBQUM7bUJBcENvQixVQUFVO0lBRzNCLHNCQUFrQixzQkFBUTthQUExQjtZQUNJLE9BQU8sWUFBVSxDQUFDLFFBQVEsQ0FBQztRQUMvQixDQUFDOzs7T0FBQTtJQU9ELHdCQUF3QjtJQUV4QiwyQkFBTSxHQUFOO1FBQ0ksRUFBRSxDQUFDLFFBQVEsQ0FBQyxpQkFBaUIsRUFBRSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUM7UUFDL0MsWUFBVSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUM7UUFDM0IsSUFBSSxDQUFDLGVBQWUsQ0FBQyxZQUFZLENBQUMscUJBQVcsQ0FBQyxDQUFDO0lBQ25ELENBQUM7SUFFRCwwQkFBSyxHQUFMO1FBQ0ksSUFBSSxNQUFNLEdBQWMsRUFBRSxDQUFDO1FBQzNCLEtBQWtCLFVBQTRCLEVBQTVCLEtBQUEsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLEVBQTVCLGNBQTRCLEVBQTVCLElBQTRCLEVBQUU7WUFBM0MsSUFBSSxLQUFLLFNBQUE7WUFDVixNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO1NBQ3RCO1FBQ0QsS0FBa0IsVUFBTSxFQUFOLGlCQUFNLEVBQU4sb0JBQU0sRUFBTixJQUFNLEVBQUU7WUFBckIsSUFBSSxLQUFLLGVBQUE7WUFDVixnRkFBZ0Y7WUFDaEYsd0RBQXdEO1lBQ3hELGFBQWE7WUFDYixJQUFJLGNBQWMsR0FBRyxLQUFLLENBQUMscUJBQXFCLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUMvRCxLQUFLLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQztZQUN0QyxLQUFLLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsb0JBQW9CLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQztTQUN4RTtJQUNMLENBQUM7O0lBL0JjLG1CQUFRLEdBQWUsSUFBSSxDQUFDO0lBSzNDO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUM7dURBQ2M7SUFFaEM7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQztzREFDYTtJQVRkLFVBQVU7UUFEOUIsT0FBTztPQUNhLFVBQVUsQ0FvQzlCO0lBQUQsaUJBQUM7Q0FwQ0QsQUFvQ0MsQ0FwQ3VDLEVBQUUsQ0FBQyxTQUFTLEdBb0NuRDtrQkFwQ29CLFVBQVUiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvLyBMZWFybiBUeXBlU2NyaXB0OlxuLy8gIC0gW0NoaW5lc2VdIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvemgvc2NyaXB0aW5nL3R5cGVzY3JpcHQuaHRtbFxuLy8gIC0gW0VuZ2xpc2hdIGh0dHA6Ly93d3cuY29jb3MyZC14Lm9yZy9kb2NzL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy90eXBlc2NyaXB0Lmh0bWxcbi8vIExlYXJuIEF0dHJpYnV0ZTpcbi8vICAtIFtDaGluZXNlXSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL3poL3NjcmlwdGluZy9yZWZlcmVuY2UvYXR0cmlidXRlcy5odG1sXG4vLyAgLSBbRW5nbGlzaF0gaHR0cDovL3d3dy5jb2NvczJkLXgub3JnL2RvY3MvY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcbi8vIExlYXJuIGxpZmUtY3ljbGUgY2FsbGJhY2tzOlxuLy8gIC0gW0NoaW5lc2VdIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvemgvc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcbi8vICAtIFtFbmdsaXNoXSBodHRwOi8vd3d3LmNvY29zMmQteC5vcmcvZG9jcy9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvbGlmZS1jeWNsZS1jYWxsYmFja3MuaHRtbFxuXG5pbXBvcnQgWlNvcnRPbkxvYWQgZnJvbSBcIi4vdXRpbGl0aWVzL1pTb3J0T25Mb2FkXCI7XG5cbmNvbnN0IHtjY2NsYXNzLCBwcm9wZXJ0eX0gPSBjYy5fZGVjb3JhdG9yO1xuXG5AY2NjbGFzc1xuZXhwb3J0IGRlZmF1bHQgY2xhc3MgTWFwTWFuYWdlciBleHRlbmRzIGNjLkNvbXBvbmVudCB7XG5cbiAgICBwcml2YXRlIHN0YXRpYyBpbnN0YW5jZTogTWFwTWFuYWdlciA9IG51bGw7XG4gICAgcHVibGljIHN0YXRpYyBnZXQgSW5zdGFuY2UoKSB7XG4gICAgICAgIHJldHVybiBNYXBNYW5hZ2VyLmluc3RhbmNlO1xuICAgIH1cbiAgICBAcHJvcGVydHkoY2MuTm9kZSlcbiAgICBvYmplY3RMYXllck5vZGU6IGNjLk5vZGUgPSBudWxsO1xuICAgIEBwcm9wZXJ0eShjYy5Ob2RlKVxuICAgIGFjdG9yTGF5ZXJOb2RlOiBjYy5Ob2RlID0gbnVsbDtcbiAgICAgICAgXG5cbiAgICAvLyBMSUZFLUNZQ0xFIENBTExCQUNLUzpcblxuICAgIG9uTG9hZCgpIHtcbiAgICAgICAgY2MuZGlyZWN0b3IuZ2V0UGh5c2ljc01hbmFnZXIoKS5lbmFibGVkID0gdHJ1ZTtcbiAgICAgICAgTWFwTWFuYWdlci5pbnN0YW5jZSA9IHRoaXM7XG4gICAgICAgIHRoaXMub2JqZWN0TGF5ZXJOb2RlLmFkZENvbXBvbmVudChaU29ydE9uTG9hZCk7XG4gICAgfVxuXG4gICAgc3RhcnQoKSB7XG4gICAgICAgIGxldCBhY3RvcnM6IGNjLk5vZGVbXSA9IFtdO1xuICAgICAgICBmb3IgKGxldCBhY3RvciBvZiB0aGlzLmFjdG9yTGF5ZXJOb2RlLmNoaWxkcmVuKSB7XG4gICAgICAgICAgICBhY3RvcnMucHVzaChhY3Rvcik7XG4gICAgICAgIH1cbiAgICAgICAgZm9yIChsZXQgYWN0b3Igb2YgYWN0b3JzKSB7XG4gICAgICAgICAgICAvLyBQb3NzaWJseSBhbiBlbmdpbmUgYnVnOiBBIG5vZGUncyB3b3JsZCBwb3NpdGlvbiBjYW4gY2hhbmdlIGFmdGVyIHJlcGFyZW50aW5nLlxuICAgICAgICAgICAgLy8gVGhhdCdzIHdoeSB3ZSBoYXZlIHRvIGZpeCB0aGUgcG9zaXRpb24gbWFudWFsbHkgaGVyZS5cbiAgICAgICAgICAgIC8vIEJhZCBBUEkgOihcbiAgICAgICAgICAgIGxldCB3b3JsZFBvc0JlZm9yZSA9IGFjdG9yLmNvbnZlcnRUb1dvcmxkU3BhY2VBUihjYy5WZWMyLlpFUk8pO1xuICAgICAgICAgICAgYWN0b3Iuc2V0UGFyZW50KHRoaXMub2JqZWN0TGF5ZXJOb2RlKTtcbiAgICAgICAgICAgIGFjdG9yLnNldFBvc2l0aW9uKGFjdG9yLnBhcmVudC5jb252ZXJ0VG9Ob2RlU3BhY2VBUih3b3JsZFBvc0JlZm9yZSkpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLy8gdXBkYXRlIChkdCkge31cbn1cbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/camera/CameraTransposer.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '18b09aWJJJK9Ik0Vsr/qJWa', 'CameraTransposer');
// scripts/camera/CameraTransposer.ts

// Learn TypeScript:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/typescript.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/life-cycle-callbacks.html
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var CameraTransposer = /** @class */ (function (_super) {
    __extends(CameraTransposer, _super);
    function CameraTransposer() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.followTarget = null;
        _this.followX = true;
        _this.followY = true;
        // @property(cc.Float)
        _this.minX = 0;
        // @property(cc.Float)
        _this.minY = -120;
        // @property(cc.Float)
        _this.maxX = 400;
        // @property(cc.Float)
        _this.maxY = 120;
        // @property(cc.Float)
        _this.offsetX = 0;
        // @property(cc.Float)
        _this.offsetY = 0;
        return _this;
    }
    // LIFE-CYCLE CALLBACKS:
    CameraTransposer.prototype.onLoad = function () {
    };
    CameraTransposer.prototype.start = function () {
    };
    CameraTransposer.prototype.update = function (dt) {
        // Not using convertToWorldSpaceAR + convertToNodeSpaceAR because
        // they are inaccurate and causes camera jitter. :(
        var cameraLocalTransform = cc.mat4();
        this.node.getLocalMatrix(cameraLocalTransform);
        var targetWorldTransform = cc.mat4();
        this.followTarget.getWorldMatrix(targetWorldTransform);
        var targetWorldTranslation = cc.v3(0, 0, 0);
        targetWorldTransform.getTranslation(targetWorldTranslation);
        var transformed = cc.v4(targetWorldTranslation.x, targetWorldTranslation.y, targetWorldTranslation.z).transformMat4(cameraLocalTransform);
        var targetPosition = cc.v2(transformed.x, transformed.y).add(cc.v2(-cc.view.getDesignResolutionSize().width / 2, -cc.view.getDesignResolutionSize().height / 2));
        targetPosition = cc.v2(clamp(this.followX ? targetPosition.x : this.node.position.x, this.minX, this.maxX), clamp(this.followY ? targetPosition.y : this.node.position.y, this.minY, this.maxY));
        this.node.position = targetPosition;
    };
    __decorate([
        property(cc.Node)
    ], CameraTransposer.prototype, "followTarget", void 0);
    __decorate([
        property(cc.Boolean)
    ], CameraTransposer.prototype, "followX", void 0);
    __decorate([
        property(cc.Boolean)
    ], CameraTransposer.prototype, "followY", void 0);
    CameraTransposer = __decorate([
        ccclass
    ], CameraTransposer);
    return CameraTransposer;
}(cc.Component));
exports.default = CameraTransposer;
function clamp(x, a, b) {
    if (x < a)
        return a;
    if (x > b)
        return b;
    return x;
}

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcY2FtZXJhXFxDYW1lcmFUcmFuc3Bvc2VyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7OztBQUFBLG9CQUFvQjtBQUNwQixrRkFBa0Y7QUFDbEYseUZBQXlGO0FBQ3pGLG1CQUFtQjtBQUNuQiw0RkFBNEY7QUFDNUYsbUdBQW1HO0FBQ25HLDhCQUE4QjtBQUM5Qiw0RkFBNEY7QUFDNUYsbUdBQW1HOztBQUU3RixJQUFBLEtBQXNCLEVBQUUsQ0FBQyxVQUFVLEVBQWxDLE9BQU8sYUFBQSxFQUFFLFFBQVEsY0FBaUIsQ0FBQztBQUcxQztJQUE4QyxvQ0FBWTtJQUExRDtRQUFBLHFFQWdEQztRQTdDRyxrQkFBWSxHQUFZLElBQUksQ0FBQztRQUU3QixhQUFPLEdBQVksSUFBSSxDQUFDO1FBRXhCLGFBQU8sR0FBWSxJQUFJLENBQUM7UUFDeEIsc0JBQXNCO1FBQ3RCLFVBQUksR0FBVyxDQUFDLENBQUM7UUFDakIsc0JBQXNCO1FBQ3RCLFVBQUksR0FBVyxDQUFDLEdBQUcsQ0FBQztRQUNwQixzQkFBc0I7UUFDdEIsVUFBSSxHQUFXLEdBQUcsQ0FBQztRQUNuQixzQkFBc0I7UUFDdEIsVUFBSSxHQUFXLEdBQUcsQ0FBQztRQUNuQixzQkFBc0I7UUFDdEIsYUFBTyxHQUFXLENBQUMsQ0FBQztRQUNwQixzQkFBc0I7UUFDdEIsYUFBTyxHQUFXLENBQUMsQ0FBQzs7SUE2QnhCLENBQUM7SUEzQkcsd0JBQXdCO0lBRXhCLGlDQUFNLEdBQU47SUFFQSxDQUFDO0lBRUQsZ0NBQUssR0FBTDtJQUVBLENBQUM7SUFFRCxpQ0FBTSxHQUFOLFVBQU8sRUFBRTtRQUNMLGlFQUFpRTtRQUNqRSxtREFBbUQ7UUFDbkQsSUFBSSxvQkFBb0IsR0FBRyxFQUFFLENBQUMsSUFBSSxFQUFFLENBQUM7UUFDckMsSUFBSSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsb0JBQW9CLENBQUMsQ0FBQztRQUMvQyxJQUFJLG9CQUFvQixHQUFHLEVBQUUsQ0FBQyxJQUFJLEVBQUUsQ0FBQztRQUNyQyxJQUFJLENBQUMsWUFBWSxDQUFDLGNBQWMsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO1FBQ3ZELElBQUksc0JBQXNCLEdBQUcsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBQzVDLG9CQUFvQixDQUFDLGNBQWMsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDO1FBQzVELElBQUksV0FBVyxHQUFHLEVBQUUsQ0FBQyxFQUFFLENBQUMsc0JBQXNCLENBQUMsQ0FBQyxFQUFFLHNCQUFzQixDQUFDLENBQUMsRUFBRSxzQkFBc0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsb0JBQW9CLENBQUMsQ0FBQztRQUMxSSxJQUFJLGNBQWMsR0FBRyxFQUFFLENBQUMsRUFBRSxDQUFDLFdBQVcsQ0FBQyxDQUFDLEVBQUUsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyx1QkFBdUIsRUFBRSxDQUFDLEtBQUssR0FBRyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLHVCQUF1QixFQUFFLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDakssY0FBYyxHQUFHLEVBQUUsQ0FBQyxFQUFFLENBQ2xCLEtBQUssQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQ25GLEtBQUssQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLENBQ3RGLENBQUM7UUFDRixJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsR0FBRyxjQUFjLENBQUM7SUFDeEMsQ0FBQztJQTVDRDtRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDOzBEQUNXO0lBRTdCO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxPQUFPLENBQUM7cURBQ0c7SUFFeEI7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLE9BQU8sQ0FBQztxREFDRztJQVBQLGdCQUFnQjtRQURwQyxPQUFPO09BQ2EsZ0JBQWdCLENBZ0RwQztJQUFELHVCQUFDO0NBaERELEFBZ0RDLENBaEQ2QyxFQUFFLENBQUMsU0FBUyxHQWdEekQ7a0JBaERvQixnQkFBZ0I7QUFrRHJDLFNBQVMsS0FBSyxDQUFDLENBQVMsRUFBRSxDQUFTLEVBQUUsQ0FBUztJQUMxQyxJQUFJLENBQUMsR0FBRyxDQUFDO1FBQUUsT0FBTyxDQUFDLENBQUM7SUFDcEIsSUFBSSxDQUFDLEdBQUcsQ0FBQztRQUFFLE9BQU8sQ0FBQyxDQUFDO0lBQ3BCLE9BQU8sQ0FBQyxDQUFDO0FBQ2IsQ0FBQyIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8vIExlYXJuIFR5cGVTY3JpcHQ6XG4vLyAgLSBbQ2hpbmVzZV0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC96aC9zY3JpcHRpbmcvdHlwZXNjcmlwdC5odG1sXG4vLyAgLSBbRW5nbGlzaF0gaHR0cDovL3d3dy5jb2NvczJkLXgub3JnL2RvY3MvY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3R5cGVzY3JpcHQuaHRtbFxuLy8gTGVhcm4gQXR0cmlidXRlOlxuLy8gIC0gW0NoaW5lc2VdIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvemgvc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcbi8vICAtIFtFbmdsaXNoXSBodHRwOi8vd3d3LmNvY29zMmQteC5vcmcvZG9jcy9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvcmVmZXJlbmNlL2F0dHJpYnV0ZXMuaHRtbFxuLy8gTGVhcm4gbGlmZS1jeWNsZSBjYWxsYmFja3M6XG4vLyAgLSBbQ2hpbmVzZV0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC96aC9zY3JpcHRpbmcvbGlmZS1jeWNsZS1jYWxsYmFja3MuaHRtbFxuLy8gIC0gW0VuZ2xpc2hdIGh0dHA6Ly93d3cuY29jb3MyZC14Lm9yZy9kb2NzL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9saWZlLWN5Y2xlLWNhbGxiYWNrcy5odG1sXG5cbmNvbnN0IHtjY2NsYXNzLCBwcm9wZXJ0eX0gPSBjYy5fZGVjb3JhdG9yO1xuXG5AY2NjbGFzc1xuZXhwb3J0IGRlZmF1bHQgY2xhc3MgQ2FtZXJhVHJhbnNwb3NlciBleHRlbmRzIGNjLkNvbXBvbmVudCB7XG5cbiAgICBAcHJvcGVydHkoY2MuTm9kZSlcbiAgICBmb2xsb3dUYXJnZXQ6IGNjLk5vZGUgPSBudWxsO1xuICAgIEBwcm9wZXJ0eShjYy5Cb29sZWFuKVxuICAgIGZvbGxvd1g6IGJvb2xlYW4gPSB0cnVlO1xuICAgIEBwcm9wZXJ0eShjYy5Cb29sZWFuKVxuICAgIGZvbGxvd1k6IGJvb2xlYW4gPSB0cnVlO1xuICAgIC8vIEBwcm9wZXJ0eShjYy5GbG9hdClcbiAgICBtaW5YOiBudW1iZXIgPSAwO1xuICAgIC8vIEBwcm9wZXJ0eShjYy5GbG9hdClcbiAgICBtaW5ZOiBudW1iZXIgPSAtMTIwO1xuICAgIC8vIEBwcm9wZXJ0eShjYy5GbG9hdClcbiAgICBtYXhYOiBudW1iZXIgPSA0MDA7XG4gICAgLy8gQHByb3BlcnR5KGNjLkZsb2F0KVxuICAgIG1heFk6IG51bWJlciA9IDEyMDtcbiAgICAvLyBAcHJvcGVydHkoY2MuRmxvYXQpXG4gICAgb2Zmc2V0WDogbnVtYmVyID0gMDtcbiAgICAvLyBAcHJvcGVydHkoY2MuRmxvYXQpXG4gICAgb2Zmc2V0WTogbnVtYmVyID0gMDtcblxuICAgIC8vIExJRkUtQ1lDTEUgQ0FMTEJBQ0tTOlxuXG4gICAgb25Mb2FkKCkge1xuICAgICAgICBcbiAgICB9XG5cbiAgICBzdGFydCAoKSB7XG4gICAgICAgIFxuICAgIH1cblxuICAgIHVwZGF0ZShkdCkge1xuICAgICAgICAvLyBOb3QgdXNpbmcgY29udmVydFRvV29ybGRTcGFjZUFSICsgY29udmVydFRvTm9kZVNwYWNlQVIgYmVjYXVzZVxuICAgICAgICAvLyB0aGV5IGFyZSBpbmFjY3VyYXRlIGFuZCBjYXVzZXMgY2FtZXJhIGppdHRlci4gOihcbiAgICAgICAgbGV0IGNhbWVyYUxvY2FsVHJhbnNmb3JtID0gY2MubWF0NCgpO1xuICAgICAgICB0aGlzLm5vZGUuZ2V0TG9jYWxNYXRyaXgoY2FtZXJhTG9jYWxUcmFuc2Zvcm0pO1xuICAgICAgICBsZXQgdGFyZ2V0V29ybGRUcmFuc2Zvcm0gPSBjYy5tYXQ0KCk7XG4gICAgICAgIHRoaXMuZm9sbG93VGFyZ2V0LmdldFdvcmxkTWF0cml4KHRhcmdldFdvcmxkVHJhbnNmb3JtKTtcbiAgICAgICAgbGV0IHRhcmdldFdvcmxkVHJhbnNsYXRpb24gPSBjYy52MygwLCAwLCAwKTtcbiAgICAgICAgdGFyZ2V0V29ybGRUcmFuc2Zvcm0uZ2V0VHJhbnNsYXRpb24odGFyZ2V0V29ybGRUcmFuc2xhdGlvbik7XG4gICAgICAgIGxldCB0cmFuc2Zvcm1lZCA9IGNjLnY0KHRhcmdldFdvcmxkVHJhbnNsYXRpb24ueCwgdGFyZ2V0V29ybGRUcmFuc2xhdGlvbi55LCB0YXJnZXRXb3JsZFRyYW5zbGF0aW9uLnopLnRyYW5zZm9ybU1hdDQoY2FtZXJhTG9jYWxUcmFuc2Zvcm0pO1xuICAgICAgICBsZXQgdGFyZ2V0UG9zaXRpb24gPSBjYy52Mih0cmFuc2Zvcm1lZC54LCB0cmFuc2Zvcm1lZC55KS5hZGQoY2MudjIoLWNjLnZpZXcuZ2V0RGVzaWduUmVzb2x1dGlvblNpemUoKS53aWR0aCAvIDIsIC1jYy52aWV3LmdldERlc2lnblJlc29sdXRpb25TaXplKCkuaGVpZ2h0IC8gMikpO1xuICAgICAgICB0YXJnZXRQb3NpdGlvbiA9IGNjLnYyKFxuICAgICAgICAgICAgY2xhbXAodGhpcy5mb2xsb3dYID8gdGFyZ2V0UG9zaXRpb24ueCA6IHRoaXMubm9kZS5wb3NpdGlvbi54LCB0aGlzLm1pblgsIHRoaXMubWF4WCksXG4gICAgICAgICAgICBjbGFtcCh0aGlzLmZvbGxvd1kgPyB0YXJnZXRQb3NpdGlvbi55IDogdGhpcy5ub2RlLnBvc2l0aW9uLnksIHRoaXMubWluWSwgdGhpcy5tYXhZKVxuICAgICAgICApO1xuICAgICAgICB0aGlzLm5vZGUucG9zaXRpb24gPSB0YXJnZXRQb3NpdGlvbjtcbiAgICB9XG59XG5cbmZ1bmN0aW9uIGNsYW1wKHg6IG51bWJlciwgYTogbnVtYmVyLCBiOiBudW1iZXIpIHtcbiAgICBpZiAoeCA8IGEpIHJldHVybiBhO1xuICAgIGlmICh4ID4gYikgcmV0dXJuIGI7XG4gICAgcmV0dXJuIHg7XG59Il19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/ai/strategies/Coward.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '0f1e55DmctOVp8eQg/uquO9', 'Coward');
// scripts/ai/strategies/Coward.ts

Object.defineProperty(exports, "__esModule", { value: true });
exports.Coward = void 0;
var AgentStrategy_1 = require("./AgentStrategy");
var Coward = /** @class */ (function (_super) {
    __extends(Coward, _super);
    /**
     *
     * @param _agent The agent using the strategy.
     * @param _runAwayFrom The node for the agent to run away from.
     */
    function Coward(_agent, _runAwayFrom) {
        var _this = _super.call(this) || this;
        _this._agent = null;
        _this._runAwayFrom = null;
        _this._moveAxis2D = cc.Vec2.ZERO;
        _this._agent = _agent;
        _this._runAwayFrom = _runAwayFrom;
        return _this;
    }
    Object.defineProperty(Coward.prototype, "awayFromTarget", {
        get: function () {
            return this._agent.node.position.sub(this._runAwayFrom.position).normalize();
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Coward.prototype, "distanceFromTarget", {
        get: function () {
            return this._runAwayFrom.position.sub(this._agent.node.position).mag();
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Coward.prototype, "horizontalAxis", {
        get: function () {
            return this._moveAxis2D.x;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Coward.prototype, "verticalAxis", {
        get: function () {
            return this._moveAxis2D.y;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Coward.prototype, "attack", {
        get: function () {
            throw new Error("Method not implemented.");
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Coward.prototype, "interact", {
        get: function () {
            throw new Error("Method not implemented.");
        },
        enumerable: false,
        configurable: true
    });
    Coward.prototype.start = function () {
    };
    Coward.prototype.update = function (dt) {
        this._moveAxis2D = this.awayFromTarget;
    };
    return Coward;
}(AgentStrategy_1.AI.Strategy));
exports.Coward = Coward;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcYWlcXHN0cmF0ZWdpZXNcXENvd2FyZC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUVBLGlEQUFxQztBQUVyQztJQUE0QiwwQkFBVztJQUduQzs7OztPQUlHO0lBQ0gsZ0JBQVksTUFBYSxFQUFFLFlBQXFCO1FBQWhELFlBQ0ksaUJBQU8sU0FHVjtRQVhPLFlBQU0sR0FBVSxJQUFJLENBQUM7UUFDckIsa0JBQVksR0FBWSxJQUFJLENBQUM7UUFZN0IsaUJBQVcsR0FBWSxFQUFFLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztRQUp4QyxLQUFJLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQztRQUNyQixLQUFJLENBQUMsWUFBWSxHQUFHLFlBQVksQ0FBQzs7SUFDckMsQ0FBQztJQUlELHNCQUFXLGtDQUFjO2FBQXpCO1lBQ0ksT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLENBQUMsU0FBUyxFQUFFLENBQUM7UUFDakYsQ0FBQzs7O09BQUE7SUFFRCxzQkFBVyxzQ0FBa0I7YUFBN0I7WUFDSSxPQUFPLElBQUksQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQTtRQUMxRSxDQUFDOzs7T0FBQTtJQUVELHNCQUFXLGtDQUFjO2FBQXpCO1lBQ0ksT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQztRQUM5QixDQUFDOzs7T0FBQTtJQUNELHNCQUFXLGdDQUFZO2FBQXZCO1lBQ0ksT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQztRQUM5QixDQUFDOzs7T0FBQTtJQUNELHNCQUFXLDBCQUFNO2FBQWpCO1lBQ0ksTUFBTSxJQUFJLEtBQUssQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDO1FBQy9DLENBQUM7OztPQUFBO0lBQ0Qsc0JBQVcsNEJBQVE7YUFBbkI7WUFDSSxNQUFNLElBQUksS0FBSyxDQUFDLHlCQUF5QixDQUFDLENBQUM7UUFDL0MsQ0FBQzs7O09BQUE7SUFDTSxzQkFBSyxHQUFaO0lBRUEsQ0FBQztJQUNNLHVCQUFNLEdBQWIsVUFBYyxFQUFVO1FBQ3BCLElBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQztJQUMzQyxDQUFDO0lBRUwsYUFBQztBQUFELENBM0NBLEFBMkNDLENBM0MyQixrQkFBRSxDQUFDLFFBQVEsR0EyQ3RDO0FBM0NZLHdCQUFNIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQnV0dG9uU3RhdGUgfSBmcm9tIFwiLi4vLi4vaW5wdXQvSUlucHV0Q29udHJvbHNcIjtcbmltcG9ydCBBZ2VudCBmcm9tIFwiLi4vQWdlbnRcIjtcbmltcG9ydCB7IEFJIH0gZnJvbSBcIi4vQWdlbnRTdHJhdGVneVwiO1xuXG5leHBvcnQgY2xhc3MgQ293YXJkIGV4dGVuZHMgQUkuU3RyYXRlZ3l7XG4gICAgcHJpdmF0ZSBfYWdlbnQ6IEFnZW50ID0gbnVsbDtcbiAgICBwcml2YXRlIF9ydW5Bd2F5RnJvbTogY2MuTm9kZSA9IG51bGw7XG4gICAgLyoqXG4gICAgICogXG4gICAgICogQHBhcmFtIF9hZ2VudCBUaGUgYWdlbnQgdXNpbmcgdGhlIHN0cmF0ZWd5LlxuICAgICAqIEBwYXJhbSBfcnVuQXdheUZyb20gVGhlIG5vZGUgZm9yIHRoZSBhZ2VudCB0byBydW4gYXdheSBmcm9tLlxuICAgICAqL1xuICAgIGNvbnN0cnVjdG9yKF9hZ2VudDogQWdlbnQsIF9ydW5Bd2F5RnJvbTogY2MuTm9kZSkge1xuICAgICAgICBzdXBlcigpO1xuICAgICAgICB0aGlzLl9hZ2VudCA9IF9hZ2VudDtcbiAgICAgICAgdGhpcy5fcnVuQXdheUZyb20gPSBfcnVuQXdheUZyb207XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBfbW92ZUF4aXMyRDogY2MuVmVjMiA9IGNjLlZlYzIuWkVSTztcblxuICAgIHB1YmxpYyBnZXQgYXdheUZyb21UYXJnZXQoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9hZ2VudC5ub2RlLnBvc2l0aW9uLnN1Yih0aGlzLl9ydW5Bd2F5RnJvbS5wb3NpdGlvbikubm9ybWFsaXplKCk7XG4gICAgfVxuXG4gICAgcHVibGljIGdldCBkaXN0YW5jZUZyb21UYXJnZXQoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9ydW5Bd2F5RnJvbS5wb3NpdGlvbi5zdWIodGhpcy5fYWdlbnQubm9kZS5wb3NpdGlvbikubWFnKClcbiAgICB9XG4gICAgXG4gICAgcHVibGljIGdldCBob3Jpem9udGFsQXhpcygpOiBudW1iZXIge1xuICAgICAgICByZXR1cm4gdGhpcy5fbW92ZUF4aXMyRC54O1xuICAgIH1cbiAgICBwdWJsaWMgZ2V0IHZlcnRpY2FsQXhpcygpOiBudW1iZXIge1xuICAgICAgICByZXR1cm4gdGhpcy5fbW92ZUF4aXMyRC55O1xuICAgIH1cbiAgICBwdWJsaWMgZ2V0IGF0dGFjaygpOiBCdXR0b25TdGF0ZSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihcIk1ldGhvZCBub3QgaW1wbGVtZW50ZWQuXCIpO1xuICAgIH1cbiAgICBwdWJsaWMgZ2V0IGludGVyYWN0KCk6IEJ1dHRvblN0YXRlIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiTWV0aG9kIG5vdCBpbXBsZW1lbnRlZC5cIik7XG4gICAgfVxuICAgIHB1YmxpYyBzdGFydCgpOiB2b2lkIHtcbiAgICAgICAgXG4gICAgfVxuICAgIHB1YmxpYyB1cGRhdGUoZHQ6IG51bWJlcik6IHZvaWQge1xuICAgICAgICB0aGlzLl9tb3ZlQXhpczJEID0gdGhpcy5hd2F5RnJvbVRhcmdldDtcbiAgICB9XG5cbn0iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/input/KeyboardControls.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '2ff4dcmThZMKKaXEWb71524', 'KeyboardControls');
// scripts/input/KeyboardControls.ts

// Learn TypeScript:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/typescript.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/life-cycle-callbacks.html
Object.defineProperty(exports, "__esModule", { value: true });
var IInputControls_1 = require("./IInputControls");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var KeyboardControls = /** @class */ (function (_super) {
    __extends(KeyboardControls, _super);
    function KeyboardControls() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this._hAxis = 0;
        _this._vAxis = 0;
        _this._zKey = IInputControls_1.ButtonState.Rest;
        return _this;
    }
    Object.defineProperty(KeyboardControls.prototype, "horizontalAxis", {
        get: function () { return this._hAxis; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(KeyboardControls.prototype, "verticalAxis", {
        get: function () { return this._vAxis; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(KeyboardControls.prototype, "attack", {
        get: function () { return this._zKey; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(KeyboardControls.prototype, "interact", {
        get: function () { return this._zKey; },
        enumerable: false,
        configurable: true
    });
    // LIFE-CYCLE CALLBACKS:
    KeyboardControls.prototype.onLoad = function () { };
    KeyboardControls.prototype.start = function () {
        cc.systemEvent.on(cc.SystemEvent.EventType.KEY_DOWN, this.onKeyDown, this);
        cc.systemEvent.on(cc.SystemEvent.EventType.KEY_UP, this.onKeyUp, this);
    };
    // update (dt) {}
    KeyboardControls.prototype.onKeyDown = function (event) {
        switch (event.keyCode) {
            case cc.macro.KEY.up:
                // case cc.macro.KEY.w:
                this._vAxis++;
                break;
            case cc.macro.KEY.down:
                // case cc.macro.KEY.s:
                this._vAxis--;
                break;
            case cc.macro.KEY.right:
                // case cc.macro.KEY.d:
                this._hAxis++;
                break;
            case cc.macro.KEY.left:
                // case cc.macro.KEY.a:
                this._hAxis--;
                break;
        }
        this._vAxis = clamp(this._vAxis);
        this._hAxis = clamp(this._hAxis);
        switch (this._zKey) {
            case IInputControls_1.ButtonState.Rest:
            case IInputControls_1.ButtonState.Released:
                this._zKey = IInputControls_1.ButtonState.Pressed;
                break;
            case IInputControls_1.ButtonState.Pressed:
            case IInputControls_1.ButtonState.Held:
                this._zKey = IInputControls_1.ButtonState.Held;
                break;
        }
    };
    KeyboardControls.prototype.onKeyUp = function (event) {
        switch (event.keyCode) {
            case cc.macro.KEY.up:
                // case cc.macro.KEY.w:
                this._vAxis--;
                break;
            case cc.macro.KEY.down:
                // case cc.macro.KEY.s:
                this._vAxis++;
                break;
            case cc.macro.KEY.right:
                // case cc.macro.KEY.d:
                this._hAxis--;
                break;
            case cc.macro.KEY.left:
                // case cc.macro.KEY.a:
                this._hAxis++;
                break;
        }
        this._vAxis = clamp(this._vAxis);
        this._hAxis = clamp(this._hAxis);
        switch (this._zKey) {
            case IInputControls_1.ButtonState.Rest:
            case IInputControls_1.ButtonState.Released:
                this._zKey = IInputControls_1.ButtonState.Rest;
                break;
            case IInputControls_1.ButtonState.Pressed:
            case IInputControls_1.ButtonState.Held:
                this._zKey = IInputControls_1.ButtonState.Released;
                break;
        }
    };
    KeyboardControls = __decorate([
        ccclass
    ], KeyboardControls);
    return KeyboardControls;
}(cc.Component));
exports.default = KeyboardControls;
function clamp(value, a, b) {
    if (a === void 0) { a = -1; }
    if (b === void 0) { b = 1; }
    if (value < a)
        return a;
    if (value > b)
        return b;
    return value;
}

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcaW5wdXRcXEtleWJvYXJkQ29udHJvbHMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsb0JBQW9CO0FBQ3BCLGtGQUFrRjtBQUNsRix5RkFBeUY7QUFDekYsbUJBQW1CO0FBQ25CLDRGQUE0RjtBQUM1RixtR0FBbUc7QUFDbkcsOEJBQThCO0FBQzlCLDRGQUE0RjtBQUM1RixtR0FBbUc7O0FBRW5HLG1EQUErRDtBQUV6RCxJQUFBLEtBQXNCLEVBQUUsQ0FBQyxVQUFVLEVBQWxDLE9BQU8sYUFBQSxFQUFFLFFBQVEsY0FBaUIsQ0FBQztBQUcxQztJQUNZLG9DQUFZO0lBRHhCO1FBQUEscUVBNkZDO1FBekZXLFlBQU0sR0FBVyxDQUFDLENBQUM7UUFHbkIsWUFBTSxHQUFXLENBQUMsQ0FBQztRQUduQixXQUFLLEdBQWdCLDRCQUFXLENBQUMsSUFBSSxDQUFDOztJQW1GbEQsQ0FBQztJQXhGRyxzQkFBVyw0Q0FBYzthQUF6QixjQUFzQyxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUEsQ0FBQyxDQUFDOzs7T0FBQTtJQUcxRCxzQkFBVywwQ0FBWTthQUF2QixjQUFvQyxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUEsQ0FBQyxDQUFDOzs7T0FBQTtJQUd4RCxzQkFBVyxvQ0FBTTthQUFqQixjQUFtQyxPQUFPLElBQUksQ0FBQyxLQUFLLENBQUEsQ0FBQyxDQUFDOzs7T0FBQTtJQUN0RCxzQkFBVyxzQ0FBUTthQUFuQixjQUFxQyxPQUFPLElBQUksQ0FBQyxLQUFLLENBQUEsQ0FBQyxDQUFDOzs7T0FBQTtJQUV4RCx3QkFBd0I7SUFFeEIsaUNBQU0sR0FBTixjQUFXLENBQUM7SUFFWixnQ0FBSyxHQUFMO1FBQ0ksRUFBRSxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDM0UsRUFBRSxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDM0UsQ0FBQztJQUVELGlCQUFpQjtJQUVqQixvQ0FBUyxHQUFULFVBQVUsS0FBNkI7UUFDbkMsUUFBUSxLQUFLLENBQUMsT0FBTyxFQUFFO1lBQ25CLEtBQUssRUFBRSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsRUFBRTtnQkFDcEIsdUJBQXVCO2dCQUNuQixJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7Z0JBQ2QsTUFBTTtZQUNWLEtBQUssRUFBRSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsSUFBSTtnQkFDdEIsdUJBQXVCO2dCQUNuQixJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7Z0JBQ2QsTUFBTTtZQUNWLEtBQUssRUFBRSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsS0FBSztnQkFDdkIsdUJBQXVCO2dCQUNuQixJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7Z0JBQ2QsTUFBTTtZQUNWLEtBQUssRUFBRSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsSUFBSTtnQkFDdEIsdUJBQXVCO2dCQUNuQixJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7Z0JBQ2QsTUFBTTtTQUNiO1FBQ0QsSUFBSSxDQUFDLE1BQU0sR0FBRyxLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ2pDLElBQUksQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUVqQyxRQUFRLElBQUksQ0FBQyxLQUFLLEVBQUU7WUFDaEIsS0FBSyw0QkFBVyxDQUFDLElBQUksQ0FBQztZQUN0QixLQUFLLDRCQUFXLENBQUMsUUFBUTtnQkFDckIsSUFBSSxDQUFDLEtBQUssR0FBRyw0QkFBVyxDQUFDLE9BQU8sQ0FBQztnQkFDakMsTUFBTTtZQUNWLEtBQUssNEJBQVcsQ0FBQyxPQUFPLENBQUM7WUFDekIsS0FBSyw0QkFBVyxDQUFDLElBQUk7Z0JBQ2pCLElBQUksQ0FBQyxLQUFLLEdBQUcsNEJBQVcsQ0FBQyxJQUFJLENBQUM7Z0JBQzlCLE1BQU07U0FDYjtJQUdMLENBQUM7SUFDRCxrQ0FBTyxHQUFQLFVBQVEsS0FBNkI7UUFDakMsUUFBUSxLQUFLLENBQUMsT0FBTyxFQUFFO1lBQ25CLEtBQUssRUFBRSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsRUFBRTtnQkFDcEIsdUJBQXVCO2dCQUNuQixJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7Z0JBQ2QsTUFBTTtZQUNWLEtBQUssRUFBRSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsSUFBSTtnQkFDdEIsdUJBQXVCO2dCQUNuQixJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7Z0JBQ2QsTUFBTTtZQUNWLEtBQUssRUFBRSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsS0FBSztnQkFDdkIsdUJBQXVCO2dCQUNuQixJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7Z0JBQ2QsTUFBTTtZQUNWLEtBQUssRUFBRSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsSUFBSTtnQkFDdEIsdUJBQXVCO2dCQUNuQixJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7Z0JBQ2QsTUFBTTtTQUNiO1FBQ0QsSUFBSSxDQUFDLE1BQU0sR0FBRyxLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ2pDLElBQUksQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUVqQyxRQUFRLElBQUksQ0FBQyxLQUFLLEVBQUU7WUFDaEIsS0FBSyw0QkFBVyxDQUFDLElBQUksQ0FBQztZQUN0QixLQUFLLDRCQUFXLENBQUMsUUFBUTtnQkFDckIsSUFBSSxDQUFDLEtBQUssR0FBRyw0QkFBVyxDQUFDLElBQUksQ0FBQztnQkFDOUIsTUFBTTtZQUNWLEtBQUssNEJBQVcsQ0FBQyxPQUFPLENBQUM7WUFDekIsS0FBSyw0QkFBVyxDQUFDLElBQUk7Z0JBQ2pCLElBQUksQ0FBQyxLQUFLLEdBQUcsNEJBQVcsQ0FBQyxRQUFRLENBQUM7Z0JBQ2xDLE1BQU07U0FDYjtJQUNMLENBQUM7SUE1RmdCLGdCQUFnQjtRQURwQyxPQUFPO09BQ2EsZ0JBQWdCLENBNkZwQztJQUFELHVCQUFDO0NBN0ZELEFBNkZDLENBNUZXLEVBQUUsQ0FBQyxTQUFTLEdBNEZ2QjtrQkE3Rm9CLGdCQUFnQjtBQStGckMsU0FBUyxLQUFLLENBQUMsS0FBYSxFQUFFLENBQWMsRUFBRSxDQUFhO0lBQTdCLGtCQUFBLEVBQUEsS0FBYSxDQUFDO0lBQUUsa0JBQUEsRUFBQSxLQUFhO0lBQ3ZELElBQUksS0FBSyxHQUFHLENBQUM7UUFBRSxPQUFPLENBQUMsQ0FBQztJQUN4QixJQUFJLEtBQUssR0FBRyxDQUFDO1FBQUUsT0FBTyxDQUFDLENBQUM7SUFDeEIsT0FBTyxLQUFLLENBQUM7QUFDakIsQ0FBQyIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8vIExlYXJuIFR5cGVTY3JpcHQ6XG4vLyAgLSBbQ2hpbmVzZV0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC96aC9zY3JpcHRpbmcvdHlwZXNjcmlwdC5odG1sXG4vLyAgLSBbRW5nbGlzaF0gaHR0cDovL3d3dy5jb2NvczJkLXgub3JnL2RvY3MvY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3R5cGVzY3JpcHQuaHRtbFxuLy8gTGVhcm4gQXR0cmlidXRlOlxuLy8gIC0gW0NoaW5lc2VdIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvemgvc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcbi8vICAtIFtFbmdsaXNoXSBodHRwOi8vd3d3LmNvY29zMmQteC5vcmcvZG9jcy9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvcmVmZXJlbmNlL2F0dHJpYnV0ZXMuaHRtbFxuLy8gTGVhcm4gbGlmZS1jeWNsZSBjYWxsYmFja3M6XG4vLyAgLSBbQ2hpbmVzZV0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC96aC9zY3JpcHRpbmcvbGlmZS1jeWNsZS1jYWxsYmFja3MuaHRtbFxuLy8gIC0gW0VuZ2xpc2hdIGh0dHA6Ly93d3cuY29jb3MyZC14Lm9yZy9kb2NzL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9saWZlLWN5Y2xlLWNhbGxiYWNrcy5odG1sXG5cbmltcG9ydCB7IEJ1dHRvblN0YXRlLCBJSW5wdXRDb250cm9scyB9IGZyb20gXCIuL0lJbnB1dENvbnRyb2xzXCI7XG5cbmNvbnN0IHtjY2NsYXNzLCBwcm9wZXJ0eX0gPSBjYy5fZGVjb3JhdG9yO1xuXG5AY2NjbGFzc1xuZXhwb3J0IGRlZmF1bHQgY2xhc3MgS2V5Ym9hcmRDb250cm9sc1xuICAgIGV4dGVuZHMgY2MuQ29tcG9uZW50XG4gICAgaW1wbGVtZW50cyBJSW5wdXRDb250cm9scyB7XG4gICAgXG4gICAgcHJpdmF0ZSBfaEF4aXM6IG51bWJlciA9IDA7XG4gICAgcHVibGljIGdldCBob3Jpem9udGFsQXhpcygpOiBudW1iZXIgeyByZXR1cm4gdGhpcy5faEF4aXMgfVxuXG4gICAgcHJpdmF0ZSBfdkF4aXM6IG51bWJlciA9IDA7XG4gICAgcHVibGljIGdldCB2ZXJ0aWNhbEF4aXMoKTogbnVtYmVyIHsgcmV0dXJuIHRoaXMuX3ZBeGlzIH1cblxuICAgIHByaXZhdGUgX3pLZXk6IEJ1dHRvblN0YXRlID0gQnV0dG9uU3RhdGUuUmVzdDtcbiAgICBwdWJsaWMgZ2V0IGF0dGFjaygpOiBCdXR0b25TdGF0ZSB7IHJldHVybiB0aGlzLl96S2V5IH1cbiAgICBwdWJsaWMgZ2V0IGludGVyYWN0KCk6IEJ1dHRvblN0YXRlIHsgcmV0dXJuIHRoaXMuX3pLZXkgfVxuICAgIFxuICAgIC8vIExJRkUtQ1lDTEUgQ0FMTEJBQ0tTOlxuXG4gICAgb25Mb2FkICgpIHt9XG5cbiAgICBzdGFydCgpIHtcbiAgICAgICAgY2Muc3lzdGVtRXZlbnQub24oY2MuU3lzdGVtRXZlbnQuRXZlbnRUeXBlLktFWV9ET1dOLCB0aGlzLm9uS2V5RG93biwgdGhpcyk7XG4gICAgICAgIGNjLnN5c3RlbUV2ZW50Lm9uKGNjLlN5c3RlbUV2ZW50LkV2ZW50VHlwZS5LRVlfVVAsIHRoaXMub25LZXlVcCwgdGhpcyk7XG4gICAgfVxuXG4gICAgLy8gdXBkYXRlIChkdCkge31cblxuICAgIG9uS2V5RG93bihldmVudDogY2MuRXZlbnQuRXZlbnRLZXlib2FyZCkge1xuICAgICAgICBzd2l0Y2ggKGV2ZW50LmtleUNvZGUpIHtcbiAgICAgICAgICAgIGNhc2UgY2MubWFjcm8uS0VZLnVwOlxuICAgICAgICAgICAgLy8gY2FzZSBjYy5tYWNyby5LRVkudzpcbiAgICAgICAgICAgICAgICB0aGlzLl92QXhpcysrO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSBjYy5tYWNyby5LRVkuZG93bjpcbiAgICAgICAgICAgIC8vIGNhc2UgY2MubWFjcm8uS0VZLnM6XG4gICAgICAgICAgICAgICAgdGhpcy5fdkF4aXMtLTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgY2MubWFjcm8uS0VZLnJpZ2h0OlxuICAgICAgICAgICAgLy8gY2FzZSBjYy5tYWNyby5LRVkuZDpcbiAgICAgICAgICAgICAgICB0aGlzLl9oQXhpcysrO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSBjYy5tYWNyby5LRVkubGVmdDpcbiAgICAgICAgICAgIC8vIGNhc2UgY2MubWFjcm8uS0VZLmE6XG4gICAgICAgICAgICAgICAgdGhpcy5faEF4aXMtLTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuICAgICAgICB0aGlzLl92QXhpcyA9IGNsYW1wKHRoaXMuX3ZBeGlzKTtcbiAgICAgICAgdGhpcy5faEF4aXMgPSBjbGFtcCh0aGlzLl9oQXhpcyk7XG5cbiAgICAgICAgc3dpdGNoICh0aGlzLl96S2V5KSB7XG4gICAgICAgICAgICBjYXNlIEJ1dHRvblN0YXRlLlJlc3Q6XG4gICAgICAgICAgICBjYXNlIEJ1dHRvblN0YXRlLlJlbGVhc2VkOlxuICAgICAgICAgICAgICAgIHRoaXMuX3pLZXkgPSBCdXR0b25TdGF0ZS5QcmVzc2VkO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSBCdXR0b25TdGF0ZS5QcmVzc2VkOlxuICAgICAgICAgICAgY2FzZSBCdXR0b25TdGF0ZS5IZWxkOlxuICAgICAgICAgICAgICAgIHRoaXMuX3pLZXkgPSBCdXR0b25TdGF0ZS5IZWxkO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG5cblxuICAgIH1cbiAgICBvbktleVVwKGV2ZW50OiBjYy5FdmVudC5FdmVudEtleWJvYXJkKSB7XG4gICAgICAgIHN3aXRjaCAoZXZlbnQua2V5Q29kZSkge1xuICAgICAgICAgICAgY2FzZSBjYy5tYWNyby5LRVkudXA6XG4gICAgICAgICAgICAvLyBjYXNlIGNjLm1hY3JvLktFWS53OlxuICAgICAgICAgICAgICAgIHRoaXMuX3ZBeGlzLS07XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlIGNjLm1hY3JvLktFWS5kb3duOlxuICAgICAgICAgICAgLy8gY2FzZSBjYy5tYWNyby5LRVkuczpcbiAgICAgICAgICAgICAgICB0aGlzLl92QXhpcysrO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSBjYy5tYWNyby5LRVkucmlnaHQ6XG4gICAgICAgICAgICAvLyBjYXNlIGNjLm1hY3JvLktFWS5kOlxuICAgICAgICAgICAgICAgIHRoaXMuX2hBeGlzLS07XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlIGNjLm1hY3JvLktFWS5sZWZ0OlxuICAgICAgICAgICAgLy8gY2FzZSBjYy5tYWNyby5LRVkuYTpcbiAgICAgICAgICAgICAgICB0aGlzLl9oQXhpcysrO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuX3ZBeGlzID0gY2xhbXAodGhpcy5fdkF4aXMpO1xuICAgICAgICB0aGlzLl9oQXhpcyA9IGNsYW1wKHRoaXMuX2hBeGlzKTtcbiAgICAgICAgXG4gICAgICAgIHN3aXRjaCAodGhpcy5fektleSkge1xuICAgICAgICAgICAgY2FzZSBCdXR0b25TdGF0ZS5SZXN0OlxuICAgICAgICAgICAgY2FzZSBCdXR0b25TdGF0ZS5SZWxlYXNlZDpcbiAgICAgICAgICAgICAgICB0aGlzLl96S2V5ID0gQnV0dG9uU3RhdGUuUmVzdDtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgQnV0dG9uU3RhdGUuUHJlc3NlZDpcbiAgICAgICAgICAgIGNhc2UgQnV0dG9uU3RhdGUuSGVsZDpcbiAgICAgICAgICAgICAgICB0aGlzLl96S2V5ID0gQnV0dG9uU3RhdGUuUmVsZWFzZWQ7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cbiAgICB9XG59XG5cbmZ1bmN0aW9uIGNsYW1wKHZhbHVlOiBudW1iZXIsIGE6IG51bWJlciA9IC0xLCBiOiBudW1iZXIgPSAxKSB7XG4gICAgaWYgKHZhbHVlIDwgYSkgcmV0dXJuIGE7XG4gICAgaWYgKHZhbHVlID4gYikgcmV0dXJuIGI7XG4gICAgcmV0dXJuIHZhbHVlO1xufSJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/utilities/ZSorter.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '99e25O3dctP9r6blHhMnMae', 'ZSorter');
// scripts/utilities/ZSorter.ts

// Learn TypeScript:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/typescript.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/life-cycle-callbacks.html
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
/**
 * A component that makes a node render in a way such that it appears behind nodes
 * that are located below it.
 */
var ZSorter = /** @class */ (function (_super) {
    __extends(ZSorter, _super);
    function ZSorter() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    ZSorter.prototype.update = function (dt) {
        this.node.zIndex = 10000 + -this.node.y;
    };
    ZSorter = __decorate([
        ccclass
    ], ZSorter);
    return ZSorter;
}(cc.Component));
exports.default = ZSorter;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcdXRpbGl0aWVzXFxaU29ydGVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7OztBQUFBLG9CQUFvQjtBQUNwQixrRkFBa0Y7QUFDbEYseUZBQXlGO0FBQ3pGLG1CQUFtQjtBQUNuQiw0RkFBNEY7QUFDNUYsbUdBQW1HO0FBQ25HLDhCQUE4QjtBQUM5Qiw0RkFBNEY7QUFDNUYsbUdBQW1HOztBQUU3RixJQUFBLEtBQXdCLEVBQUUsQ0FBQyxVQUFVLEVBQW5DLE9BQU8sYUFBQSxFQUFFLFFBQVEsY0FBa0IsQ0FBQztBQUM1Qzs7O0dBR0c7QUFFSDtJQUFxQywyQkFBWTtJQUFqRDs7SUFJQSxDQUFDO0lBSEcsd0JBQU0sR0FBTixVQUFPLEVBQUU7UUFDTCxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxLQUFLLEdBQUcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztJQUM1QyxDQUFDO0lBSGdCLE9BQU87UUFEM0IsT0FBTztPQUNhLE9BQU8sQ0FJM0I7SUFBRCxjQUFDO0NBSkQsQUFJQyxDQUpvQyxFQUFFLENBQUMsU0FBUyxHQUloRDtrQkFKb0IsT0FBTyIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8vIExlYXJuIFR5cGVTY3JpcHQ6XG4vLyAgLSBbQ2hpbmVzZV0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC96aC9zY3JpcHRpbmcvdHlwZXNjcmlwdC5odG1sXG4vLyAgLSBbRW5nbGlzaF0gaHR0cDovL3d3dy5jb2NvczJkLXgub3JnL2RvY3MvY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3R5cGVzY3JpcHQuaHRtbFxuLy8gTGVhcm4gQXR0cmlidXRlOlxuLy8gIC0gW0NoaW5lc2VdIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvemgvc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcbi8vICAtIFtFbmdsaXNoXSBodHRwOi8vd3d3LmNvY29zMmQteC5vcmcvZG9jcy9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvcmVmZXJlbmNlL2F0dHJpYnV0ZXMuaHRtbFxuLy8gTGVhcm4gbGlmZS1jeWNsZSBjYWxsYmFja3M6XG4vLyAgLSBbQ2hpbmVzZV0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC96aC9zY3JpcHRpbmcvbGlmZS1jeWNsZS1jYWxsYmFja3MuaHRtbFxuLy8gIC0gW0VuZ2xpc2hdIGh0dHA6Ly93d3cuY29jb3MyZC14Lm9yZy9kb2NzL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9saWZlLWN5Y2xlLWNhbGxiYWNrcy5odG1sXG5cbmNvbnN0IHsgY2NjbGFzcywgcHJvcGVydHkgfSA9IGNjLl9kZWNvcmF0b3I7XG4vKipcbiAqIEEgY29tcG9uZW50IHRoYXQgbWFrZXMgYSBub2RlIHJlbmRlciBpbiBhIHdheSBzdWNoIHRoYXQgaXQgYXBwZWFycyBiZWhpbmQgbm9kZXNcbiAqIHRoYXQgYXJlIGxvY2F0ZWQgYmVsb3cgaXQuXG4gKi9cbkBjY2NsYXNzXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBaU29ydGVyIGV4dGVuZHMgY2MuQ29tcG9uZW50IHtcbiAgICB1cGRhdGUoZHQpIHtcbiAgICAgICAgdGhpcy5ub2RlLnpJbmRleCA9IDEwMDAwICsgLXRoaXMubm9kZS55O1xuICAgIH1cbn1cbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/migration/use_reversed_rotateTo.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '84c73YUtTdDS4mQWTLbwpuq', 'use_reversed_rotateTo');
// migration/use_reversed_rotateTo.js

"use strict";

/*
 * This script is automatically generated by Cocos Creator and is only used for projects compatible with v2.1.0/v2.1.1/v2.2.1/v2.2.2 versions.
 * You do not need to manually add this script in any other project.
 * If you don't use cc.Action in your project, you can delete this script directly.
 * If your project is hosted in VCS such as git, submit this script together.
 *
 * 此脚本由 Cocos Creator 自动生成，仅用于兼容 v2.1.0/v2.1.1/v2.2.1/v2.2.2 版本的工程，
 * 你无需在任何其它项目中手动添加此脚本。
 * 如果你的项目中没用到 Action，可直接删除该脚本。
 * 如果你的项目有托管于 git 等版本库，请将此脚本一并上传。
 */
cc.RotateTo._reverse = true;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcbWlncmF0aW9uXFx1c2VfcmV2ZXJzZWRfcm90YXRlVG8uanMiXSwibmFtZXMiOlsiY2MiLCJSb3RhdGVUbyIsIl9yZXZlcnNlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQUEsRUFBRSxDQUFDQyxRQUFILENBQVlDLFFBQVosR0FBdUIsSUFBdkIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8qXG4gKiBUaGlzIHNjcmlwdCBpcyBhdXRvbWF0aWNhbGx5IGdlbmVyYXRlZCBieSBDb2NvcyBDcmVhdG9yIGFuZCBpcyBvbmx5IHVzZWQgZm9yIHByb2plY3RzIGNvbXBhdGlibGUgd2l0aCB2Mi4xLjAvdjIuMS4xL3YyLjIuMS92Mi4yLjIgdmVyc2lvbnMuXG4gKiBZb3UgZG8gbm90IG5lZWQgdG8gbWFudWFsbHkgYWRkIHRoaXMgc2NyaXB0IGluIGFueSBvdGhlciBwcm9qZWN0LlxuICogSWYgeW91IGRvbid0IHVzZSBjYy5BY3Rpb24gaW4geW91ciBwcm9qZWN0LCB5b3UgY2FuIGRlbGV0ZSB0aGlzIHNjcmlwdCBkaXJlY3RseS5cbiAqIElmIHlvdXIgcHJvamVjdCBpcyBob3N0ZWQgaW4gVkNTIHN1Y2ggYXMgZ2l0LCBzdWJtaXQgdGhpcyBzY3JpcHQgdG9nZXRoZXIuXG4gKlxuICog5q2k6ISa5pys55SxIENvY29zIENyZWF0b3Ig6Ieq5Yqo55Sf5oiQ77yM5LuF55So5LqO5YW85a65IHYyLjEuMC92Mi4xLjEvdjIuMi4xL3YyLjIuMiDniYjmnKznmoTlt6XnqIvvvIxcbiAqIOS9oOaXoOmcgOWcqOS7u+S9leWFtuWug+mhueebruS4reaJi+WKqOa3u+WKoOatpOiEmuacrOOAglxuICog5aaC5p6c5L2g55qE6aG555uu5Lit5rKh55So5YiwIEFjdGlvbu+8jOWPr+ebtOaOpeWIoOmZpOivpeiEmuacrOOAglxuICog5aaC5p6c5L2g55qE6aG555uu5pyJ5omY566h5LqOIGdpdCDnrYnniYjmnKzlupPvvIzor7flsIbmraTohJrmnKzkuIDlubbkuIrkvKDjgIJcbiAqL1xuXG5jYy5Sb3RhdGVUby5fcmV2ZXJzZSA9IHRydWU7XG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/ActorController.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '3dfdbqK/TxMW4zSBlVfgS6Z', 'ActorController');
// scripts/ActorController.ts

// Learn TypeScript:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/typescript.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/life-cycle-callbacks.html
Object.defineProperty(exports, "__esModule", { value: true });
var Controller_1 = require("./input/Controller");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var FacingDirection;
(function (FacingDirection) {
    FacingDirection[FacingDirection["Right"] = 0] = "Right";
    FacingDirection[FacingDirection["Left"] = 1] = "Left";
})(FacingDirection || (FacingDirection = {}));
function sign(x) {
    return x > 0 ? 1 : x < 0 ? -1 : 0;
}
/**
 * A component that implements movement and actions for each actor.
 * It will read input from the first component it finds that has
 * implemented IInputControls.
 */
var ActorController = /** @class */ (function (_super) {
    __extends(ActorController, _super);
    function ActorController() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.initialFacingDirection = FacingDirection.Right;
        _this._animation = null;
        _this._animState = null;
        _this._rigidbody = null;
        _this.idleAnimationName = "";
        _this.moveAnimationName = "";
        _this._idleAnimState = null;
        _this._moveAnimState = null;
        _this.moveSpeed = 10;
        _this.moveAxisX = 0;
        _this.moveAxisY = 0;
        return _this;
    }
    Object.defineProperty(ActorController.prototype, "moveAxis2D", {
        get: function () {
            return new cc.Vec2(this.moveAxisX, this.moveAxisY);
        },
        enumerable: false,
        configurable: true
    });
    // LIFE-CYCLE CALLBACKS:
    ActorController.prototype.onLoad = function () {
        this._animation = this.node.getComponent(cc.Animation);
        if (!this._animation)
            console.warn("ActorController: Component cc.Animation missing on node " + this.node.name);
        this._rigidbody = this.node.getComponent(cc.RigidBody);
        if (!this._rigidbody)
            console.warn("ActorController: Component cc.Rigidbody missing on node " + this.node.name);
    };
    ActorController.prototype.start = function () {
        _super.prototype.start.call(this);
        this._idleAnimState = this._animation.getAnimationState(this.idleAnimationName);
        this._moveAnimState = this._animation.getAnimationState(this.moveAnimationName);
        this._animState = this._animation.play(this.idleAnimationName);
    };
    ActorController.prototype.update = function (dt) {
        // Receive external input if available.
        if (this.inputSource) {
            this.moveAxisX = this.inputSource.horizontalAxis;
            this.moveAxisY = this.inputSource.verticalAxis;
        }
        this._rigidbody.linearVelocity = this.moveAxis2D.mul(this.moveSpeed * dt);
        if (!this._rigidbody.linearVelocity.fuzzyEquals(cc.Vec2.ZERO, 0.01)) {
            if (this._animState != this._moveAnimState) {
                this._animState = this._animation.play(this.moveAnimationName);
            }
            if (this.moveAxisX != 0) {
                this.node.setScale(new cc.Vec2(
                // X
                this.initialFacingDirection == FacingDirection.Right ?
                    sign(this.moveAxisX) :
                    -sign(this.moveAxisX), 
                // Y
                1));
            }
        }
        else {
            if (this._animState != this._idleAnimState) {
                this._animState = this._animation.play(this.idleAnimationName);
            }
        }
        this.node.position = this.node.position.add(this._rigidbody.linearVelocity);
    };
    __decorate([
        property({ type: cc.Enum(FacingDirection) })
    ], ActorController.prototype, "initialFacingDirection", void 0);
    __decorate([
        property(cc.String)
    ], ActorController.prototype, "idleAnimationName", void 0);
    __decorate([
        property(cc.String)
    ], ActorController.prototype, "moveAnimationName", void 0);
    __decorate([
        property(cc.Float)
    ], ActorController.prototype, "moveSpeed", void 0);
    ActorController = __decorate([
        ccclass
    ], ActorController);
    return ActorController;
}(Controller_1.default));
exports.default = ActorController;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcQWN0b3JDb250cm9sbGVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7OztBQUFBLG9CQUFvQjtBQUNwQixrRkFBa0Y7QUFDbEYseUZBQXlGO0FBQ3pGLG1CQUFtQjtBQUNuQiw0RkFBNEY7QUFDNUYsbUdBQW1HO0FBQ25HLDhCQUE4QjtBQUM5Qiw0RkFBNEY7QUFDNUYsbUdBQW1HOztBQUVuRyxpREFBNEM7QUFFdEMsSUFBQSxLQUF3QixFQUFFLENBQUMsVUFBVSxFQUFuQyxPQUFPLGFBQUEsRUFBRSxRQUFRLGNBQWtCLENBQUM7QUFFNUMsSUFBSyxlQUdKO0FBSEQsV0FBSyxlQUFlO0lBQ2hCLHVEQUFLLENBQUE7SUFDTCxxREFBSSxDQUFBO0FBQ1IsQ0FBQyxFQUhJLGVBQWUsS0FBZixlQUFlLFFBR25CO0FBRUQsU0FBUyxJQUFJLENBQUMsQ0FBUztJQUNuQixPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN0QyxDQUFDO0FBRUQ7Ozs7R0FJRztBQUVIO0lBQTZDLG1DQUFVO0lBQXZEO1FBQUEscUVBa0ZDO1FBaEZHLDRCQUFzQixHQUFHLGVBQWUsQ0FBQyxLQUFLLENBQUM7UUFFdkMsZ0JBQVUsR0FBaUIsSUFBSSxDQUFDO1FBQ2hDLGdCQUFVLEdBQXNCLElBQUksQ0FBQztRQUNyQyxnQkFBVSxHQUFpQixJQUFJLENBQUM7UUFFeEMsdUJBQWlCLEdBQVcsRUFBRSxDQUFDO1FBRS9CLHVCQUFpQixHQUFXLEVBQUUsQ0FBQztRQUN2QixvQkFBYyxHQUFzQixJQUFJLENBQUM7UUFDekMsb0JBQWMsR0FBc0IsSUFBSSxDQUFDO1FBR2pELGVBQVMsR0FBRyxFQUFFLENBQUM7UUFDUixlQUFTLEdBQUcsQ0FBQyxDQUFDO1FBQ2QsZUFBUyxHQUFHLENBQUMsQ0FBQzs7SUFpRXpCLENBQUM7SUFoRUcsc0JBQVcsdUNBQVU7YUFBckI7WUFDSSxPQUFPLElBQUksRUFBRSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUN2RCxDQUFDOzs7T0FBQTtJQUVELHdCQUF3QjtJQUV4QixnQ0FBTSxHQUFOO1FBQ0ksSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDdkQsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVO1lBQUUsT0FBTyxDQUFDLElBQUksQ0FBQyw2REFBMkQsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFNLENBQUMsQ0FBQztRQUNoSCxJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUN2RCxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVU7WUFBRSxPQUFPLENBQUMsSUFBSSxDQUFDLDZEQUEyRCxJQUFJLENBQUMsSUFBSSxDQUFDLElBQU0sQ0FBQyxDQUFDO0lBQ3BILENBQUM7SUFFRCwrQkFBSyxHQUFMO1FBQ0ksaUJBQU0sS0FBSyxXQUFFLENBQUM7UUFDZCxJQUFJLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLENBQUM7UUFDaEYsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO1FBQ2hGLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLENBQUM7SUFFbkUsQ0FBQztJQUdELGdDQUFNLEdBQU4sVUFBTyxFQUFFO1FBQ0wsdUNBQXVDO1FBQ3ZDLElBQUksSUFBSSxDQUFDLFdBQVcsRUFBRTtZQUNsQixJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsY0FBYyxDQUFDO1lBQ2pELElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxZQUFZLENBQUM7U0FDbEQ7UUFFRCxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsU0FBUyxHQUFHLEVBQUUsQ0FBQyxDQUFDO1FBQzFFLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLEVBQUU7WUFDakUsSUFBSSxJQUFJLENBQUMsVUFBVSxJQUFJLElBQUksQ0FBQyxjQUFjLEVBQUU7Z0JBQ3hDLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLENBQUM7YUFDbEU7WUFDRCxJQUFJLElBQUksQ0FBQyxTQUFTLElBQUksQ0FBQyxFQUFFO2dCQUNyQixJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxJQUFJO2dCQUMxQixJQUFJO2dCQUNKLElBQUksQ0FBQyxzQkFBc0IsSUFBSSxlQUFlLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ2xELElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQztvQkFDdEIsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQztnQkFFekIsSUFBSTtnQkFDSixDQUFDLENBQ0EsQ0FDSixDQUFDO2FBRUw7U0FFSjthQUNJO1lBQ0QsSUFBSSxJQUFJLENBQUMsVUFBVSxJQUFJLElBQUksQ0FBQyxjQUFjLEVBQUU7Z0JBQ3hDLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLENBQUM7YUFDbEU7U0FFSjtRQUNELElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxDQUFDO0lBRWhGLENBQUM7SUF6RUQ7UUFEQyxRQUFRLENBQUMsRUFBRSxJQUFJLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsRUFBRSxDQUFDO21FQUNFO0lBTS9DO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUM7OERBQ1c7SUFFL0I7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQzs4REFDVztJQUsvQjtRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDO3NEQUNKO0lBZkUsZUFBZTtRQURuQyxPQUFPO09BQ2EsZUFBZSxDQWtGbkM7SUFBRCxzQkFBQztDQWxGRCxBQWtGQyxDQWxGNEMsb0JBQVUsR0FrRnREO2tCQWxGb0IsZUFBZSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8vIExlYXJuIFR5cGVTY3JpcHQ6XG4vLyAgLSBbQ2hpbmVzZV0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC96aC9zY3JpcHRpbmcvdHlwZXNjcmlwdC5odG1sXG4vLyAgLSBbRW5nbGlzaF0gaHR0cDovL3d3dy5jb2NvczJkLXgub3JnL2RvY3MvY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3R5cGVzY3JpcHQuaHRtbFxuLy8gTGVhcm4gQXR0cmlidXRlOlxuLy8gIC0gW0NoaW5lc2VdIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvemgvc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcbi8vICAtIFtFbmdsaXNoXSBodHRwOi8vd3d3LmNvY29zMmQteC5vcmcvZG9jcy9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvcmVmZXJlbmNlL2F0dHJpYnV0ZXMuaHRtbFxuLy8gTGVhcm4gbGlmZS1jeWNsZSBjYWxsYmFja3M6XG4vLyAgLSBbQ2hpbmVzZV0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC96aC9zY3JpcHRpbmcvbGlmZS1jeWNsZS1jYWxsYmFja3MuaHRtbFxuLy8gIC0gW0VuZ2xpc2hdIGh0dHA6Ly93d3cuY29jb3MyZC14Lm9yZy9kb2NzL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9saWZlLWN5Y2xlLWNhbGxiYWNrcy5odG1sXG5cbmltcG9ydCBDb250cm9sbGVyIGZyb20gXCIuL2lucHV0L0NvbnRyb2xsZXJcIjtcblxuY29uc3QgeyBjY2NsYXNzLCBwcm9wZXJ0eSB9ID0gY2MuX2RlY29yYXRvcjtcblxuZW51bSBGYWNpbmdEaXJlY3Rpb257XG4gICAgUmlnaHQsXG4gICAgTGVmdFxufVxuXG5mdW5jdGlvbiBzaWduKHg6IG51bWJlcikge1xuICAgIHJldHVybiB4ID4gMCA/IDEgOiB4IDwgMCA/IC0xIDogMDtcbn1cblxuLyoqXG4gKiBBIGNvbXBvbmVudCB0aGF0IGltcGxlbWVudHMgbW92ZW1lbnQgYW5kIGFjdGlvbnMgZm9yIGVhY2ggYWN0b3IuXG4gKiBJdCB3aWxsIHJlYWQgaW5wdXQgZnJvbSB0aGUgZmlyc3QgY29tcG9uZW50IGl0IGZpbmRzIHRoYXQgaGFzXG4gKiBpbXBsZW1lbnRlZCBJSW5wdXRDb250cm9scy5cbiAqL1xuQGNjY2xhc3NcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIEFjdG9yQ29udHJvbGxlciBleHRlbmRzIENvbnRyb2xsZXIge1xuICAgIEBwcm9wZXJ0eSh7IHR5cGU6IGNjLkVudW0oRmFjaW5nRGlyZWN0aW9uKSB9KVxuICAgIGluaXRpYWxGYWNpbmdEaXJlY3Rpb24gPSBGYWNpbmdEaXJlY3Rpb24uUmlnaHQ7XG5cbiAgICBwcml2YXRlIF9hbmltYXRpb246IGNjLkFuaW1hdGlvbiA9IG51bGw7XG4gICAgcHJpdmF0ZSBfYW5pbVN0YXRlOiBjYy5BbmltYXRpb25TdGF0ZSA9IG51bGw7XG4gICAgcHJpdmF0ZSBfcmlnaWRib2R5OiBjYy5SaWdpZEJvZHkgPSBudWxsO1xuICAgIEBwcm9wZXJ0eShjYy5TdHJpbmcpXG4gICAgaWRsZUFuaW1hdGlvbk5hbWU6IHN0cmluZyA9IFwiXCI7XG4gICAgQHByb3BlcnR5KGNjLlN0cmluZylcbiAgICBtb3ZlQW5pbWF0aW9uTmFtZTogc3RyaW5nID0gXCJcIjtcbiAgICBwcml2YXRlIF9pZGxlQW5pbVN0YXRlOiBjYy5BbmltYXRpb25TdGF0ZSA9IG51bGw7XG4gICAgcHJpdmF0ZSBfbW92ZUFuaW1TdGF0ZTogY2MuQW5pbWF0aW9uU3RhdGUgPSBudWxsO1xuXG4gICAgQHByb3BlcnR5KGNjLkZsb2F0KVxuICAgIG1vdmVTcGVlZCA9IDEwO1xuICAgIHB1YmxpYyBtb3ZlQXhpc1ggPSAwO1xuICAgIHB1YmxpYyBtb3ZlQXhpc1kgPSAwO1xuICAgIHB1YmxpYyBnZXQgbW92ZUF4aXMyRCgpIHtcbiAgICAgICAgcmV0dXJuIG5ldyBjYy5WZWMyKHRoaXMubW92ZUF4aXNYLCB0aGlzLm1vdmVBeGlzWSk7XG4gICAgfVxuXG4gICAgLy8gTElGRS1DWUNMRSBDQUxMQkFDS1M6XG5cbiAgICBvbkxvYWQoKSB7XG4gICAgICAgIHRoaXMuX2FuaW1hdGlvbiA9IHRoaXMubm9kZS5nZXRDb21wb25lbnQoY2MuQW5pbWF0aW9uKTtcbiAgICAgICAgaWYgKCF0aGlzLl9hbmltYXRpb24pIGNvbnNvbGUud2FybihgQWN0b3JDb250cm9sbGVyOiBDb21wb25lbnQgY2MuQW5pbWF0aW9uIG1pc3Npbmcgb24gbm9kZSAke3RoaXMubm9kZS5uYW1lfWApO1xuICAgICAgICB0aGlzLl9yaWdpZGJvZHkgPSB0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KGNjLlJpZ2lkQm9keSk7XG4gICAgICAgIGlmICghdGhpcy5fcmlnaWRib2R5KSBjb25zb2xlLndhcm4oYEFjdG9yQ29udHJvbGxlcjogQ29tcG9uZW50IGNjLlJpZ2lkYm9keSBtaXNzaW5nIG9uIG5vZGUgJHt0aGlzLm5vZGUubmFtZX1gKTtcbiAgICB9XG5cbiAgICBzdGFydCgpIHtcbiAgICAgICAgc3VwZXIuc3RhcnQoKTtcbiAgICAgICAgdGhpcy5faWRsZUFuaW1TdGF0ZSA9IHRoaXMuX2FuaW1hdGlvbi5nZXRBbmltYXRpb25TdGF0ZSh0aGlzLmlkbGVBbmltYXRpb25OYW1lKTtcbiAgICAgICAgdGhpcy5fbW92ZUFuaW1TdGF0ZSA9IHRoaXMuX2FuaW1hdGlvbi5nZXRBbmltYXRpb25TdGF0ZSh0aGlzLm1vdmVBbmltYXRpb25OYW1lKTtcbiAgICAgICAgdGhpcy5fYW5pbVN0YXRlID0gdGhpcy5fYW5pbWF0aW9uLnBsYXkodGhpcy5pZGxlQW5pbWF0aW9uTmFtZSk7XG5cbiAgICB9XG5cblxuICAgIHVwZGF0ZShkdCkge1xuICAgICAgICAvLyBSZWNlaXZlIGV4dGVybmFsIGlucHV0IGlmIGF2YWlsYWJsZS5cbiAgICAgICAgaWYgKHRoaXMuaW5wdXRTb3VyY2UpIHtcbiAgICAgICAgICAgIHRoaXMubW92ZUF4aXNYID0gdGhpcy5pbnB1dFNvdXJjZS5ob3Jpem9udGFsQXhpcztcbiAgICAgICAgICAgIHRoaXMubW92ZUF4aXNZID0gdGhpcy5pbnB1dFNvdXJjZS52ZXJ0aWNhbEF4aXM7XG4gICAgICAgIH1cblxuICAgICAgICB0aGlzLl9yaWdpZGJvZHkubGluZWFyVmVsb2NpdHkgPSB0aGlzLm1vdmVBeGlzMkQubXVsKHRoaXMubW92ZVNwZWVkICogZHQpO1xuICAgICAgICBpZiAoIXRoaXMuX3JpZ2lkYm9keS5saW5lYXJWZWxvY2l0eS5mdXp6eUVxdWFscyhjYy5WZWMyLlpFUk8sIDAuMDEpKSB7XG4gICAgICAgICAgICBpZiAodGhpcy5fYW5pbVN0YXRlICE9IHRoaXMuX21vdmVBbmltU3RhdGUpIHtcbiAgICAgICAgICAgICAgICB0aGlzLl9hbmltU3RhdGUgPSB0aGlzLl9hbmltYXRpb24ucGxheSh0aGlzLm1vdmVBbmltYXRpb25OYW1lKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmICh0aGlzLm1vdmVBeGlzWCAhPSAwKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5ub2RlLnNldFNjYWxlKG5ldyBjYy5WZWMyKFxuICAgICAgICAgICAgICAgICAgICAvLyBYXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuaW5pdGlhbEZhY2luZ0RpcmVjdGlvbiA9PSBGYWNpbmdEaXJlY3Rpb24uUmlnaHQgP1xuICAgICAgICAgICAgICAgICAgICAgICAgc2lnbih0aGlzLm1vdmVBeGlzWCkgOlxuICAgICAgICAgICAgICAgICAgICAgICAgLXNpZ24odGhpcy5tb3ZlQXhpc1gpXG4gICAgICAgICAgICAgICAgICAgICxcbiAgICAgICAgICAgICAgICAgICAgLy8gWVxuICAgICAgICAgICAgICAgICAgICAxXG4gICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgfVxuXG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICBpZiAodGhpcy5fYW5pbVN0YXRlICE9IHRoaXMuX2lkbGVBbmltU3RhdGUpIHtcbiAgICAgICAgICAgICAgICB0aGlzLl9hbmltU3RhdGUgPSB0aGlzLl9hbmltYXRpb24ucGxheSh0aGlzLmlkbGVBbmltYXRpb25OYW1lKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIFxuICAgICAgICB9XG4gICAgICAgIHRoaXMubm9kZS5wb3NpdGlvbiA9IHRoaXMubm9kZS5wb3NpdGlvbi5hZGQodGhpcy5fcmlnaWRib2R5LmxpbmVhclZlbG9jaXR5KTtcbiAgICAgICAgXG4gICAgfVxuXG4gICAgXG5cblxuXG4gICAgXG59XG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/ai/navigation/Waypoint.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'c1fb9eQwYFFiaL2Pab25I/w', 'Waypoint');
// scripts/ai/navigation/Waypoint.ts

// Learn TypeScript:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/typescript.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/life-cycle-callbacks.html
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var Waypoint = /** @class */ (function (_super) {
    __extends(Waypoint, _super);
    function Waypoint() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.adjacentWaypoints = [];
        _this.distances = [];
        return _this;
        // update (dt) {}
    }
    Waypoint_1 = Waypoint;
    /**
     * Returns the distance to a given waypoint.
     * @param otherWaypoint The waypoint to compute the distance to.
     * @returns The distance to that waypoint.
     */
    Waypoint.prototype.distanceTo = function (otherWaypoint) {
        return this.distanceToNode(otherWaypoint.node);
    };
    Waypoint.prototype.distanceToNode = function (otherNode) {
        // Computes the magnitude of the vector (a - b)
        // Where "a" is the other waypoint's position, and
        // "b" is this waypoint's position.
        return otherNode.convertToWorldSpaceAR(cc.Vec2.ZERO)
            .sub(this.node.convertToWorldSpaceAR(cc.Vec2.ZERO))
            .mag();
    };
    Waypoint.prototype.addEdgeTo = function (otherWaypoint) {
        this.adjacentWaypoints.push(otherWaypoint);
        this.distances.push(this.distanceTo(otherWaypoint));
    };
    // LIFE-CYCLE CALLBACKS:
    Waypoint.prototype.onLoad = function () {
        for (var _i = 0, _a = this.adjacentWaypoints; _i < _a.length; _i++) {
            var neighbor = _a[_i];
            this.distances.push(this.distanceTo(neighbor));
        }
    };
    Waypoint.prototype.start = function () {
    };
    var Waypoint_1;
    __decorate([
        property(Waypoint_1)
    ], Waypoint.prototype, "adjacentWaypoints", void 0);
    Waypoint = Waypoint_1 = __decorate([
        ccclass
    ], Waypoint);
    return Waypoint;
}(cc.Component));
exports.default = Waypoint;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcYWlcXG5hdmlnYXRpb25cXFdheXBvaW50LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7OztBQUFBLG9CQUFvQjtBQUNwQixrRkFBa0Y7QUFDbEYseUZBQXlGO0FBQ3pGLG1CQUFtQjtBQUNuQiw0RkFBNEY7QUFDNUYsbUdBQW1HO0FBQ25HLDhCQUE4QjtBQUM5Qiw0RkFBNEY7QUFDNUYsbUdBQW1HOztBQUU3RixJQUFBLEtBQXNCLEVBQUUsQ0FBQyxVQUFVLEVBQWxDLE9BQU8sYUFBQSxFQUFFLFFBQVEsY0FBaUIsQ0FBQztBQUcxQztJQUFzQyw0QkFBWTtJQUFsRDtRQUFBLHFFQXlDQztRQXRDWSx1QkFBaUIsR0FBZSxFQUFFLENBQUM7UUFDbkMsZUFBUyxHQUFhLEVBQUUsQ0FBQzs7UUFvQ2xDLGlCQUFpQjtJQUNyQixDQUFDO2lCQXpDb0IsUUFBUTtJQUt6Qjs7OztPQUlHO0lBQ0ksNkJBQVUsR0FBakIsVUFBa0IsYUFBdUI7UUFDckMsT0FBTyxJQUFJLENBQUMsY0FBYyxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUNuRCxDQUFDO0lBRU0saUNBQWMsR0FBckIsVUFBc0IsU0FBa0I7UUFDcEMsK0NBQStDO1FBQy9DLGtEQUFrRDtRQUNsRCxtQ0FBbUM7UUFDbkMsT0FBTyxTQUFTLENBQUMscUJBQXFCLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7YUFDL0MsR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMscUJBQXFCLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUNsRCxHQUFHLEVBQUUsQ0FBQztJQUNmLENBQUM7SUFFTSw0QkFBUyxHQUFoQixVQUFpQixhQUF1QjtRQUNwQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDO1FBQzNDLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQztJQUN4RCxDQUFDO0lBRUQsd0JBQXdCO0lBRXhCLHlCQUFNLEdBQU47UUFDSSxLQUFxQixVQUFzQixFQUF0QixLQUFBLElBQUksQ0FBQyxpQkFBaUIsRUFBdEIsY0FBc0IsRUFBdEIsSUFBc0IsRUFBRTtZQUF4QyxJQUFJLFFBQVEsU0FBQTtZQUNiLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztTQUNsRDtJQUNMLENBQUM7SUFFRCx3QkFBSyxHQUFMO0lBRUEsQ0FBQzs7SUFuQ0Q7UUFEQyxRQUFRLENBQUMsVUFBUSxDQUFDO3VEQUN5QjtJQUgzQixRQUFRO1FBRDVCLE9BQU87T0FDYSxRQUFRLENBeUM1QjtJQUFELGVBQUM7Q0F6Q0QsQUF5Q0MsQ0F6Q3FDLEVBQUUsQ0FBQyxTQUFTLEdBeUNqRDtrQkF6Q29CLFFBQVEiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvLyBMZWFybiBUeXBlU2NyaXB0OlxuLy8gIC0gW0NoaW5lc2VdIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvemgvc2NyaXB0aW5nL3R5cGVzY3JpcHQuaHRtbFxuLy8gIC0gW0VuZ2xpc2hdIGh0dHA6Ly93d3cuY29jb3MyZC14Lm9yZy9kb2NzL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy90eXBlc2NyaXB0Lmh0bWxcbi8vIExlYXJuIEF0dHJpYnV0ZTpcbi8vICAtIFtDaGluZXNlXSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL3poL3NjcmlwdGluZy9yZWZlcmVuY2UvYXR0cmlidXRlcy5odG1sXG4vLyAgLSBbRW5nbGlzaF0gaHR0cDovL3d3dy5jb2NvczJkLXgub3JnL2RvY3MvY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcbi8vIExlYXJuIGxpZmUtY3ljbGUgY2FsbGJhY2tzOlxuLy8gIC0gW0NoaW5lc2VdIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvemgvc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcbi8vICAtIFtFbmdsaXNoXSBodHRwOi8vd3d3LmNvY29zMmQteC5vcmcvZG9jcy9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvbGlmZS1jeWNsZS1jYWxsYmFja3MuaHRtbFxuXG5jb25zdCB7Y2NjbGFzcywgcHJvcGVydHl9ID0gY2MuX2RlY29yYXRvcjtcblxuQGNjY2xhc3NcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIFdheXBvaW50IGV4dGVuZHMgY2MuQ29tcG9uZW50IHtcblxuICAgIEBwcm9wZXJ0eShXYXlwb2ludClcbiAgICByZWFkb25seSBhZGphY2VudFdheXBvaW50czogV2F5cG9pbnRbXSA9IFtdO1xuICAgIHJlYWRvbmx5IGRpc3RhbmNlczogbnVtYmVyW10gPSBbXTtcbiAgICAvKipcbiAgICAgKiBSZXR1cm5zIHRoZSBkaXN0YW5jZSB0byBhIGdpdmVuIHdheXBvaW50LlxuICAgICAqIEBwYXJhbSBvdGhlcldheXBvaW50IFRoZSB3YXlwb2ludCB0byBjb21wdXRlIHRoZSBkaXN0YW5jZSB0by5cbiAgICAgKiBAcmV0dXJucyBUaGUgZGlzdGFuY2UgdG8gdGhhdCB3YXlwb2ludC5cbiAgICAgKi9cbiAgICBwdWJsaWMgZGlzdGFuY2VUbyhvdGhlcldheXBvaW50OiBXYXlwb2ludCk6IG51bWJlcntcbiAgICAgICAgcmV0dXJuIHRoaXMuZGlzdGFuY2VUb05vZGUob3RoZXJXYXlwb2ludC5ub2RlKTtcbiAgICB9XG5cbiAgICBwdWJsaWMgZGlzdGFuY2VUb05vZGUob3RoZXJOb2RlOiBjYy5Ob2RlKTogbnVtYmVye1xuICAgICAgICAvLyBDb21wdXRlcyB0aGUgbWFnbml0dWRlIG9mIHRoZSB2ZWN0b3IgKGEgLSBiKVxuICAgICAgICAvLyBXaGVyZSBcImFcIiBpcyB0aGUgb3RoZXIgd2F5cG9pbnQncyBwb3NpdGlvbiwgYW5kXG4gICAgICAgIC8vIFwiYlwiIGlzIHRoaXMgd2F5cG9pbnQncyBwb3NpdGlvbi5cbiAgICAgICAgcmV0dXJuIG90aGVyTm9kZS5jb252ZXJ0VG9Xb3JsZFNwYWNlQVIoY2MuVmVjMi5aRVJPKVxuICAgICAgICAgICAgLnN1Yih0aGlzLm5vZGUuY29udmVydFRvV29ybGRTcGFjZUFSKGNjLlZlYzIuWkVSTykpXG4gICAgICAgICAgICAubWFnKCk7XG4gICAgfVxuXG4gICAgcHVibGljIGFkZEVkZ2VUbyhvdGhlcldheXBvaW50OiBXYXlwb2ludCk6IHZvaWR7XG4gICAgICAgIHRoaXMuYWRqYWNlbnRXYXlwb2ludHMucHVzaChvdGhlcldheXBvaW50KTtcbiAgICAgICAgdGhpcy5kaXN0YW5jZXMucHVzaCh0aGlzLmRpc3RhbmNlVG8ob3RoZXJXYXlwb2ludCkpO1xuICAgIH1cblxuICAgIC8vIExJRkUtQ1lDTEUgQ0FMTEJBQ0tTOlxuXG4gICAgb25Mb2FkKCkge1xuICAgICAgICBmb3IgKGxldCBuZWlnaGJvciBvZiB0aGlzLmFkamFjZW50V2F5cG9pbnRzKSB7XG4gICAgICAgICAgICB0aGlzLmRpc3RhbmNlcy5wdXNoKHRoaXMuZGlzdGFuY2VUbyhuZWlnaGJvcikpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgc3RhcnQgKCkge1xuXG4gICAgfVxuXG4gICAgLy8gdXBkYXRlIChkdCkge31cbn1cbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/ai/WanderAgent.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '2a05fAQ2UJPQIurJewep8gS', 'WanderAgent');
// scripts/ai/WanderAgent.ts

// Learn TypeScript:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/typescript.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/life-cycle-callbacks.html
Object.defineProperty(exports, "__esModule", { value: true });
var IInputControls_1 = require("../input/IInputControls");
var Agent_1 = require("./Agent");
var Wanderer_1 = require("./strategies/Wanderer");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
function randomPointOnCircle(radius) {
    if (radius === void 0) { radius = 1; }
    var angle = Math.random() * Math.PI * 2;
    return new cc.Vec2(Math.cos(angle) * radius, Math.sin(angle) * radius);
}
/**
 * An agent that simply wanders around like a cute animal.
 */
var WanderAgent = /** @class */ (function (_super) {
    __extends(WanderAgent, _super);
    function WanderAgent() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        /** The agent will move for this long before stopping to wait. */
        _this.moveDuration = 1.0;
        /** The agent will move at this speed. */
        _this.moveSpeed = 5.0;
        /** The agent will wait for this long before starting to move again. */
        _this.waitDuration = 0.5;
        /** The actual wait duration will be randomized by this factor,
         *  such that the actual wait duration is a random number between
         *  waitDuration x (1 - waitRandomFactor) and
         *  waitDuration x (1 + waitRandomFactor).
        */
        _this.waitRandomFactor = 0.1;
        _this._strategy = null;
        _this.attack = IInputControls_1.ButtonState.Rest;
        _this.interact = IInputControls_1.ButtonState.Rest;
        return _this;
        // !!! DO NOT IMPLEMENT "update"
        // !!! If you want to, you'll have to call the parent class's update method as well!
        // !!! Use agentUpdate instead.
        // update (dt) {}
    }
    Object.defineProperty(WanderAgent.prototype, "horizontalAxis", {
        get: function () {
            if (!this._strategy)
                return 0;
            return this._strategy.horizontalAxis * this.moveSpeed;
        },
        enumerable: false,
        configurable: true
    });
    ;
    Object.defineProperty(WanderAgent.prototype, "verticalAxis", {
        get: function () {
            if (!this._strategy)
                return 0;
            return this._strategy.verticalAxis * this.moveSpeed;
        },
        enumerable: false,
        configurable: true
    });
    //*||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||*\\
    // TODO (1.4): Complete WanderAgent using the Wanderer strategy.
    // [SPECIFICATIONS]
    // - Assign a new Wanderer to this.strategy, with WandererAgent's properties
    //   as the constructor's arguments.
    // - Invoke its "start" method inside WanderAgent's "start" method. 
    // - Invoke its "update" method inside WanderAgent's "agentUpdate" method.
    //*||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||*\\
    WanderAgent.prototype.agentUpdate = function (dt) {
        //#region [YOUR IMPLEMENTATION HERE]
        this._strategy.update(dt);
        //#endregion
    };
    // LIFE-CYCLE CALLBACKS:
    WanderAgent.prototype.onLoad = function () {
        //#region [YOUR IMPLEMENTATION HERE]
        this._strategy = new Wanderer_1.Wanderer(this.moveDuration, this.waitDuration, this.waitRandomFactor);
        //#endregion
    };
    WanderAgent.prototype.start = function () {
        //#region [YOUR IMPLEMENTATION HERE]
        this._strategy.start();
        //#endregion
    };
    __decorate([
        property(cc.Float)
    ], WanderAgent.prototype, "moveDuration", void 0);
    __decorate([
        property(cc.Float)
    ], WanderAgent.prototype, "moveSpeed", void 0);
    __decorate([
        property(cc.Float)
    ], WanderAgent.prototype, "waitDuration", void 0);
    __decorate([
        property(cc.Float)
    ], WanderAgent.prototype, "waitRandomFactor", void 0);
    WanderAgent = __decorate([
        ccclass
    ], WanderAgent);
    return WanderAgent;
}(Agent_1.default));
exports.default = WanderAgent;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcYWlcXFdhbmRlckFnZW50LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7OztBQUFBLG9CQUFvQjtBQUNwQixrRkFBa0Y7QUFDbEYseUZBQXlGO0FBQ3pGLG1CQUFtQjtBQUNuQiw0RkFBNEY7QUFDNUYsbUdBQW1HO0FBQ25HLDhCQUE4QjtBQUM5Qiw0RkFBNEY7QUFDNUYsbUdBQW1HOztBQUVuRywwREFBc0U7QUFDdEUsaUNBQTRCO0FBRTVCLGtEQUFpRDtBQUMzQyxJQUFBLEtBQXdCLEVBQUUsQ0FBQyxVQUFVLEVBQW5DLE9BQU8sYUFBQSxFQUFFLFFBQVEsY0FBa0IsQ0FBQztBQUU1QyxTQUFTLG1CQUFtQixDQUFDLE1BQWtCO0lBQWxCLHVCQUFBLEVBQUEsVUFBa0I7SUFDM0MsSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLE1BQU0sRUFBRSxHQUFHLElBQUksQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDO0lBQ3hDLE9BQU8sSUFBSSxFQUFFLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLEdBQUcsTUFBTSxFQUFFLElBQUksQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLEdBQUcsTUFBTSxDQUFDLENBQUM7QUFDM0UsQ0FBQztBQUNEOztHQUVHO0FBRUg7SUFDWSwrQkFBSztJQURqQjtRQUFBLHFFQXNFQztRQWxFRyxpRUFBaUU7UUFFakUsa0JBQVksR0FBRyxHQUFHLENBQUM7UUFDbkIseUNBQXlDO1FBRXpDLGVBQVMsR0FBRyxHQUFHLENBQUM7UUFDaEIsdUVBQXVFO1FBRXZFLGtCQUFZLEdBQUcsR0FBRyxDQUFDO1FBQ25COzs7O1VBSUU7UUFFRixzQkFBZ0IsR0FBRyxHQUFHLENBQUM7UUFHZixlQUFTLEdBQWlCLElBQUksQ0FBQztRQVV2QyxZQUFNLEdBQWdCLDRCQUFXLENBQUMsSUFBSSxDQUFDO1FBQ3ZDLGNBQVEsR0FBZ0IsNEJBQVcsQ0FBQyxJQUFJLENBQUM7O1FBaUN6QyxnQ0FBZ0M7UUFDaEMsb0ZBQW9GO1FBQ3BGLCtCQUErQjtRQUMvQixpQkFBaUI7SUFDckIsQ0FBQztJQTlDRyxzQkFBVyx1Q0FBYzthQUF6QjtZQUNJLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUztnQkFBRSxPQUFPLENBQUMsQ0FBQztZQUM5QixPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUM7UUFDMUQsQ0FBQzs7O09BQUE7SUFBQSxDQUFDO0lBQ0Ysc0JBQVcscUNBQVk7YUFBdkI7WUFDSSxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVM7Z0JBQUUsT0FBTyxDQUFDLENBQUM7WUFDOUIsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDO1FBQ3hELENBQUM7OztPQUFBO0lBS0QsNEVBQTRFO0lBQzVFLGdFQUFnRTtJQUNoRSxtQkFBbUI7SUFDbkIsNEVBQTRFO0lBQzVFLG9DQUFvQztJQUNwQyxvRUFBb0U7SUFDcEUsMEVBQTBFO0lBQzFFLDRFQUE0RTtJQUVsRSxpQ0FBVyxHQUFyQixVQUFzQixFQUFVO1FBQzVCLG9DQUFvQztRQUNwQyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUMxQixZQUFZO0lBQ2hCLENBQUM7SUFFRCx3QkFBd0I7SUFFeEIsNEJBQU0sR0FBTjtRQUNJLG9DQUFvQztRQUNwQyxJQUFJLENBQUMsU0FBUyxHQUFDLElBQUksbUJBQVEsQ0FBQyxJQUFJLENBQUMsWUFBWSxFQUFDLElBQUksQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDLGdCQUFnQixDQUFDLENBQUM7UUFFeEYsWUFBWTtJQUNoQixDQUFDO0lBRUQsMkJBQUssR0FBTDtRQUNJLG9DQUFvQztRQUNwQyxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssRUFBRSxDQUFDO1FBQ3ZCLFlBQVk7SUFDaEIsQ0FBQztJQTFERDtRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDO3FEQUNBO0lBR25CO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUM7a0RBQ0g7SUFHaEI7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQztxREFDQTtJQU9uQjtRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDO3lEQUNJO0lBbkJOLFdBQVc7UUFEL0IsT0FBTztPQUNhLFdBQVcsQ0FzRS9CO0lBQUQsa0JBQUM7Q0F0RUQsQUFzRUMsQ0FyRVcsZUFBSyxHQXFFaEI7a0JBdEVvQixXQUFXIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy8gTGVhcm4gVHlwZVNjcmlwdDpcbi8vICAtIFtDaGluZXNlXSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL3poL3NjcmlwdGluZy90eXBlc2NyaXB0Lmh0bWxcbi8vICAtIFtFbmdsaXNoXSBodHRwOi8vd3d3LmNvY29zMmQteC5vcmcvZG9jcy9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvdHlwZXNjcmlwdC5odG1sXG4vLyBMZWFybiBBdHRyaWJ1dGU6XG4vLyAgLSBbQ2hpbmVzZV0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC96aC9zY3JpcHRpbmcvcmVmZXJlbmNlL2F0dHJpYnV0ZXMuaHRtbFxuLy8gIC0gW0VuZ2xpc2hdIGh0dHA6Ly93d3cuY29jb3MyZC14Lm9yZy9kb2NzL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9yZWZlcmVuY2UvYXR0cmlidXRlcy5odG1sXG4vLyBMZWFybiBsaWZlLWN5Y2xlIGNhbGxiYWNrczpcbi8vICAtIFtDaGluZXNlXSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL3poL3NjcmlwdGluZy9saWZlLWN5Y2xlLWNhbGxiYWNrcy5odG1sXG4vLyAgLSBbRW5nbGlzaF0gaHR0cDovL3d3dy5jb2NvczJkLXgub3JnL2RvY3MvY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcblxuaW1wb3J0IHsgQnV0dG9uU3RhdGUsIElJbnB1dENvbnRyb2xzIH0gZnJvbSBcIi4uL2lucHV0L0lJbnB1dENvbnRyb2xzXCI7XG5pbXBvcnQgQWdlbnQgZnJvbSBcIi4vQWdlbnRcIjtcbmltcG9ydCB7IEFJIH0gZnJvbSBcIi4vc3RyYXRlZ2llcy9BZ2VudFN0cmF0ZWd5XCI7XG5pbXBvcnQgeyBXYW5kZXJlciB9IGZyb20gXCIuL3N0cmF0ZWdpZXMvV2FuZGVyZXJcIjtcbmNvbnN0IHsgY2NjbGFzcywgcHJvcGVydHkgfSA9IGNjLl9kZWNvcmF0b3I7XG5cbmZ1bmN0aW9uIHJhbmRvbVBvaW50T25DaXJjbGUocmFkaXVzOiBudW1iZXIgPSAxKSB7XG4gICAgbGV0IGFuZ2xlID0gTWF0aC5yYW5kb20oKSAqIE1hdGguUEkgKiAyO1xuICAgIHJldHVybiBuZXcgY2MuVmVjMihNYXRoLmNvcyhhbmdsZSkgKiByYWRpdXMsIE1hdGguc2luKGFuZ2xlKSAqIHJhZGl1cyk7XG59XG4vKipcbiAqIEFuIGFnZW50IHRoYXQgc2ltcGx5IHdhbmRlcnMgYXJvdW5kIGxpa2UgYSBjdXRlIGFuaW1hbC5cbiAqL1xuQGNjY2xhc3NcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIFdhbmRlckFnZW50XG4gICAgZXh0ZW5kcyBBZ2VudFxuICAgIGltcGxlbWVudHMgSUlucHV0Q29udHJvbHN7XG5cbiAgICAvKiogVGhlIGFnZW50IHdpbGwgbW92ZSBmb3IgdGhpcyBsb25nIGJlZm9yZSBzdG9wcGluZyB0byB3YWl0LiAqL1xuICAgIEBwcm9wZXJ0eShjYy5GbG9hdClcbiAgICBtb3ZlRHVyYXRpb24gPSAxLjA7XG4gICAgLyoqIFRoZSBhZ2VudCB3aWxsIG1vdmUgYXQgdGhpcyBzcGVlZC4gKi9cbiAgICBAcHJvcGVydHkoY2MuRmxvYXQpXG4gICAgbW92ZVNwZWVkID0gNS4wO1xuICAgIC8qKiBUaGUgYWdlbnQgd2lsbCB3YWl0IGZvciB0aGlzIGxvbmcgYmVmb3JlIHN0YXJ0aW5nIHRvIG1vdmUgYWdhaW4uICovXG4gICAgQHByb3BlcnR5KGNjLkZsb2F0KVxuICAgIHdhaXREdXJhdGlvbiA9IDAuNTtcbiAgICAvKiogVGhlIGFjdHVhbCB3YWl0IGR1cmF0aW9uIHdpbGwgYmUgcmFuZG9taXplZCBieSB0aGlzIGZhY3RvciwgXG4gICAgICogIHN1Y2ggdGhhdCB0aGUgYWN0dWFsIHdhaXQgZHVyYXRpb24gaXMgYSByYW5kb20gbnVtYmVyIGJldHdlZW5cbiAgICAgKiAgd2FpdER1cmF0aW9uIHggKDEgLSB3YWl0UmFuZG9tRmFjdG9yKSBhbmQgXG4gICAgICogIHdhaXREdXJhdGlvbiB4ICgxICsgd2FpdFJhbmRvbUZhY3RvcikuXG4gICAgKi9cbiAgICBAcHJvcGVydHkoY2MuRmxvYXQpXG4gICAgd2FpdFJhbmRvbUZhY3RvciA9IDAuMTtcblxuXG4gICAgcHJpdmF0ZSBfc3RyYXRlZ3kgOiBBSS5TdHJhdGVneSA9IG51bGw7XG5cbiAgICBwdWJsaWMgZ2V0IGhvcml6b250YWxBeGlzKCkge1xuICAgICAgICBpZiAoIXRoaXMuX3N0cmF0ZWd5KSByZXR1cm4gMDtcbiAgICAgICAgcmV0dXJuIHRoaXMuX3N0cmF0ZWd5Lmhvcml6b250YWxBeGlzICogdGhpcy5tb3ZlU3BlZWQ7XG4gICAgfTtcbiAgICBwdWJsaWMgZ2V0IHZlcnRpY2FsQXhpcygpIHtcbiAgICAgICAgaWYgKCF0aGlzLl9zdHJhdGVneSkgcmV0dXJuIDA7XG4gICAgICAgIHJldHVybiB0aGlzLl9zdHJhdGVneS52ZXJ0aWNhbEF4aXMgKiB0aGlzLm1vdmVTcGVlZDtcbiAgICB9XG4gICAgYXR0YWNrOiBCdXR0b25TdGF0ZSA9IEJ1dHRvblN0YXRlLlJlc3Q7XG4gICAgaW50ZXJhY3Q6IEJ1dHRvblN0YXRlID0gQnV0dG9uU3RhdGUuUmVzdDtcblxuICAgIFxuICAgIC8vKnx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHwqXFxcXFxuICAgIC8vIFRPRE8gKDEuNCk6IENvbXBsZXRlIFdhbmRlckFnZW50IHVzaW5nIHRoZSBXYW5kZXJlciBzdHJhdGVneS5cbiAgICAvLyBbU1BFQ0lGSUNBVElPTlNdXG4gICAgLy8gLSBBc3NpZ24gYSBuZXcgV2FuZGVyZXIgdG8gdGhpcy5zdHJhdGVneSwgd2l0aCBXYW5kZXJlckFnZW50J3MgcHJvcGVydGllc1xuICAgIC8vICAgYXMgdGhlIGNvbnN0cnVjdG9yJ3MgYXJndW1lbnRzLlxuICAgIC8vIC0gSW52b2tlIGl0cyBcInN0YXJ0XCIgbWV0aG9kIGluc2lkZSBXYW5kZXJBZ2VudCdzIFwic3RhcnRcIiBtZXRob2QuIFxuICAgIC8vIC0gSW52b2tlIGl0cyBcInVwZGF0ZVwiIG1ldGhvZCBpbnNpZGUgV2FuZGVyQWdlbnQncyBcImFnZW50VXBkYXRlXCIgbWV0aG9kLlxuICAgIC8vKnx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHwqXFxcXFxuXG4gICAgcHJvdGVjdGVkIGFnZW50VXBkYXRlKGR0OiBudW1iZXIpOiB2b2lkIHtcbiAgICAgICAgLy8jcmVnaW9uIFtZT1VSIElNUExFTUVOVEFUSU9OIEhFUkVdXG4gICAgICAgIHRoaXMuX3N0cmF0ZWd5LnVwZGF0ZShkdCk7XG4gICAgICAgIC8vI2VuZHJlZ2lvblxuICAgIH1cblxuICAgIC8vIExJRkUtQ1lDTEUgQ0FMTEJBQ0tTOlxuXG4gICAgb25Mb2FkKCkge1xuICAgICAgICAvLyNyZWdpb24gW1lPVVIgSU1QTEVNRU5UQVRJT04gSEVSRV1cbiAgICAgICAgdGhpcy5fc3RyYXRlZ3k9bmV3IFdhbmRlcmVyKHRoaXMubW92ZUR1cmF0aW9uLHRoaXMud2FpdER1cmF0aW9uLCB0aGlzLndhaXRSYW5kb21GYWN0b3IpO1xuICAgICAgICBcbiAgICAgICAgLy8jZW5kcmVnaW9uXG4gICAgfVxuXG4gICAgc3RhcnQoKSB7XG4gICAgICAgIC8vI3JlZ2lvbiBbWU9VUiBJTVBMRU1FTlRBVElPTiBIRVJFXVxuICAgICAgICB0aGlzLl9zdHJhdGVneS5zdGFydCgpO1xuICAgICAgICAvLyNlbmRyZWdpb25cbiAgICB9XG4gICAgXG4gICAgLy8gISEhIERPIE5PVCBJTVBMRU1FTlQgXCJ1cGRhdGVcIlxuICAgIC8vICEhISBJZiB5b3Ugd2FudCB0bywgeW91J2xsIGhhdmUgdG8gY2FsbCB0aGUgcGFyZW50IGNsYXNzJ3MgdXBkYXRlIG1ldGhvZCBhcyB3ZWxsIVxuICAgIC8vICEhISBVc2UgYWdlbnRVcGRhdGUgaW5zdGVhZC5cbiAgICAvLyB1cGRhdGUgKGR0KSB7fVxufVxuIl19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/ai/TODO5.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '41c4cZki1tNb59SSEIJ/TR5', 'TODO5');
// scripts/ai/TODO5.ts

//*||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||*\\
// TODO (5): Turn blue, green, yellow, red slimes to prefabs and create instances of them.
// [SPECIFICATIONS]
// - You need to add one blue slime, one green slime, one yellow slime, and one red slime
//   after turning them to prefabs, into scene "level1-1".
// - Place them under the node "Actors".
// - They should still function properly after you instantiate the prefabs!
//    - Place them in the map where they would be visible.
//    - Do not place them in the right side of the river in the far right end of the map.
// - Remember to reassign the fields in the Properties panel for green, yellow, and red slimes.
// - For the new yellow slime, assign Waypoint Graph 3 to it.
// - For the new red slime, assign Waypoint Graph 4 to it.
//*||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||*\\

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcYWlcXFRPRE81LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7OztBQUFBLDRFQUE0RTtBQUM1RSwwRkFBMEY7QUFDMUYsbUJBQW1CO0FBQ25CLHlGQUF5RjtBQUN6RiwwREFBMEQ7QUFDMUQsd0NBQXdDO0FBQ3hDLDJFQUEyRTtBQUMzRSwwREFBMEQ7QUFDMUQseUZBQXlGO0FBQ3pGLCtGQUErRjtBQUMvRiw2REFBNkQ7QUFDN0QsMERBQTBEO0FBQzFELDRFQUE0RSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8vKnx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHwqXFxcXFxuLy8gVE9ETyAoNSk6IFR1cm4gYmx1ZSwgZ3JlZW4sIHllbGxvdywgcmVkIHNsaW1lcyB0byBwcmVmYWJzIGFuZCBjcmVhdGUgaW5zdGFuY2VzIG9mIHRoZW0uXG4vLyBbU1BFQ0lGSUNBVElPTlNdXG4vLyAtIFlvdSBuZWVkIHRvIGFkZCBvbmUgYmx1ZSBzbGltZSwgb25lIGdyZWVuIHNsaW1lLCBvbmUgeWVsbG93IHNsaW1lLCBhbmQgb25lIHJlZCBzbGltZVxuLy8gICBhZnRlciB0dXJuaW5nIHRoZW0gdG8gcHJlZmFicywgaW50byBzY2VuZSBcImxldmVsMS0xXCIuXG4vLyAtIFBsYWNlIHRoZW0gdW5kZXIgdGhlIG5vZGUgXCJBY3RvcnNcIi5cbi8vIC0gVGhleSBzaG91bGQgc3RpbGwgZnVuY3Rpb24gcHJvcGVybHkgYWZ0ZXIgeW91IGluc3RhbnRpYXRlIHRoZSBwcmVmYWJzIVxuLy8gICAgLSBQbGFjZSB0aGVtIGluIHRoZSBtYXAgd2hlcmUgdGhleSB3b3VsZCBiZSB2aXNpYmxlLlxuLy8gICAgLSBEbyBub3QgcGxhY2UgdGhlbSBpbiB0aGUgcmlnaHQgc2lkZSBvZiB0aGUgcml2ZXIgaW4gdGhlIGZhciByaWdodCBlbmQgb2YgdGhlIG1hcC5cbi8vIC0gUmVtZW1iZXIgdG8gcmVhc3NpZ24gdGhlIGZpZWxkcyBpbiB0aGUgUHJvcGVydGllcyBwYW5lbCBmb3IgZ3JlZW4sIHllbGxvdywgYW5kIHJlZCBzbGltZXMuXG4vLyAtIEZvciB0aGUgbmV3IHllbGxvdyBzbGltZSwgYXNzaWduIFdheXBvaW50IEdyYXBoIDMgdG8gaXQuXG4vLyAtIEZvciB0aGUgbmV3IHJlZCBzbGltZSwgYXNzaWduIFdheXBvaW50IEdyYXBoIDQgdG8gaXQuXG4vLyp8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8KlxcXFwiXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/ai/NavWanderAgent.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '5353eyD4YdHSLFpesp5kvKK', 'NavWanderAgent');
// scripts/ai/NavWanderAgent.ts

// Learn TypeScript:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/typescript.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/life-cycle-callbacks.html
Object.defineProperty(exports, "__esModule", { value: true });
var IInputControls_1 = require("../input/IInputControls");
var Agent_1 = require("./Agent");
var WaypointGraph_1 = require("./navigation/WaypointGraph");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
//*||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||*\\
// TODO (3.3): Complete NavWanderAgent's behaviour using NavWanderer.
// [SPECIFICATIONS]
// - Check out the other agents to figure out what's missing, and connect
//   everything together!
//*||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||*\\
var NavWanderAgent = /** @class */ (function (_super) {
    __extends(NavWanderAgent, _super);
    function NavWanderAgent() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.attack = IInputControls_1.ButtonState.Rest;
        _this.interact = IInputControls_1.ButtonState.Rest;
        _this.waypointGraph = null;
        return _this;
        // update (dt) {}
    }
    Object.defineProperty(NavWanderAgent.prototype, "horizontalAxis", {
        get: function () {
            //#region [YOUR IMPLEMENTATION HERE]
            return 0;
            //#endregion
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(NavWanderAgent.prototype, "verticalAxis", {
        get: function () {
            //#region [YOUR IMPLEMENTATION HERE]
            return 0;
            //#endregion
        },
        enumerable: false,
        configurable: true
    });
    //#region [YOUR IMPLEMENTATION HERE]
    //#endregion
    NavWanderAgent.prototype.agentUpdate = function (dt) {
        //#region [YOUR IMPLEMENTATION HERE]
        //#endregion
    };
    // LIFE-CYCLE CALLBACKS:
    NavWanderAgent.prototype.onLoad = function () {
        //#region [YOUR IMPLEMENTATION HERE]
        //#endregion
    };
    NavWanderAgent.prototype.start = function () {
        //#region [YOUR IMPLEMENTATION HERE]
        //#endregion
    };
    __decorate([
        property(WaypointGraph_1.default)
    ], NavWanderAgent.prototype, "waypointGraph", void 0);
    NavWanderAgent = __decorate([
        ccclass
    ], NavWanderAgent);
    return NavWanderAgent;
}(Agent_1.default));
exports.default = NavWanderAgent;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcYWlcXE5hdldhbmRlckFnZW50LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7OztBQUFBLG9CQUFvQjtBQUNwQixrRkFBa0Y7QUFDbEYseUZBQXlGO0FBQ3pGLG1CQUFtQjtBQUNuQiw0RkFBNEY7QUFDNUYsbUdBQW1HO0FBQ25HLDhCQUE4QjtBQUM5Qiw0RkFBNEY7QUFDNUYsbUdBQW1HOztBQUVuRywwREFBc0U7QUFDdEUsaUNBQTRCO0FBQzVCLDREQUF1RDtBQUdqRCxJQUFBLEtBQXNCLEVBQUUsQ0FBQyxVQUFVLEVBQWxDLE9BQU8sYUFBQSxFQUFFLFFBQVEsY0FBaUIsQ0FBQztBQUUxQyw0RUFBNEU7QUFDNUUscUVBQXFFO0FBQ3JFLG1CQUFtQjtBQUNuQix5RUFBeUU7QUFDekUseUJBQXlCO0FBQ3pCLDRFQUE0RTtBQUc1RTtJQUNZLGtDQUFLO0lBRGpCO1FBQUEscUVBMkNDO1FBN0JHLFlBQU0sR0FBZ0IsNEJBQVcsQ0FBQyxJQUFJLENBQUM7UUFDdkMsY0FBUSxHQUFnQiw0QkFBVyxDQUFDLElBQUksQ0FBQztRQUV6QyxtQkFBYSxHQUFrQixJQUFJLENBQUM7O1FBeUJwQyxpQkFBaUI7SUFDckIsQ0FBQztJQXZDRyxzQkFBVywwQ0FBYzthQUF6QjtZQUNJLG9DQUFvQztZQUNwQyxPQUFPLENBQUMsQ0FBQztZQUNULFlBQVk7UUFDaEIsQ0FBQzs7O09BQUE7SUFDRCxzQkFBVyx3Q0FBWTthQUF2QjtZQUNJLG9DQUFvQztZQUNwQyxPQUFPLENBQUMsQ0FBQztZQUNULFlBQVk7UUFDaEIsQ0FBQzs7O09BQUE7SUFNRCxvQ0FBb0M7SUFFcEMsWUFBWTtJQUNGLG9DQUFXLEdBQXJCLFVBQXNCLEVBQVU7UUFDNUIsb0NBQW9DO1FBRXBDLFlBQVk7SUFDaEIsQ0FBQztJQUVELHdCQUF3QjtJQUV4QiwrQkFBTSxHQUFOO1FBQ0ksb0NBQW9DO1FBRXBDLFlBQVk7SUFDaEIsQ0FBQztJQUVELDhCQUFLLEdBQUw7UUFDSSxvQ0FBb0M7UUFFcEMsWUFBWTtJQUNoQixDQUFDO0lBdkJEO1FBREMsUUFBUSxDQUFDLHVCQUFhLENBQUM7eURBQ1k7SUFqQm5CLGNBQWM7UUFEbEMsT0FBTztPQUNhLGNBQWMsQ0EyQ2xDO0lBQUQscUJBQUM7Q0EzQ0QsQUEyQ0MsQ0ExQ1csZUFBSyxHQTBDaEI7a0JBM0NvQixjQUFjIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy8gTGVhcm4gVHlwZVNjcmlwdDpcbi8vICAtIFtDaGluZXNlXSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL3poL3NjcmlwdGluZy90eXBlc2NyaXB0Lmh0bWxcbi8vICAtIFtFbmdsaXNoXSBodHRwOi8vd3d3LmNvY29zMmQteC5vcmcvZG9jcy9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvdHlwZXNjcmlwdC5odG1sXG4vLyBMZWFybiBBdHRyaWJ1dGU6XG4vLyAgLSBbQ2hpbmVzZV0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC96aC9zY3JpcHRpbmcvcmVmZXJlbmNlL2F0dHJpYnV0ZXMuaHRtbFxuLy8gIC0gW0VuZ2xpc2hdIGh0dHA6Ly93d3cuY29jb3MyZC14Lm9yZy9kb2NzL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9yZWZlcmVuY2UvYXR0cmlidXRlcy5odG1sXG4vLyBMZWFybiBsaWZlLWN5Y2xlIGNhbGxiYWNrczpcbi8vICAtIFtDaGluZXNlXSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL3poL3NjcmlwdGluZy9saWZlLWN5Y2xlLWNhbGxiYWNrcy5odG1sXG4vLyAgLSBbRW5nbGlzaF0gaHR0cDovL3d3dy5jb2NvczJkLXgub3JnL2RvY3MvY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcblxuaW1wb3J0IHsgQnV0dG9uU3RhdGUsIElJbnB1dENvbnRyb2xzIH0gZnJvbSBcIi4uL2lucHV0L0lJbnB1dENvbnRyb2xzXCI7XG5pbXBvcnQgQWdlbnQgZnJvbSBcIi4vQWdlbnRcIjtcbmltcG9ydCBXYXlwb2ludEdyYXBoIGZyb20gXCIuL25hdmlnYXRpb24vV2F5cG9pbnRHcmFwaFwiO1xuaW1wb3J0IHsgTmF2V2FuZGVyZXIgfSBmcm9tIFwiLi9zdHJhdGVnaWVzL05hdldhbmRlcmVyXCI7XG5cbmNvbnN0IHtjY2NsYXNzLCBwcm9wZXJ0eX0gPSBjYy5fZGVjb3JhdG9yO1xuXG4vLyp8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8KlxcXFxcbi8vIFRPRE8gKDMuMyk6IENvbXBsZXRlIE5hdldhbmRlckFnZW50J3MgYmVoYXZpb3VyIHVzaW5nIE5hdldhbmRlcmVyLlxuLy8gW1NQRUNJRklDQVRJT05TXVxuLy8gLSBDaGVjayBvdXQgdGhlIG90aGVyIGFnZW50cyB0byBmaWd1cmUgb3V0IHdoYXQncyBtaXNzaW5nLCBhbmQgY29ubmVjdFxuLy8gICBldmVyeXRoaW5nIHRvZ2V0aGVyIVxuLy8qfHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fCpcXFxcXG5cbkBjY2NsYXNzXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBOYXZXYW5kZXJBZ2VudFxuICAgIGV4dGVuZHMgQWdlbnQgXG4gICAgaW1wbGVtZW50cyBJSW5wdXRDb250cm9sc3tcbiAgICBcbiAgICBwdWJsaWMgZ2V0IGhvcml6b250YWxBeGlzKCk6IG51bWJlciB7XG4gICAgICAgIC8vI3JlZ2lvbiBbWU9VUiBJTVBMRU1FTlRBVElPTiBIRVJFXVxuICAgICAgICByZXR1cm4gMDtcbiAgICAgICAgLy8jZW5kcmVnaW9uXG4gICAgfVxuICAgIHB1YmxpYyBnZXQgdmVydGljYWxBeGlzKCk6IG51bWJlciB7XG4gICAgICAgIC8vI3JlZ2lvbiBbWU9VUiBJTVBMRU1FTlRBVElPTiBIRVJFXVxuICAgICAgICByZXR1cm4gMDtcbiAgICAgICAgLy8jZW5kcmVnaW9uXG4gICAgfVxuICAgIGF0dGFjazogQnV0dG9uU3RhdGUgPSBCdXR0b25TdGF0ZS5SZXN0O1xuICAgIGludGVyYWN0OiBCdXR0b25TdGF0ZSA9IEJ1dHRvblN0YXRlLlJlc3Q7XG4gICAgQHByb3BlcnR5KFdheXBvaW50R3JhcGgpXG4gICAgd2F5cG9pbnRHcmFwaDogV2F5cG9pbnRHcmFwaCA9IG51bGw7XG5cbiAgICAvLyNyZWdpb24gW1lPVVIgSU1QTEVNRU5UQVRJT04gSEVSRV1cbiAgICBcbiAgICAvLyNlbmRyZWdpb25cbiAgICBwcm90ZWN0ZWQgYWdlbnRVcGRhdGUoZHQ6IG51bWJlcik6IHZvaWQge1xuICAgICAgICAvLyNyZWdpb24gW1lPVVIgSU1QTEVNRU5UQVRJT04gSEVSRV1cbiAgICAgICAgXG4gICAgICAgIC8vI2VuZHJlZ2lvblxuICAgIH1cblxuICAgIC8vIExJRkUtQ1lDTEUgQ0FMTEJBQ0tTOlxuXG4gICAgb25Mb2FkKCkge1xuICAgICAgICAvLyNyZWdpb24gW1lPVVIgSU1QTEVNRU5UQVRJT04gSEVSRV1cbiAgICAgICAgXG4gICAgICAgIC8vI2VuZHJlZ2lvblxuICAgIH1cblxuICAgIHN0YXJ0ICgpIHtcbiAgICAgICAgLy8jcmVnaW9uIFtZT1VSIElNUExFTUVOVEFUSU9OIEhFUkVdXG4gICAgICAgIFxuICAgICAgICAvLyNlbmRyZWdpb25cbiAgICB9XG5cbiAgICAvLyB1cGRhdGUgKGR0KSB7fVxufVxuIl19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/ai/Agent.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '39ba77Ddy1EMpTOy+FEUQJ4', 'Agent');
// scripts/ai/Agent.ts

// Learn TypeScript:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/typescript.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/life-cycle-callbacks.html
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
/**
 * Abstract class for all AI components.
 * You can think of this as an organized API.
 * If you want to implement the update method, you have to call the
 * super method first!
 */
var Agent = /** @class */ (function (_super) {
    __extends(Agent, _super);
    function Agent() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    // LIFE-CYCLE CALLBACKS:
    Agent.prototype.update = function (dt) {
        this.agentUpdate(dt);
    };
    return Agent;
}(cc.Component));
exports.default = Agent;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcYWlcXEFnZW50LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7OztBQUFBLG9CQUFvQjtBQUNwQixrRkFBa0Y7QUFDbEYseUZBQXlGO0FBQ3pGLG1CQUFtQjtBQUNuQiw0RkFBNEY7QUFDNUYsbUdBQW1HO0FBQ25HLDhCQUE4QjtBQUM5Qiw0RkFBNEY7QUFDNUYsbUdBQW1HOztBQUU3RixJQUFBLEtBQXNCLEVBQUUsQ0FBQyxVQUFVLEVBQWxDLE9BQU8sYUFBQSxFQUFFLFFBQVEsY0FBaUIsQ0FBQztBQUUxQzs7Ozs7R0FLRztBQUNIO0lBQTRDLHlCQUFZO0lBQXhEOztJQWFBLENBQUM7SUFMRyx3QkFBd0I7SUFFZCxzQkFBTSxHQUFoQixVQUFpQixFQUFVO1FBQ3ZCLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFDLENBQUM7SUFDekIsQ0FBQztJQUNMLFlBQUM7QUFBRCxDQWJBLEFBYUMsQ0FiMkMsRUFBRSxDQUFDLFNBQVMsR0FhdkQiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvLyBMZWFybiBUeXBlU2NyaXB0OlxuLy8gIC0gW0NoaW5lc2VdIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvemgvc2NyaXB0aW5nL3R5cGVzY3JpcHQuaHRtbFxuLy8gIC0gW0VuZ2xpc2hdIGh0dHA6Ly93d3cuY29jb3MyZC14Lm9yZy9kb2NzL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy90eXBlc2NyaXB0Lmh0bWxcbi8vIExlYXJuIEF0dHJpYnV0ZTpcbi8vICAtIFtDaGluZXNlXSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL3poL3NjcmlwdGluZy9yZWZlcmVuY2UvYXR0cmlidXRlcy5odG1sXG4vLyAgLSBbRW5nbGlzaF0gaHR0cDovL3d3dy5jb2NvczJkLXgub3JnL2RvY3MvY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcbi8vIExlYXJuIGxpZmUtY3ljbGUgY2FsbGJhY2tzOlxuLy8gIC0gW0NoaW5lc2VdIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvemgvc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcbi8vICAtIFtFbmdsaXNoXSBodHRwOi8vd3d3LmNvY29zMmQteC5vcmcvZG9jcy9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvbGlmZS1jeWNsZS1jYWxsYmFja3MuaHRtbFxuXG5jb25zdCB7Y2NjbGFzcywgcHJvcGVydHl9ID0gY2MuX2RlY29yYXRvcjtcblxuLyoqXG4gKiBBYnN0cmFjdCBjbGFzcyBmb3IgYWxsIEFJIGNvbXBvbmVudHMuXG4gKiBZb3UgY2FuIHRoaW5rIG9mIHRoaXMgYXMgYW4gb3JnYW5pemVkIEFQSS5cbiAqIElmIHlvdSB3YW50IHRvIGltcGxlbWVudCB0aGUgdXBkYXRlIG1ldGhvZCwgeW91IGhhdmUgdG8gY2FsbCB0aGVcbiAqIHN1cGVyIG1ldGhvZCBmaXJzdCFcbiAqL1xuZXhwb3J0IGRlZmF1bHQgYWJzdHJhY3QgY2xhc3MgQWdlbnQgZXh0ZW5kcyBjYy5Db21wb25lbnQge1xuXG4gICAgLyoqXG4gICAgICogVGhlIHVwZGF0ZSBtZXRob2Qgd3JhcHBlciBmb3IgQWdlbnQgY2xhc3Nlcy5cbiAgICAgKiBAcGFyYW0gZHQgVGltZSBlbGFwc2VkIHNpbmNlIHRoZSBsYXN0IGFnZW50VXBkYXRlLlxuICAgICAqL1xuICAgIHByb3RlY3RlZCBhYnN0cmFjdCBhZ2VudFVwZGF0ZShkdDogbnVtYmVyKTogdm9pZDtcblxuICAgIC8vIExJRkUtQ1lDTEUgQ0FMTEJBQ0tTOlxuXG4gICAgcHJvdGVjdGVkIHVwZGF0ZShkdDogbnVtYmVyKSB7XG4gICAgICAgIHRoaXMuYWdlbnRVcGRhdGUoZHQpO1xuICAgIH1cbn1cbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/ai/ShyAgent.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '0b710El2DRDKqoljmM7gWCo', 'ShyAgent');
// scripts/ai/ShyAgent.ts

// Learn TypeScript:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/typescript.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/life-cycle-callbacks.html
Object.defineProperty(exports, "__esModule", { value: true });
var IInputControls_1 = require("../input/IInputControls");
var Agent_1 = require("./Agent");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
/**
 * Mixes two vectors.
 *
 * Example: `mixVec2(a, b, 0.25)` (Mathematically equivalent to a * 0.25 + b * 0.75)
 * @param mix A value between 0 and 1.
 * @returns The mixed result.
 */
function mixVec2(a, b, mix) {
    return a.mul(mix).add(b.mul(1.0 - mix));
}
var ShyAgent = /** @class */ (function (_super) {
    __extends(ShyAgent, _super);
    function ShyAgent() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        /** The agent will move for this long before stopping to wait. */
        _this.moveDuration = 1.0;
        /** The agent will move at this speed. */
        _this.moveSpeed = 1.0;
        /** The agent will wait for this long before starting to move again. */
        _this.waitDuration = 0.5;
        /** The actual wait duration will be randomized by this factor,
         *  such that the actual wait duration is a random number between
         *  waitDuration x (1 - waitRandomFactor) and
         *  waitDuration x (1 + waitRandomFactor).
        */
        _this.waitRandomFactor = 0.1;
        _this.runAwayFrom = null;
        _this.safeDistance = 5.0;
        _this.attack = IInputControls_1.ButtonState.Rest;
        _this.interact = IInputControls_1.ButtonState.Rest;
        _this._moveAxis2D = cc.Vec2.ZERO;
        _this._wanderer = null;
        _this._coward = null;
        _this._isWaiting = false;
        return _this;
        // update (dt) {}
    }
    Object.defineProperty(ShyAgent.prototype, "horizontalAxis", {
        get: function () { return this._moveAxis2D.x; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(ShyAgent.prototype, "verticalAxis", {
        get: function () { return this._moveAxis2D.y; },
        enumerable: false,
        configurable: true
    });
    ShyAgent.prototype.agentUpdate = function (dt) {
        //*||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||*\\
        // TODO (2.2): Combine the two strategies to implement ShyAgent's behaviour.
        // [SPECIFICATIONS]
        // - The ShyAgent is like the WanderAgent, but when it is about to move,
        //   there are two cases:
        //    - If the agent's distance to the target (runAwayFrom) is less than 
        //      the safe distance (safeDistance), set this._moveAxis2D as a mix of 
        //      the wanderer's axes and the coward's axes. 
        //      Please use the provided function mixVec2 with 
        //      a = wandererMove, b = cowardMove, mix = 0.25. (See line 25)
        //    - Otherwise, set this.moveAxis2D as the wanderer's axes.
        // - Note that the agent should NOT be able to change direction while moving.
        //
        // - Hint 1: You can use this._coward.distanceFromTarget to get the 
        //   distance to the target.
        // - Hint 2: Try maintaining this.isWaiting to prevent the agent from
        //   changing direction while moving.
        //*||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||*\\
        //#region [YOUR IMPLEMENTATION HERE]
        // ...
        //#endregion
        if (!this._wanderer || !this._coward)
            return;
        var wandererMove = cc.v2(this._wanderer.horizontalAxis, this._wanderer.verticalAxis);
        var cowardMove = cc.v2(this._coward.horizontalAxis, this._coward.verticalAxis);
        if (wandererMove.fuzzyEquals(cc.Vec2.ZERO, 0.01)) {
            // Wanderer has stopped. The agent should move the moment it is no longer stopped.
            this._isWaiting = true;
            this._moveAxis2D = wandererMove;
        }
        //#region [YOUR IMPLEMENTATION HERE]
        // else...
        //#endregion
    };
    // LIFE-CYCLE CALLBACKS:
    //*||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||*\\
    // TODO (2.1): Initialize ShyAgent's two strategies (this._wanderer and this._coward) correctly.
    // [SPECIFICATIONS]
    // - You'll need ShyAgent's properties: moveDuration, waitDuration, 
    //   waitRandomFactor, runAwayFrom.
    // - You'll also need to pass a reference to this object to the Coward strategy. 
    //   to construct it correctly. (How?)
    //*||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||*\\
    ShyAgent.prototype.onLoad = function () {
        //#region [YOUR IMPLEMENTATION HERE]
        //#endregion
    };
    ShyAgent.prototype.start = function () {
        //#region [YOUR IMPLEMENTATION HERE]
        //#endregion
    };
    __decorate([
        property(cc.Float)
    ], ShyAgent.prototype, "moveDuration", void 0);
    __decorate([
        property(cc.Float)
    ], ShyAgent.prototype, "moveSpeed", void 0);
    __decorate([
        property(cc.Float)
    ], ShyAgent.prototype, "waitDuration", void 0);
    __decorate([
        property(cc.Float)
    ], ShyAgent.prototype, "waitRandomFactor", void 0);
    __decorate([
        property(cc.Node)
    ], ShyAgent.prototype, "runAwayFrom", void 0);
    __decorate([
        property(cc.Float)
    ], ShyAgent.prototype, "safeDistance", void 0);
    ShyAgent = __decorate([
        ccclass
    ], ShyAgent);
    return ShyAgent;
}(Agent_1.default));
exports.default = ShyAgent;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcYWlcXFNoeUFnZW50LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7OztBQUFBLG9CQUFvQjtBQUNwQixrRkFBa0Y7QUFDbEYseUZBQXlGO0FBQ3pGLG1CQUFtQjtBQUNuQiw0RkFBNEY7QUFDNUYsbUdBQW1HO0FBQ25HLDhCQUE4QjtBQUM5Qiw0RkFBNEY7QUFDNUYsbUdBQW1HOztBQUVuRywwREFBc0U7QUFDdEUsaUNBQTRCO0FBSXRCLElBQUEsS0FBc0IsRUFBRSxDQUFDLFVBQVUsRUFBbEMsT0FBTyxhQUFBLEVBQUUsUUFBUSxjQUFpQixDQUFDO0FBQzFDOzs7Ozs7R0FNRztBQUNILFNBQVMsT0FBTyxDQUFDLENBQVUsRUFBRSxDQUFVLEVBQUUsR0FBVztJQUNoRCxPQUFPLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxHQUFHLEdBQUcsQ0FBQyxDQUFDLENBQUE7QUFDM0MsQ0FBQztBQUdEO0lBQ1ksNEJBQUs7SUFEakI7UUFBQSxxRUE2RkM7UUExRkcsaUVBQWlFO1FBRWpFLGtCQUFZLEdBQUcsR0FBRyxDQUFDO1FBQ25CLHlDQUF5QztRQUV6QyxlQUFTLEdBQUcsR0FBRyxDQUFDO1FBQ2hCLHVFQUF1RTtRQUV2RSxrQkFBWSxHQUFHLEdBQUcsQ0FBQztRQUNuQjs7OztVQUlFO1FBRUYsc0JBQWdCLEdBQUcsR0FBRyxDQUFDO1FBRXZCLGlCQUFXLEdBQVksSUFBSSxDQUFDO1FBRTVCLGtCQUFZLEdBQVcsR0FBRyxDQUFDO1FBSTNCLFlBQU0sR0FBZ0IsNEJBQVcsQ0FBQyxJQUFJLENBQUM7UUFDdkMsY0FBUSxHQUFnQiw0QkFBVyxDQUFDLElBQUksQ0FBQztRQUVqQyxpQkFBVyxHQUFZLEVBQUUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO1FBQ3BDLGVBQVMsR0FBYSxJQUFJLENBQUM7UUFDM0IsYUFBTyxHQUFXLElBQUksQ0FBQztRQUN2QixnQkFBVSxHQUFZLEtBQUssQ0FBQzs7UUE0RHBDLGlCQUFpQjtJQUNyQixDQUFDO0lBckVHLHNCQUFXLG9DQUFjO2FBQXpCLGNBQThCLE9BQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUEsQ0FBQyxDQUFDOzs7T0FBQTtJQUN6RCxzQkFBVyxrQ0FBWTthQUF2QixjQUE0QixPQUFPLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFBLENBQUMsQ0FBQzs7O09BQUE7SUFTN0MsOEJBQVcsR0FBckIsVUFBc0IsRUFBVTtRQUM1Qiw0RUFBNEU7UUFDNUUsNEVBQTRFO1FBQzVFLG1CQUFtQjtRQUNuQix3RUFBd0U7UUFDeEUseUJBQXlCO1FBQ3pCLHlFQUF5RTtRQUN6RSwyRUFBMkU7UUFDM0UsbURBQW1EO1FBQ25ELHNEQUFzRDtRQUN0RCxtRUFBbUU7UUFDbkUsOERBQThEO1FBQzlELDZFQUE2RTtRQUM3RSxFQUFFO1FBQ0Ysb0VBQW9FO1FBQ3BFLDRCQUE0QjtRQUM1QixxRUFBcUU7UUFDckUscUNBQXFDO1FBQ3JDLDRFQUE0RTtRQUM1RSxvQ0FBb0M7UUFDcEMsTUFBTTtRQUNOLFlBQVk7UUFDWixJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPO1lBQUUsT0FBTztRQUM3QyxJQUFJLFlBQVksR0FBRyxFQUFFLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsY0FBYyxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsWUFBWSxDQUFDLENBQUM7UUFDckYsSUFBSSxVQUFVLEdBQUcsRUFBRSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGNBQWMsRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDO1FBQy9FLElBQUksWUFBWSxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsRUFBRTtZQUM5QyxrRkFBa0Y7WUFDbEYsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUM7WUFDdkIsSUFBSSxDQUFDLFdBQVcsR0FBRyxZQUFZLENBQUM7U0FDbkM7UUFDRCxvQ0FBb0M7UUFDcEMsVUFBVTtRQUNWLFlBQVk7SUFDaEIsQ0FBQztJQUdELHdCQUF3QjtJQUV4Qiw0RUFBNEU7SUFDNUUsZ0dBQWdHO0lBQ2hHLG1CQUFtQjtJQUNuQixvRUFBb0U7SUFDcEUsbUNBQW1DO0lBQ25DLGlGQUFpRjtJQUNqRixzQ0FBc0M7SUFDdEMsNEVBQTRFO0lBQzVFLHlCQUFNLEdBQU47UUFDSSxvQ0FBb0M7UUFFcEMsWUFBWTtJQUNoQixDQUFDO0lBRUQsd0JBQUssR0FBTDtRQUNJLG9DQUFvQztRQUVwQyxZQUFZO0lBQ2hCLENBQUM7SUFyRkQ7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQztrREFDQTtJQUduQjtRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDOytDQUNIO0lBR2hCO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUM7a0RBQ0E7SUFPbkI7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQztzREFDSTtJQUV2QjtRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDO2lEQUNVO0lBRTVCO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUM7a0RBQ1E7SUF0QlYsUUFBUTtRQUQ1QixPQUFPO09BQ2EsUUFBUSxDQTZGNUI7SUFBRCxlQUFDO0NBN0ZELEFBNkZDLENBNUZXLGVBQUssR0E0RmhCO2tCQTdGb0IsUUFBUSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8vIExlYXJuIFR5cGVTY3JpcHQ6XG4vLyAgLSBbQ2hpbmVzZV0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC96aC9zY3JpcHRpbmcvdHlwZXNjcmlwdC5odG1sXG4vLyAgLSBbRW5nbGlzaF0gaHR0cDovL3d3dy5jb2NvczJkLXgub3JnL2RvY3MvY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3R5cGVzY3JpcHQuaHRtbFxuLy8gTGVhcm4gQXR0cmlidXRlOlxuLy8gIC0gW0NoaW5lc2VdIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvemgvc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcbi8vICAtIFtFbmdsaXNoXSBodHRwOi8vd3d3LmNvY29zMmQteC5vcmcvZG9jcy9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvcmVmZXJlbmNlL2F0dHJpYnV0ZXMuaHRtbFxuLy8gTGVhcm4gbGlmZS1jeWNsZSBjYWxsYmFja3M6XG4vLyAgLSBbQ2hpbmVzZV0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC96aC9zY3JpcHRpbmcvbGlmZS1jeWNsZS1jYWxsYmFja3MuaHRtbFxuLy8gIC0gW0VuZ2xpc2hdIGh0dHA6Ly93d3cuY29jb3MyZC14Lm9yZy9kb2NzL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9saWZlLWN5Y2xlLWNhbGxiYWNrcy5odG1sXG5cbmltcG9ydCB7IEJ1dHRvblN0YXRlLCBJSW5wdXRDb250cm9scyB9IGZyb20gXCIuLi9pbnB1dC9JSW5wdXRDb250cm9sc1wiO1xuaW1wb3J0IEFnZW50IGZyb20gXCIuL0FnZW50XCI7XG5pbXBvcnQgeyBDb3dhcmQgfSBmcm9tIFwiLi9zdHJhdGVnaWVzL0Nvd2FyZFwiO1xuaW1wb3J0IHsgV2FuZGVyZXIgfSBmcm9tIFwiLi9zdHJhdGVnaWVzL1dhbmRlcmVyXCI7XG5cbmNvbnN0IHtjY2NsYXNzLCBwcm9wZXJ0eX0gPSBjYy5fZGVjb3JhdG9yO1xuLyoqXG4gKiBNaXhlcyB0d28gdmVjdG9ycy5cbiAqIFxuICogRXhhbXBsZTogYG1peFZlYzIoYSwgYiwgMC4yNSlgIChNYXRoZW1hdGljYWxseSBlcXVpdmFsZW50IHRvIGEgKiAwLjI1ICsgYiAqIDAuNzUpXG4gKiBAcGFyYW0gbWl4IEEgdmFsdWUgYmV0d2VlbiAwIGFuZCAxLlxuICogQHJldHVybnMgVGhlIG1peGVkIHJlc3VsdC5cbiAqL1xuZnVuY3Rpb24gbWl4VmVjMihhOiBjYy5WZWMyLCBiOiBjYy5WZWMyLCBtaXg6IG51bWJlcikge1xuICAgIHJldHVybiBhLm11bChtaXgpLmFkZChiLm11bCgxLjAgLSBtaXgpKVxufVxuXG5AY2NjbGFzc1xuZXhwb3J0IGRlZmF1bHQgY2xhc3MgU2h5QWdlbnRcbiAgICBleHRlbmRzIEFnZW50XG4gICAgaW1wbGVtZW50cyBJSW5wdXRDb250cm9sc3tcbiAgICAvKiogVGhlIGFnZW50IHdpbGwgbW92ZSBmb3IgdGhpcyBsb25nIGJlZm9yZSBzdG9wcGluZyB0byB3YWl0LiAqL1xuICAgIEBwcm9wZXJ0eShjYy5GbG9hdClcbiAgICBtb3ZlRHVyYXRpb24gPSAxLjA7XG4gICAgLyoqIFRoZSBhZ2VudCB3aWxsIG1vdmUgYXQgdGhpcyBzcGVlZC4gKi9cbiAgICBAcHJvcGVydHkoY2MuRmxvYXQpXG4gICAgbW92ZVNwZWVkID0gMS4wO1xuICAgIC8qKiBUaGUgYWdlbnQgd2lsbCB3YWl0IGZvciB0aGlzIGxvbmcgYmVmb3JlIHN0YXJ0aW5nIHRvIG1vdmUgYWdhaW4uICovXG4gICAgQHByb3BlcnR5KGNjLkZsb2F0KVxuICAgIHdhaXREdXJhdGlvbiA9IDAuNTtcbiAgICAvKiogVGhlIGFjdHVhbCB3YWl0IGR1cmF0aW9uIHdpbGwgYmUgcmFuZG9taXplZCBieSB0aGlzIGZhY3RvciwgXG4gICAgICogIHN1Y2ggdGhhdCB0aGUgYWN0dWFsIHdhaXQgZHVyYXRpb24gaXMgYSByYW5kb20gbnVtYmVyIGJldHdlZW5cbiAgICAgKiAgd2FpdER1cmF0aW9uIHggKDEgLSB3YWl0UmFuZG9tRmFjdG9yKSBhbmQgXG4gICAgICogIHdhaXREdXJhdGlvbiB4ICgxICsgd2FpdFJhbmRvbUZhY3RvcikuXG4gICAgKi9cbiAgICBAcHJvcGVydHkoY2MuRmxvYXQpXG4gICAgd2FpdFJhbmRvbUZhY3RvciA9IDAuMTtcbiAgICBAcHJvcGVydHkoY2MuTm9kZSlcbiAgICBydW5Bd2F5RnJvbTogY2MuTm9kZSA9IG51bGw7XG4gICAgQHByb3BlcnR5KGNjLkZsb2F0KVxuICAgIHNhZmVEaXN0YW5jZTogbnVtYmVyID0gNS4wO1xuXG4gICAgcHVibGljIGdldCBob3Jpem9udGFsQXhpcygpIHsgcmV0dXJuIHRoaXMuX21vdmVBeGlzMkQueCB9XG4gICAgcHVibGljIGdldCB2ZXJ0aWNhbEF4aXMoKSB7IHJldHVybiB0aGlzLl9tb3ZlQXhpczJELnkgfVxuICAgIGF0dGFjazogQnV0dG9uU3RhdGUgPSBCdXR0b25TdGF0ZS5SZXN0O1xuICAgIGludGVyYWN0OiBCdXR0b25TdGF0ZSA9IEJ1dHRvblN0YXRlLlJlc3Q7XG5cbiAgICBwcml2YXRlIF9tb3ZlQXhpczJEOiBjYy5WZWMyID0gY2MuVmVjMi5aRVJPO1xuICAgIHByaXZhdGUgX3dhbmRlcmVyOiBXYW5kZXJlciA9IG51bGw7XG4gICAgcHJpdmF0ZSBfY293YXJkOiBDb3dhcmQgPSBudWxsO1xuICAgIHByaXZhdGUgX2lzV2FpdGluZzogQm9vbGVhbiA9IGZhbHNlO1xuXG4gICAgcHJvdGVjdGVkIGFnZW50VXBkYXRlKGR0OiBudW1iZXIpOiB2b2lkIHtcbiAgICAgICAgLy8qfHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fCpcXFxcXG4gICAgICAgIC8vIFRPRE8gKDIuMik6IENvbWJpbmUgdGhlIHR3byBzdHJhdGVnaWVzIHRvIGltcGxlbWVudCBTaHlBZ2VudCdzIGJlaGF2aW91ci5cbiAgICAgICAgLy8gW1NQRUNJRklDQVRJT05TXVxuICAgICAgICAvLyAtIFRoZSBTaHlBZ2VudCBpcyBsaWtlIHRoZSBXYW5kZXJBZ2VudCwgYnV0IHdoZW4gaXQgaXMgYWJvdXQgdG8gbW92ZSxcbiAgICAgICAgLy8gICB0aGVyZSBhcmUgdHdvIGNhc2VzOlxuICAgICAgICAvLyAgICAtIElmIHRoZSBhZ2VudCdzIGRpc3RhbmNlIHRvIHRoZSB0YXJnZXQgKHJ1bkF3YXlGcm9tKSBpcyBsZXNzIHRoYW4gXG4gICAgICAgIC8vICAgICAgdGhlIHNhZmUgZGlzdGFuY2UgKHNhZmVEaXN0YW5jZSksIHNldCB0aGlzLl9tb3ZlQXhpczJEIGFzIGEgbWl4IG9mIFxuICAgICAgICAvLyAgICAgIHRoZSB3YW5kZXJlcidzIGF4ZXMgYW5kIHRoZSBjb3dhcmQncyBheGVzLiBcbiAgICAgICAgLy8gICAgICBQbGVhc2UgdXNlIHRoZSBwcm92aWRlZCBmdW5jdGlvbiBtaXhWZWMyIHdpdGggXG4gICAgICAgIC8vICAgICAgYSA9IHdhbmRlcmVyTW92ZSwgYiA9IGNvd2FyZE1vdmUsIG1peCA9IDAuMjUuIChTZWUgbGluZSAyNSlcbiAgICAgICAgLy8gICAgLSBPdGhlcndpc2UsIHNldCB0aGlzLm1vdmVBeGlzMkQgYXMgdGhlIHdhbmRlcmVyJ3MgYXhlcy5cbiAgICAgICAgLy8gLSBOb3RlIHRoYXQgdGhlIGFnZW50IHNob3VsZCBOT1QgYmUgYWJsZSB0byBjaGFuZ2UgZGlyZWN0aW9uIHdoaWxlIG1vdmluZy5cbiAgICAgICAgLy9cbiAgICAgICAgLy8gLSBIaW50IDE6IFlvdSBjYW4gdXNlIHRoaXMuX2Nvd2FyZC5kaXN0YW5jZUZyb21UYXJnZXQgdG8gZ2V0IHRoZSBcbiAgICAgICAgLy8gICBkaXN0YW5jZSB0byB0aGUgdGFyZ2V0LlxuICAgICAgICAvLyAtIEhpbnQgMjogVHJ5IG1haW50YWluaW5nIHRoaXMuaXNXYWl0aW5nIHRvIHByZXZlbnQgdGhlIGFnZW50IGZyb21cbiAgICAgICAgLy8gICBjaGFuZ2luZyBkaXJlY3Rpb24gd2hpbGUgbW92aW5nLlxuICAgICAgICAvLyp8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8KlxcXFxcbiAgICAgICAgLy8jcmVnaW9uIFtZT1VSIElNUExFTUVOVEFUSU9OIEhFUkVdXG4gICAgICAgIC8vIC4uLlxuICAgICAgICAvLyNlbmRyZWdpb25cbiAgICAgICAgaWYgKCF0aGlzLl93YW5kZXJlciB8fCAhdGhpcy5fY293YXJkKSByZXR1cm47XG4gICAgICAgIGxldCB3YW5kZXJlck1vdmUgPSBjYy52Mih0aGlzLl93YW5kZXJlci5ob3Jpem9udGFsQXhpcywgdGhpcy5fd2FuZGVyZXIudmVydGljYWxBeGlzKTtcbiAgICAgICAgbGV0IGNvd2FyZE1vdmUgPSBjYy52Mih0aGlzLl9jb3dhcmQuaG9yaXpvbnRhbEF4aXMsIHRoaXMuX2Nvd2FyZC52ZXJ0aWNhbEF4aXMpO1xuICAgICAgICBpZiAod2FuZGVyZXJNb3ZlLmZ1enp5RXF1YWxzKGNjLlZlYzIuWkVSTywgMC4wMSkpIHtcbiAgICAgICAgICAgIC8vIFdhbmRlcmVyIGhhcyBzdG9wcGVkLiBUaGUgYWdlbnQgc2hvdWxkIG1vdmUgdGhlIG1vbWVudCBpdCBpcyBubyBsb25nZXIgc3RvcHBlZC5cbiAgICAgICAgICAgIHRoaXMuX2lzV2FpdGluZyA9IHRydWU7XG4gICAgICAgICAgICB0aGlzLl9tb3ZlQXhpczJEID0gd2FuZGVyZXJNb3ZlO1xuICAgICAgICB9XG4gICAgICAgIC8vI3JlZ2lvbiBbWU9VUiBJTVBMRU1FTlRBVElPTiBIRVJFXVxuICAgICAgICAvLyBlbHNlLi4uXG4gICAgICAgIC8vI2VuZHJlZ2lvblxuICAgIH1cblxuXG4gICAgLy8gTElGRS1DWUNMRSBDQUxMQkFDS1M6XG5cbiAgICAvLyp8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8KlxcXFxcbiAgICAvLyBUT0RPICgyLjEpOiBJbml0aWFsaXplIFNoeUFnZW50J3MgdHdvIHN0cmF0ZWdpZXMgKHRoaXMuX3dhbmRlcmVyIGFuZCB0aGlzLl9jb3dhcmQpIGNvcnJlY3RseS5cbiAgICAvLyBbU1BFQ0lGSUNBVElPTlNdXG4gICAgLy8gLSBZb3UnbGwgbmVlZCBTaHlBZ2VudCdzIHByb3BlcnRpZXM6IG1vdmVEdXJhdGlvbiwgd2FpdER1cmF0aW9uLCBcbiAgICAvLyAgIHdhaXRSYW5kb21GYWN0b3IsIHJ1bkF3YXlGcm9tLlxuICAgIC8vIC0gWW91J2xsIGFsc28gbmVlZCB0byBwYXNzIGEgcmVmZXJlbmNlIHRvIHRoaXMgb2JqZWN0IHRvIHRoZSBDb3dhcmQgc3RyYXRlZ3kuIFxuICAgIC8vICAgdG8gY29uc3RydWN0IGl0IGNvcnJlY3RseS4gKEhvdz8pXG4gICAgLy8qfHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fCpcXFxcXG4gICAgb25Mb2FkKCkge1xuICAgICAgICAvLyNyZWdpb24gW1lPVVIgSU1QTEVNRU5UQVRJT04gSEVSRV1cbiAgICAgICAgXG4gICAgICAgIC8vI2VuZHJlZ2lvblxuICAgIH1cblxuICAgIHN0YXJ0ICgpIHtcbiAgICAgICAgLy8jcmVnaW9uIFtZT1VSIElNUExFTUVOVEFUSU9OIEhFUkVdXG4gICAgICAgIFxuICAgICAgICAvLyNlbmRyZWdpb25cbiAgICB9XG5cbiAgICAvLyB1cGRhdGUgKGR0KSB7fVxufVxuIl19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/input/IInputControls.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '5cb1e/x681EIqL7dYrX+sTd', 'IInputControls');
// scripts/input/IInputControls.ts

Object.defineProperty(exports, "__esModule", { value: true });
exports.hasImplementedInputControls = exports.ButtonState = void 0;
/**
 * The state of a button-like variable during a single frame.
 */
var ButtonState;
(function (ButtonState) {
    /** The button is in its natural (inactive) state. */
    ButtonState[ButtonState["Rest"] = 0] = "Rest";
    /** The button is pressed down this frame. */
    ButtonState[ButtonState["Pressed"] = 1] = "Pressed";
    /** The button is held down. */
    ButtonState[ButtonState["Held"] = 2] = "Held";
    /** The button is released this frame. */
    ButtonState[ButtonState["Released"] = 3] = "Released";
})(ButtonState = exports.ButtonState || (exports.ButtonState = {}));
function hasImplementedInputControls(obj) {
    return obj &&
        (obj.horizontalAxis !== undefined) &&
        (obj.verticalAxis !== undefined) &&
        (obj.attack !== undefined) &&
        (obj.interact !== undefined);
}
exports.hasImplementedInputControls = hasImplementedInputControls;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcaW5wdXRcXElJbnB1dENvbnRyb2xzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQ0E7O0dBRUc7QUFDSCxJQUFZLFdBU1g7QUFURCxXQUFZLFdBQVc7SUFDbkIscURBQXFEO0lBQ3JELDZDQUFJLENBQUE7SUFDSiw2Q0FBNkM7SUFDN0MsbURBQU8sQ0FBQTtJQUNQLCtCQUErQjtJQUMvQiw2Q0FBSSxDQUFBO0lBQ0oseUNBQXlDO0lBQ3pDLHFEQUFRLENBQUE7QUFDWixDQUFDLEVBVFcsV0FBVyxHQUFYLG1CQUFXLEtBQVgsbUJBQVcsUUFTdEI7QUFhRCxTQUFnQiwyQkFBMkIsQ0FBQyxHQUFRO0lBQ2hELE9BQU8sR0FBRztRQUNWLENBQUMsR0FBRyxDQUFDLGNBQWMsS0FBSyxTQUFTLENBQUM7UUFDbEMsQ0FBQyxHQUFHLENBQUMsWUFBWSxLQUFLLFNBQVMsQ0FBQztRQUNoQyxDQUFDLEdBQUcsQ0FBQyxNQUFNLEtBQUssU0FBUyxDQUFDO1FBQzFCLENBQUMsR0FBRyxDQUFDLFFBQVEsS0FBSyxTQUFTLENBQUMsQ0FBQTtBQUNoQyxDQUFDO0FBTkQsa0VBTUMiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJcbi8qKlxuICogVGhlIHN0YXRlIG9mIGEgYnV0dG9uLWxpa2UgdmFyaWFibGUgZHVyaW5nIGEgc2luZ2xlIGZyYW1lLlxuICovXG5leHBvcnQgZW51bSBCdXR0b25TdGF0ZXtcbiAgICAvKiogVGhlIGJ1dHRvbiBpcyBpbiBpdHMgbmF0dXJhbCAoaW5hY3RpdmUpIHN0YXRlLiAqL1xuICAgIFJlc3QsXG4gICAgLyoqIFRoZSBidXR0b24gaXMgcHJlc3NlZCBkb3duIHRoaXMgZnJhbWUuICovXG4gICAgUHJlc3NlZCxcbiAgICAvKiogVGhlIGJ1dHRvbiBpcyBoZWxkIGRvd24uICovXG4gICAgSGVsZCxcbiAgICAvKiogVGhlIGJ1dHRvbiBpcyByZWxlYXNlZCB0aGlzIGZyYW1lLiAqL1xuICAgIFJlbGVhc2VkLFxufVxuZXhwb3J0IHR5cGUgQXhpczFEID0gbnVtYmVyO1xuLyoqXG4gKiBJbnRlcmZhY2UgZm9yIG9iamVjdHMgdGhhdCBjYW4gc3VwcG9ydCBjb250cm9sIGlucHV0cy5cbiAqIFlvdSBjYW4gY29uc2lkZXIgdGhpcyBhcyBhbiBhYnN0cmFjdGlvbiBvdmVyIGRpZmZlcmVudCBraW5kcyBvZiBpbnB1dHMuXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgSUlucHV0Q29udHJvbHMge1xuICAgIHJlYWRvbmx5IGhvcml6b250YWxBeGlzOiBBeGlzMUQ7XG4gICAgcmVhZG9ubHkgdmVydGljYWxBeGlzOiBBeGlzMUQ7XG4gICAgcmVhZG9ubHkgYXR0YWNrOiBCdXR0b25TdGF0ZTtcbiAgICByZWFkb25seSBpbnRlcmFjdDogQnV0dG9uU3RhdGU7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBoYXNJbXBsZW1lbnRlZElucHV0Q29udHJvbHMob2JqOiBhbnkpOiBvYmogaXMgSUlucHV0Q29udHJvbHN7XG4gICAgcmV0dXJuIG9iaiAmJiBcbiAgICAob2JqLmhvcml6b250YWxBeGlzICE9PSB1bmRlZmluZWQpICYmXG4gICAgKG9iai52ZXJ0aWNhbEF4aXMgIT09IHVuZGVmaW5lZCkgJiZcbiAgICAob2JqLmF0dGFjayAhPT0gdW5kZWZpbmVkKSAmJlxuICAgIChvYmouaW50ZXJhY3QgIT09IHVuZGVmaW5lZClcbn0iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/ai/strategies/NavChaser.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '8b71eeKSnpJcaE9WtnE0IOv', 'NavChaser');
// scripts/ai/strategies/NavChaser.ts

// Learn TypeScript:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/typescript.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/life-cycle-callbacks.html
Object.defineProperty(exports, "__esModule", { value: true });
exports.NavChaser = void 0;
var Navigator_1 = require("./Navigator");
/**
 * An AI strategy that describes a behaviour in which the agent tries to move to the
 * waypoint on the waypoint graph closest to the target.
 *
 * It will not stray away from the graph beyond a distance equal to the shortest edge
 * on the graph's length.
 */
var NavChaser = /** @class */ (function (_super) {
    __extends(NavChaser, _super);
    function NavChaser(agent, waypointGraph, runTowards) {
        var _this = _super.call(this, agent, waypointGraph) || this;
        /** The agent's output to IInput. */
        _this._moveAxis2D = cc.Vec2.ZERO;
        _this._minGraphEdgeLength = Infinity;
        _this._runTowards = null;
        _this._nextWaypoint = null;
        _this._runTowards = runTowards;
        return _this;
    }
    Object.defineProperty(NavChaser.prototype, "nextWaypoint", {
        get: function () {
            return this._nextWaypoint;
        },
        enumerable: false,
        configurable: true
    });
    NavChaser.prototype.onTransitionFinish = function () {
        //*||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||*\\
        // TODO (4.2): Complete NavChaser's onTransitionFinish method.
        // [SPECIFICATIONS]
        // - NavChaser should move towards the waypoint on the waypoint graph 
        //   closest to this._runTowards.
        // - Assign your results to this._nextWaypoint.
        //*||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||*\\
        //#region [YOUR IMPLEMENTATION HERE]
        //#endregion
        // console.log(`NavChaser: Current: ${this.currentWaypoint.node.name}, Next: ${this.nextWaypoint.node.name}`);
    };
    Object.defineProperty(NavChaser.prototype, "horizontalAxis", {
        get: function () {
            return this._moveAxis2D.x;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(NavChaser.prototype, "verticalAxis", {
        get: function () {
            return this._moveAxis2D.y;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(NavChaser.prototype, "attack", {
        get: function () {
            throw new Error("Method not implemented.");
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(NavChaser.prototype, "interact", {
        get: function () {
            throw new Error("Method not implemented.");
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(NavChaser.prototype, "towardsTarget", {
        get: function () {
            return this._runTowards.position.sub(this.agent.node.position).normalize();
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(NavChaser.prototype, "distanceFromTarget", {
        get: function () {
            return this._runTowards.position.sub(this.agent.node.position).mag();
        },
        enumerable: false,
        configurable: true
    });
    NavChaser.prototype.start = function () {
        this._nextWaypoint = this.closestWaypoint;
        for (var _i = 0, _a = this.waypointGraph.adjacencyList; _i < _a.length; _i++) {
            var waypoint = _a[_i];
            for (var _b = 0, _c = waypoint.distances; _b < _c.length; _b++) {
                var dist = _c[_b];
                this._minGraphEdgeLength = Math.min(this._minGraphEdgeLength, dist);
            }
        }
    };
    NavChaser.prototype.update = function (dt) {
        if (this.distanceFromTarget < this._minGraphEdgeLength
            && this.currentWaypoint && this.currentWaypoint.distanceToNode(this.agent.node) < this._minGraphEdgeLength) {
            this._moveAxis2D = this.towardsTarget;
        }
        else {
            _super.prototype.update.call(this, dt);
            if (this.currentWaypoint === this.nextWaypoint) {
                this._moveAxis2D = cc.Vec2.ZERO;
                this.onTransitionFinish();
            }
            else
                this._moveAxis2D = this.towardsNextWaypoint;
        }
    };
    return NavChaser;
}(Navigator_1.Navigator));
exports.NavChaser = NavChaser;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcYWlcXHN0cmF0ZWdpZXNcXE5hdkNoYXNlci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7QUFBQSxvQkFBb0I7QUFDcEIsa0ZBQWtGO0FBQ2xGLHlGQUF5RjtBQUN6RixtQkFBbUI7QUFDbkIsNEZBQTRGO0FBQzVGLG1HQUFtRztBQUNuRyw4QkFBOEI7QUFDOUIsNEZBQTRGO0FBQzVGLG1HQUFtRzs7O0FBTW5HLHlDQUF3QztBQUN4Qzs7Ozs7O0dBTUc7QUFDSDtJQUErQiw2QkFBUztJQUtwQyxtQkFBWSxLQUFZLEVBQUUsYUFBNEIsRUFBRSxVQUFtQjtRQUEzRSxZQUNJLGtCQUFNLEtBQUssRUFBRSxhQUFhLENBQUMsU0FFOUI7UUFQRCxvQ0FBb0M7UUFDNUIsaUJBQVcsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztRQUMzQix5QkFBbUIsR0FBRyxRQUFRLENBQUM7UUFDL0IsaUJBQVcsR0FBWSxJQUFJLENBQUM7UUFLNUIsbUJBQWEsR0FBYSxJQUFJLENBQUM7UUFGbkMsS0FBSSxDQUFDLFdBQVcsR0FBRyxVQUFVLENBQUM7O0lBQ2xDLENBQUM7SUFFRCxzQkFBYyxtQ0FBWTthQUExQjtZQUNJLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQztRQUM5QixDQUFDOzs7T0FBQTtJQUNTLHNDQUFrQixHQUE1QjtRQUNJLDRFQUE0RTtRQUM1RSw4REFBOEQ7UUFDOUQsbUJBQW1CO1FBQ25CLHNFQUFzRTtRQUN0RSxpQ0FBaUM7UUFDakMsK0NBQStDO1FBQy9DLDRFQUE0RTtRQUU1RSxvQ0FBb0M7UUFFcEMsWUFBWTtRQUNaLDhHQUE4RztJQUNsSCxDQUFDO0lBQ0Qsc0JBQVcscUNBQWM7YUFBekI7WUFDSSxPQUFPLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDO1FBQzlCLENBQUM7OztPQUFBO0lBQ0Qsc0JBQVcsbUNBQVk7YUFBdkI7WUFDSSxPQUFPLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDO1FBQzlCLENBQUM7OztPQUFBO0lBQ0Qsc0JBQVcsNkJBQU07YUFBakI7WUFDSSxNQUFNLElBQUksS0FBSyxDQUFDLHlCQUF5QixDQUFDLENBQUM7UUFDL0MsQ0FBQzs7O09BQUE7SUFDRCxzQkFBVywrQkFBUTthQUFuQjtZQUNJLE1BQU0sSUFBSSxLQUFLLENBQUMseUJBQXlCLENBQUMsQ0FBQztRQUMvQyxDQUFDOzs7T0FBQTtJQUNELHNCQUFXLG9DQUFhO2FBQXhCO1lBQ0ksT0FBUSxJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsU0FBUyxFQUFFLENBQUM7UUFDaEYsQ0FBQzs7O09BQUE7SUFFRCxzQkFBVyx5Q0FBa0I7YUFBN0I7WUFDSSxPQUFPLElBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQTtRQUN4RSxDQUFDOzs7T0FBQTtJQUNNLHlCQUFLLEdBQVo7UUFDSSxJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUM7UUFDMUMsS0FBcUIsVUFBZ0MsRUFBaEMsS0FBQSxJQUFJLENBQUMsYUFBYSxDQUFDLGFBQWEsRUFBaEMsY0FBZ0MsRUFBaEMsSUFBZ0MsRUFBRTtZQUFsRCxJQUFJLFFBQVEsU0FBQTtZQUNiLEtBQWlCLFVBQWtCLEVBQWxCLEtBQUEsUUFBUSxDQUFDLFNBQVMsRUFBbEIsY0FBa0IsRUFBbEIsSUFBa0IsRUFBRTtnQkFBaEMsSUFBSSxJQUFJLFNBQUE7Z0JBQ1QsSUFBSSxDQUFDLG1CQUFtQixHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLG1CQUFtQixFQUFFLElBQUksQ0FBQyxDQUFDO2FBQ3ZFO1NBQ0o7SUFDTCxDQUFDO0lBRU0sMEJBQU0sR0FBYixVQUFjLEVBQVU7UUFDcEIsSUFBSSxJQUFJLENBQUMsa0JBQWtCLEdBQUcsSUFBSSxDQUFDLG1CQUFtQjtlQUMvQyxJQUFJLENBQUMsZUFBZSxJQUFJLElBQUksQ0FBQyxlQUFlLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLG1CQUFtQixFQUFFO1lBQzVHLElBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQztTQUN6QzthQUNJO1lBQ0QsaUJBQU0sTUFBTSxZQUFDLEVBQUUsQ0FBQyxDQUFDO1lBQ2pCLElBQUksSUFBSSxDQUFDLGVBQWUsS0FBSyxJQUFJLENBQUMsWUFBWSxFQUFFO2dCQUM1QyxJQUFJLENBQUMsV0FBVyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO2dCQUNoQyxJQUFJLENBQUMsa0JBQWtCLEVBQUUsQ0FBQzthQUM3Qjs7Z0JBQ0ksSUFBSSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUMsbUJBQW1CLENBQUM7U0FDcEQ7SUFFTCxDQUFDO0lBRUwsZ0JBQUM7QUFBRCxDQXZFQSxBQXVFQyxDQXZFOEIscUJBQVMsR0F1RXZDO0FBdkVZLDhCQUFTIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy8gTGVhcm4gVHlwZVNjcmlwdDpcbi8vICAtIFtDaGluZXNlXSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL3poL3NjcmlwdGluZy90eXBlc2NyaXB0Lmh0bWxcbi8vICAtIFtFbmdsaXNoXSBodHRwOi8vd3d3LmNvY29zMmQteC5vcmcvZG9jcy9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvdHlwZXNjcmlwdC5odG1sXG4vLyBMZWFybiBBdHRyaWJ1dGU6XG4vLyAgLSBbQ2hpbmVzZV0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC96aC9zY3JpcHRpbmcvcmVmZXJlbmNlL2F0dHJpYnV0ZXMuaHRtbFxuLy8gIC0gW0VuZ2xpc2hdIGh0dHA6Ly93d3cuY29jb3MyZC14Lm9yZy9kb2NzL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9yZWZlcmVuY2UvYXR0cmlidXRlcy5odG1sXG4vLyBMZWFybiBsaWZlLWN5Y2xlIGNhbGxiYWNrczpcbi8vICAtIFtDaGluZXNlXSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL3poL3NjcmlwdGluZy9saWZlLWN5Y2xlLWNhbGxiYWNrcy5odG1sXG4vLyAgLSBbRW5nbGlzaF0gaHR0cDovL3d3dy5jb2NvczJkLXgub3JnL2RvY3MvY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcblxuaW1wb3J0IHsgQnV0dG9uU3RhdGUgfSBmcm9tIFwiLi4vLi4vaW5wdXQvSUlucHV0Q29udHJvbHNcIjtcbmltcG9ydCBBZ2VudCBmcm9tIFwiLi4vQWdlbnRcIjtcbmltcG9ydCBXYXlwb2ludCBmcm9tIFwiLi4vbmF2aWdhdGlvbi9XYXlwb2ludFwiO1xuaW1wb3J0IFdheXBvaW50R3JhcGggZnJvbSBcIi4uL25hdmlnYXRpb24vV2F5cG9pbnRHcmFwaFwiO1xuaW1wb3J0IHsgTmF2aWdhdG9yIH0gZnJvbSBcIi4vTmF2aWdhdG9yXCI7XG4vKipcbiAqIEFuIEFJIHN0cmF0ZWd5IHRoYXQgZGVzY3JpYmVzIGEgYmVoYXZpb3VyIGluIHdoaWNoIHRoZSBhZ2VudCB0cmllcyB0byBtb3ZlIHRvIHRoZSBcbiAqIHdheXBvaW50IG9uIHRoZSB3YXlwb2ludCBncmFwaCBjbG9zZXN0IHRvIHRoZSB0YXJnZXQuXG4gKiBcbiAqIEl0IHdpbGwgbm90IHN0cmF5IGF3YXkgZnJvbSB0aGUgZ3JhcGggYmV5b25kIGEgZGlzdGFuY2UgZXF1YWwgdG8gdGhlIHNob3J0ZXN0IGVkZ2VcbiAqIG9uIHRoZSBncmFwaCdzIGxlbmd0aC5cbiAqL1xuZXhwb3J0IGNsYXNzIE5hdkNoYXNlciBleHRlbmRzIE5hdmlnYXRvcntcbiAgICAvKiogVGhlIGFnZW50J3Mgb3V0cHV0IHRvIElJbnB1dC4gKi9cbiAgICBwcml2YXRlIF9tb3ZlQXhpczJEID0gY2MuVmVjMi5aRVJPO1xuICAgIHByaXZhdGUgX21pbkdyYXBoRWRnZUxlbmd0aCA9IEluZmluaXR5O1xuICAgIHByaXZhdGUgX3J1blRvd2FyZHM6IGNjLk5vZGUgPSBudWxsO1xuICAgIGNvbnN0cnVjdG9yKGFnZW50OiBBZ2VudCwgd2F5cG9pbnRHcmFwaDogV2F5cG9pbnRHcmFwaCwgcnVuVG93YXJkczogY2MuTm9kZSkge1xuICAgICAgICBzdXBlcihhZ2VudCwgd2F5cG9pbnRHcmFwaCk7XG4gICAgICAgIHRoaXMuX3J1blRvd2FyZHMgPSBydW5Ub3dhcmRzO1xuICAgIH1cbiAgICBwcml2YXRlIF9uZXh0V2F5cG9pbnQ6IFdheXBvaW50ID0gbnVsbDtcbiAgICBwcm90ZWN0ZWQgZ2V0IG5leHRXYXlwb2ludCgpOiBXYXlwb2ludCB7XG4gICAgICAgIHJldHVybiB0aGlzLl9uZXh0V2F5cG9pbnQ7XG4gICAgfVxuICAgIHByb3RlY3RlZCBvblRyYW5zaXRpb25GaW5pc2goKTogdm9pZCB7XG4gICAgICAgIC8vKnx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHwqXFxcXFxuICAgICAgICAvLyBUT0RPICg0LjIpOiBDb21wbGV0ZSBOYXZDaGFzZXIncyBvblRyYW5zaXRpb25GaW5pc2ggbWV0aG9kLlxuICAgICAgICAvLyBbU1BFQ0lGSUNBVElPTlNdXG4gICAgICAgIC8vIC0gTmF2Q2hhc2VyIHNob3VsZCBtb3ZlIHRvd2FyZHMgdGhlIHdheXBvaW50IG9uIHRoZSB3YXlwb2ludCBncmFwaCBcbiAgICAgICAgLy8gICBjbG9zZXN0IHRvIHRoaXMuX3J1blRvd2FyZHMuXG4gICAgICAgIC8vIC0gQXNzaWduIHlvdXIgcmVzdWx0cyB0byB0aGlzLl9uZXh0V2F5cG9pbnQuXG4gICAgICAgIC8vKnx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHwqXFxcXFxuICAgICAgIFxuICAgICAgICAvLyNyZWdpb24gW1lPVVIgSU1QTEVNRU5UQVRJT04gSEVSRV1cbiAgICAgICAgXG4gICAgICAgIC8vI2VuZHJlZ2lvblxuICAgICAgICAvLyBjb25zb2xlLmxvZyhgTmF2Q2hhc2VyOiBDdXJyZW50OiAke3RoaXMuY3VycmVudFdheXBvaW50Lm5vZGUubmFtZX0sIE5leHQ6ICR7dGhpcy5uZXh0V2F5cG9pbnQubm9kZS5uYW1lfWApO1xuICAgIH1cbiAgICBwdWJsaWMgZ2V0IGhvcml6b250YWxBeGlzKCk6IG51bWJlciB7XG4gICAgICAgIHJldHVybiB0aGlzLl9tb3ZlQXhpczJELng7XG4gICAgfVxuICAgIHB1YmxpYyBnZXQgdmVydGljYWxBeGlzKCk6IG51bWJlciB7XG4gICAgICAgIHJldHVybiB0aGlzLl9tb3ZlQXhpczJELnk7XG4gICAgfVxuICAgIHB1YmxpYyBnZXQgYXR0YWNrKCk6IEJ1dHRvblN0YXRlIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiTWV0aG9kIG5vdCBpbXBsZW1lbnRlZC5cIik7XG4gICAgfVxuICAgIHB1YmxpYyBnZXQgaW50ZXJhY3QoKTogQnV0dG9uU3RhdGUge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJNZXRob2Qgbm90IGltcGxlbWVudGVkLlwiKTtcbiAgICB9XG4gICAgcHVibGljIGdldCB0b3dhcmRzVGFyZ2V0KCkge1xuICAgICAgICByZXR1cm4gIHRoaXMuX3J1blRvd2FyZHMucG9zaXRpb24uc3ViKHRoaXMuYWdlbnQubm9kZS5wb3NpdGlvbikubm9ybWFsaXplKCk7XG4gICAgfVxuXG4gICAgcHVibGljIGdldCBkaXN0YW5jZUZyb21UYXJnZXQoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9ydW5Ub3dhcmRzLnBvc2l0aW9uLnN1Yih0aGlzLmFnZW50Lm5vZGUucG9zaXRpb24pLm1hZygpXG4gICAgfVxuICAgIHB1YmxpYyBzdGFydCgpOiB2b2lkIHtcbiAgICAgICAgdGhpcy5fbmV4dFdheXBvaW50ID0gdGhpcy5jbG9zZXN0V2F5cG9pbnQ7XG4gICAgICAgIGZvciAobGV0IHdheXBvaW50IG9mIHRoaXMud2F5cG9pbnRHcmFwaC5hZGphY2VuY3lMaXN0KSB7XG4gICAgICAgICAgICBmb3IgKGxldCBkaXN0IG9mIHdheXBvaW50LmRpc3RhbmNlcykge1xuICAgICAgICAgICAgICAgIHRoaXMuX21pbkdyYXBoRWRnZUxlbmd0aCA9IE1hdGgubWluKHRoaXMuX21pbkdyYXBoRWRnZUxlbmd0aCwgZGlzdCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBwdWJsaWMgdXBkYXRlKGR0OiBudW1iZXIpOiB2b2lkIHtcbiAgICAgICAgaWYgKHRoaXMuZGlzdGFuY2VGcm9tVGFyZ2V0IDwgdGhpcy5fbWluR3JhcGhFZGdlTGVuZ3RoXG4gICAgICAgICAgICAmJiB0aGlzLmN1cnJlbnRXYXlwb2ludCAmJiB0aGlzLmN1cnJlbnRXYXlwb2ludC5kaXN0YW5jZVRvTm9kZSh0aGlzLmFnZW50Lm5vZGUpIDwgdGhpcy5fbWluR3JhcGhFZGdlTGVuZ3RoKSB7XG4gICAgICAgICAgICB0aGlzLl9tb3ZlQXhpczJEID0gdGhpcy50b3dhcmRzVGFyZ2V0O1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgc3VwZXIudXBkYXRlKGR0KTtcbiAgICAgICAgICAgIGlmICh0aGlzLmN1cnJlbnRXYXlwb2ludCA9PT0gdGhpcy5uZXh0V2F5cG9pbnQpIHtcbiAgICAgICAgICAgICAgICB0aGlzLl9tb3ZlQXhpczJEID0gY2MuVmVjMi5aRVJPO1xuICAgICAgICAgICAgICAgIHRoaXMub25UcmFuc2l0aW9uRmluaXNoKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHRoaXMuX21vdmVBeGlzMkQgPSB0aGlzLnRvd2FyZHNOZXh0V2F5cG9pbnQ7XG4gICAgICAgIH1cbiAgICAgICAgXG4gICAgfVxuXG59Il19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/ai/strategies/Wanderer.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '1f7aasmeZhNIoYFA83XzaqQ', 'Wanderer');
// scripts/ai/strategies/Wanderer.ts

Object.defineProperty(exports, "__esModule", { value: true });
exports.Wanderer = void 0;
var AgentStrategy_1 = require("./AgentStrategy");
/**
 * An AI strategy that describes a "wandering" behaviour.
 */
var Wanderer = /** @class */ (function (_super) {
    __extends(Wanderer, _super);
    function Wanderer(moveDuration, waitDuration, waitRandomFactor) {
        var _this = _super.call(this) || this;
        /** The agent will move for this long before stopping to wait. */
        _this._moveDuration = 1.0;
        /** The agent will wait for this long before starting to move again. */
        _this._waitDuration = 0.5;
        /** The actual wait duration will be randomized by this factor,
         *  such that the actual wait duration is a random number between
         *  waitDuration x (1 - waitRandomFactor) and
         *  waitDuration x (1 + waitRandomFactor).
        */
        _this._waitRandomFactor = 0.1;
        /** The time point after which the agent should wait. */
        _this._nextWaitTime = 0;
        /** The time point after which the agent should move again. */
        _this._nextMoveTime = 0;
        /** The velocity (vector with magnitude) at which the agent should move. */
        _this._wanderVelocity = cc.Vec2.ZERO;
        /** The agent's output to IInput. */
        _this._moveAxis2D = cc.Vec2.ZERO;
        //*||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||*\\
        // TODO (1.1): Complete the constructor.
        // [SPECIFICATIONS]
        // - Initialize the three private variables above properly.
        //*||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||*\\
        //#region [YOUR IMPLEMENTATION HERE]
        _this._moveDuration = moveDuration;
        _this._waitDuration = waitDuration;
        _this._waitRandomFactor = waitRandomFactor;
        return _this;
        //#endregion
    }
    Object.defineProperty(Wanderer.prototype, "horizontalAxis", {
        //*||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||*\\
        // TODO (1.2): Map moveAxis2D to horizontal and vertical axes.
        // [SPECIFICATIONS]
        // - _moveAxis2D.x should be mapped to the horizontal axis.
        // - _moveAxis2D.y should be mapped to the vertical axis.
        // - You can leave attack() and interact() unimplemented.
        //*||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||*\\
        get: function () {
            //#region [YOUR IMPLEMENTATION HERE]
            return this._moveAxis2D.x;
            //#endregion
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Wanderer.prototype, "verticalAxis", {
        get: function () {
            //#region [YOUR IMPLEMENTATION HERE]
            return this._moveAxis2D.y;
            //#endregion
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Wanderer.prototype, "attack", {
        get: function () {
            throw new Error("Method not implemented.");
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Wanderer.prototype, "interact", {
        get: function () {
            throw new Error("Method not implemented.");
        },
        enumerable: false,
        configurable: true
    });
    Wanderer.prototype.start = function () {
        this._nextMoveTime = cc.director.getTotalTime() / 1000.0;
        this._nextWaitTime = this._nextMoveTime - this._waitDuration;
    };
    Wanderer.prototype.update = function (dt) {
        /** The current time in the game in seconds. */
        var currentTime = cc.director.getTotalTime() / 1000.0;
        //*||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||*\\
        // TODO (1.3): Implement the behaviour of a wandering agent.
        // [SPECIFICATIONS]
        // 1. The agent should recompute its wandering direction when the
        //    current time (currentTime) reaches the next move time (this._nextMoveTime)
        //     - When this happens, recompute the next move time and the next wait 
        //       time.
        //     - Compute the wandering direction as a random 2D vector using the
        //       provided function "randomPointOnCircle".
        // 2. The agent's movement axes (this._moveAxis2D)
        //    should be equal to the wander velocity (this._wanderVelocity) before
        //    the next wait time (this._nextWaitTime) arrives. 
        //    OTHERWISE it should be equal to cc.Vec2.ZERO.
        //*||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||*\\
        if (currentTime >= this._nextMoveTime) {
            this._nextWaitTime = currentTime + this._moveDuration;
            this._nextMoveTime = this._nextWaitTime + this._waitDuration * (1 + this._waitRandomFactor * (Math.random() * 2.0 - 1.0));
            this._wanderVelocity = randomPointOnUnitCircle();
        }
        if (currentTime < this._nextWaitTime) {
            this._moveAxis2D = this._wanderVelocity;
        }
        else
            this._moveAxis2D = cc.Vec2.Zero;
        //#region [YOUR IMPLEMENTATION HERE]
        //#endregion
    };
    return Wanderer;
}(AgentStrategy_1.AI.Strategy));
exports.Wanderer = Wanderer;
function randomPointOnUnitCircle() {
    var angle = Math.random() * Math.PI * 2;
    return new cc.Vec2(Math.cos(angle), Math.sin(angle));
}

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcYWlcXHN0cmF0ZWdpZXNcXFdhbmRlcmVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBRUEsaURBQXFDO0FBRXJDOztHQUVHO0FBQ0g7SUFBOEIsNEJBQVc7SUFZckMsa0JBQVksWUFBbUIsRUFBRSxZQUFtQixFQUFFLGdCQUF1QjtRQUE3RSxZQUNJLGlCQUFPLFNBV1Y7UUF2QkQsaUVBQWlFO1FBQ3pELG1CQUFhLEdBQUcsR0FBRyxDQUFDO1FBQzVCLHVFQUF1RTtRQUMvRCxtQkFBYSxHQUFHLEdBQUcsQ0FBQztRQUM1Qjs7OztVQUlFO1FBQ08sdUJBQWlCLEdBQUcsR0FBRyxDQUFDO1FBZ0JqQyx3REFBd0Q7UUFDaEQsbUJBQWEsR0FBRyxDQUFDLENBQUM7UUFDMUIsOERBQThEO1FBQ3RELG1CQUFhLEdBQUcsQ0FBQyxDQUFDO1FBQzFCLDJFQUEyRTtRQUNuRSxxQkFBZSxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO1FBQ3ZDLG9DQUFvQztRQUM1QixpQkFBVyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO1FBbkIvQiw0RUFBNEU7UUFDNUUsd0NBQXdDO1FBQ3hDLG1CQUFtQjtRQUNuQiwyREFBMkQ7UUFDM0QsNEVBQTRFO1FBQzVFLG9DQUFvQztRQUNwQyxLQUFJLENBQUMsYUFBYSxHQUFHLFlBQVksQ0FBQztRQUNsQyxLQUFJLENBQUMsYUFBYSxHQUFHLFlBQVksQ0FBQztRQUNsQyxLQUFJLENBQUMsaUJBQWlCLEdBQUcsZ0JBQWdCLENBQUM7O1FBQzFDLFlBQVk7SUFDaEIsQ0FBQztJQWtCRCxzQkFBVyxvQ0FBYztRQVB6Qiw0RUFBNEU7UUFDNUUsOERBQThEO1FBQzlELG1CQUFtQjtRQUNuQiwyREFBMkQ7UUFDM0QseURBQXlEO1FBQ3pELHlEQUF5RDtRQUN6RCw0RUFBNEU7YUFDNUU7WUFDSSxvQ0FBb0M7WUFDcEMsT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQztZQUMxQixZQUFZO1FBQ2hCLENBQUM7OztPQUFBO0lBQ0Qsc0JBQVcsa0NBQVk7YUFBdkI7WUFDSSxvQ0FBb0M7WUFDcEMsT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQztZQUMxQixZQUFZO1FBQ2hCLENBQUM7OztPQUFBO0lBQ0Qsc0JBQVcsNEJBQU07YUFBakI7WUFDSSxNQUFNLElBQUksS0FBSyxDQUFDLHlCQUF5QixDQUFDLENBQUM7UUFDL0MsQ0FBQzs7O09BQUE7SUFDRCxzQkFBVyw4QkFBUTthQUFuQjtZQUNJLE1BQU0sSUFBSSxLQUFLLENBQUMseUJBQXlCLENBQUMsQ0FBQztRQUMvQyxDQUFDOzs7T0FBQTtJQUVNLHdCQUFLLEdBQVo7UUFDSSxJQUFJLENBQUMsYUFBYSxHQUFHLEVBQUUsQ0FBQyxRQUFRLENBQUMsWUFBWSxFQUFFLEdBQUcsTUFBTSxDQUFDO1FBQ3pELElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDO0lBQ2pFLENBQUM7SUFDTSx5QkFBTSxHQUFiLFVBQWMsRUFBVTtRQUNwQiwrQ0FBK0M7UUFDL0MsSUFBSSxXQUFXLEdBQUcsRUFBRSxDQUFDLFFBQVEsQ0FBQyxZQUFZLEVBQUUsR0FBRyxNQUFNLENBQUM7UUFFdEQsNEVBQTRFO1FBQzVFLDREQUE0RDtRQUM1RCxtQkFBbUI7UUFDbkIsaUVBQWlFO1FBQ2pFLGdGQUFnRjtRQUNoRiwyRUFBMkU7UUFDM0UsY0FBYztRQUNkLHdFQUF3RTtRQUN4RSxpREFBaUQ7UUFDakQsa0RBQWtEO1FBQ2xELDBFQUEwRTtRQUMxRSx1REFBdUQ7UUFDdkQsbURBQW1EO1FBQ25ELDRFQUE0RTtRQUM1RSxJQUFHLFdBQVcsSUFBRSxJQUFJLENBQUMsYUFBYSxFQUNsQztZQUNJLElBQUksQ0FBQyxhQUFhLEdBQUcsV0FBVyxHQUFDLElBQUksQ0FBQyxhQUFhLENBQUM7WUFDcEQsSUFBSSxDQUFDLGFBQWEsR0FBQyxJQUFJLENBQUMsYUFBYSxHQUFFLElBQUksQ0FBQyxhQUFhLEdBQUMsQ0FBQyxDQUFDLEdBQUMsSUFBSSxDQUFDLGlCQUFpQixHQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxHQUFDLEdBQUcsR0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO1lBQzdHLElBQUksQ0FBQyxlQUFlLEdBQUMsdUJBQXVCLEVBQUUsQ0FBQztTQUdsRDtRQUNELElBQUcsV0FBVyxHQUFDLElBQUksQ0FBQyxhQUFhLEVBQ2pDO1lBQ0ksSUFBSSxDQUFDLFdBQVcsR0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDO1NBRXpDOztZQUNJLElBQUksQ0FBQyxXQUFXLEdBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7UUFFbkMsb0NBQW9DO1FBRXBDLFlBQVk7SUFDaEIsQ0FBQztJQUVMLGVBQUM7QUFBRCxDQXJHQSxBQXFHQyxDQXJHNkIsa0JBQUUsQ0FBQyxRQUFRLEdBcUd4QztBQXJHWSw0QkFBUTtBQXVHckIsU0FBUyx1QkFBdUI7SUFDNUIsSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLE1BQU0sRUFBRSxHQUFHLElBQUksQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDO0lBQ3hDLE9BQU8sSUFBSSxFQUFFLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLEVBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO0FBQ3pELENBQUMiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBCdXR0b25TdGF0ZSB9IGZyb20gXCIuLi8uLi9pbnB1dC9JSW5wdXRDb250cm9sc1wiO1xuaW1wb3J0IEFnZW50IGZyb20gXCIuLi9BZ2VudFwiO1xuaW1wb3J0IHsgQUkgfSBmcm9tIFwiLi9BZ2VudFN0cmF0ZWd5XCI7XG5cbi8qKlxuICogQW4gQUkgc3RyYXRlZ3kgdGhhdCBkZXNjcmliZXMgYSBcIndhbmRlcmluZ1wiIGJlaGF2aW91ci5cbiAqL1xuZXhwb3J0IGNsYXNzIFdhbmRlcmVyIGV4dGVuZHMgQUkuU3RyYXRlZ3l7XG4gICAgLyoqIFRoZSBhZ2VudCB3aWxsIG1vdmUgZm9yIHRoaXMgbG9uZyBiZWZvcmUgc3RvcHBpbmcgdG8gd2FpdC4gKi9cbiAgICBwcml2YXRlIF9tb3ZlRHVyYXRpb24gPSAxLjA7XG4gICAgLyoqIFRoZSBhZ2VudCB3aWxsIHdhaXQgZm9yIHRoaXMgbG9uZyBiZWZvcmUgc3RhcnRpbmcgdG8gbW92ZSBhZ2Fpbi4gKi9cbiAgICBwcml2YXRlIF93YWl0RHVyYXRpb24gPSAwLjU7XG4gICAgLyoqIFRoZSBhY3R1YWwgd2FpdCBkdXJhdGlvbiB3aWxsIGJlIHJhbmRvbWl6ZWQgYnkgdGhpcyBmYWN0b3IsIFxuICAgICAqICBzdWNoIHRoYXQgdGhlIGFjdHVhbCB3YWl0IGR1cmF0aW9uIGlzIGEgcmFuZG9tIG51bWJlciBiZXR3ZWVuXG4gICAgICogIHdhaXREdXJhdGlvbiB4ICgxIC0gd2FpdFJhbmRvbUZhY3RvcikgYW5kIFxuICAgICAqICB3YWl0RHVyYXRpb24geCAoMSArIHdhaXRSYW5kb21GYWN0b3IpLlxuICAgICovXG4gICAgIHByaXZhdGUgX3dhaXRSYW5kb21GYWN0b3IgPSAwLjE7XG5cbiAgICBjb25zdHJ1Y3Rvcihtb3ZlRHVyYXRpb246bnVtYmVyLCB3YWl0RHVyYXRpb246bnVtYmVyLCB3YWl0UmFuZG9tRmFjdG9yOm51bWJlcikge1xuICAgICAgICBzdXBlcigpO1xuICAgICAgICAvLyp8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8KlxcXFxcbiAgICAgICAgLy8gVE9ETyAoMS4xKTogQ29tcGxldGUgdGhlIGNvbnN0cnVjdG9yLlxuICAgICAgICAvLyBbU1BFQ0lGSUNBVElPTlNdXG4gICAgICAgIC8vIC0gSW5pdGlhbGl6ZSB0aGUgdGhyZWUgcHJpdmF0ZSB2YXJpYWJsZXMgYWJvdmUgcHJvcGVybHkuXG4gICAgICAgIC8vKnx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHwqXFxcXFxuICAgICAgICAvLyNyZWdpb24gW1lPVVIgSU1QTEVNRU5UQVRJT04gSEVSRV1cbiAgICAgICAgdGhpcy5fbW92ZUR1cmF0aW9uID0gbW92ZUR1cmF0aW9uO1xuICAgICAgICB0aGlzLl93YWl0RHVyYXRpb24gPSB3YWl0RHVyYXRpb247XG4gICAgICAgIHRoaXMuX3dhaXRSYW5kb21GYWN0b3IgPSB3YWl0UmFuZG9tRmFjdG9yO1xuICAgICAgICAvLyNlbmRyZWdpb25cbiAgICB9XG5cbiAgICAvKiogVGhlIHRpbWUgcG9pbnQgYWZ0ZXIgd2hpY2ggdGhlIGFnZW50IHNob3VsZCB3YWl0LiAqL1xuICAgIHByaXZhdGUgX25leHRXYWl0VGltZSA9IDA7XG4gICAgLyoqIFRoZSB0aW1lIHBvaW50IGFmdGVyIHdoaWNoIHRoZSBhZ2VudCBzaG91bGQgbW92ZSBhZ2Fpbi4gKi9cbiAgICBwcml2YXRlIF9uZXh0TW92ZVRpbWUgPSAwO1xuICAgIC8qKiBUaGUgdmVsb2NpdHkgKHZlY3RvciB3aXRoIG1hZ25pdHVkZSkgYXQgd2hpY2ggdGhlIGFnZW50IHNob3VsZCBtb3ZlLiAqL1xuICAgIHByaXZhdGUgX3dhbmRlclZlbG9jaXR5ID0gY2MuVmVjMi5aRVJPO1xuICAgIC8qKiBUaGUgYWdlbnQncyBvdXRwdXQgdG8gSUlucHV0LiAqL1xuICAgIHByaXZhdGUgX21vdmVBeGlzMkQgPSBjYy5WZWMyLlpFUk87XG5cbiAgICAvLyp8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8KlxcXFxcbiAgICAvLyBUT0RPICgxLjIpOiBNYXAgbW92ZUF4aXMyRCB0byBob3Jpem9udGFsIGFuZCB2ZXJ0aWNhbCBheGVzLlxuICAgIC8vIFtTUEVDSUZJQ0FUSU9OU11cbiAgICAvLyAtIF9tb3ZlQXhpczJELnggc2hvdWxkIGJlIG1hcHBlZCB0byB0aGUgaG9yaXpvbnRhbCBheGlzLlxuICAgIC8vIC0gX21vdmVBeGlzMkQueSBzaG91bGQgYmUgbWFwcGVkIHRvIHRoZSB2ZXJ0aWNhbCBheGlzLlxuICAgIC8vIC0gWW91IGNhbiBsZWF2ZSBhdHRhY2soKSBhbmQgaW50ZXJhY3QoKSB1bmltcGxlbWVudGVkLlxuICAgIC8vKnx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHwqXFxcXFxuICAgIHB1YmxpYyBnZXQgaG9yaXpvbnRhbEF4aXMoKTogbnVtYmVyIHtcbiAgICAgICAgLy8jcmVnaW9uIFtZT1VSIElNUExFTUVOVEFUSU9OIEhFUkVdXG4gICAgICAgIHJldHVybiB0aGlzLl9tb3ZlQXhpczJELng7XG4gICAgICAgIC8vI2VuZHJlZ2lvblxuICAgIH1cbiAgICBwdWJsaWMgZ2V0IHZlcnRpY2FsQXhpcygpOiBudW1iZXIge1xuICAgICAgICAvLyNyZWdpb24gW1lPVVIgSU1QTEVNRU5UQVRJT04gSEVSRV1cbiAgICAgICAgcmV0dXJuIHRoaXMuX21vdmVBeGlzMkQueTtcbiAgICAgICAgLy8jZW5kcmVnaW9uXG4gICAgfVxuICAgIHB1YmxpYyBnZXQgYXR0YWNrKCk6IEJ1dHRvblN0YXRlIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiTWV0aG9kIG5vdCBpbXBsZW1lbnRlZC5cIik7XG4gICAgfVxuICAgIHB1YmxpYyBnZXQgaW50ZXJhY3QoKTogQnV0dG9uU3RhdGUge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJNZXRob2Qgbm90IGltcGxlbWVudGVkLlwiKTtcbiAgICB9XG5cbiAgICBwdWJsaWMgc3RhcnQoKSB7XG4gICAgICAgIHRoaXMuX25leHRNb3ZlVGltZSA9IGNjLmRpcmVjdG9yLmdldFRvdGFsVGltZSgpIC8gMTAwMC4wO1xuICAgICAgICB0aGlzLl9uZXh0V2FpdFRpbWUgPSB0aGlzLl9uZXh0TW92ZVRpbWUgLSB0aGlzLl93YWl0RHVyYXRpb247XG4gICAgfVxuICAgIHB1YmxpYyB1cGRhdGUoZHQ6IG51bWJlcikge1xuICAgICAgICAvKiogVGhlIGN1cnJlbnQgdGltZSBpbiB0aGUgZ2FtZSBpbiBzZWNvbmRzLiAqL1xuICAgICAgICBsZXQgY3VycmVudFRpbWUgPSBjYy5kaXJlY3Rvci5nZXRUb3RhbFRpbWUoKSAvIDEwMDAuMDtcblxuICAgICAgICAvLyp8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8KlxcXFxcbiAgICAgICAgLy8gVE9ETyAoMS4zKTogSW1wbGVtZW50IHRoZSBiZWhhdmlvdXIgb2YgYSB3YW5kZXJpbmcgYWdlbnQuXG4gICAgICAgIC8vIFtTUEVDSUZJQ0FUSU9OU11cbiAgICAgICAgLy8gMS4gVGhlIGFnZW50IHNob3VsZCByZWNvbXB1dGUgaXRzIHdhbmRlcmluZyBkaXJlY3Rpb24gd2hlbiB0aGVcbiAgICAgICAgLy8gICAgY3VycmVudCB0aW1lIChjdXJyZW50VGltZSkgcmVhY2hlcyB0aGUgbmV4dCBtb3ZlIHRpbWUgKHRoaXMuX25leHRNb3ZlVGltZSlcbiAgICAgICAgLy8gICAgIC0gV2hlbiB0aGlzIGhhcHBlbnMsIHJlY29tcHV0ZSB0aGUgbmV4dCBtb3ZlIHRpbWUgYW5kIHRoZSBuZXh0IHdhaXQgXG4gICAgICAgIC8vICAgICAgIHRpbWUuXG4gICAgICAgIC8vICAgICAtIENvbXB1dGUgdGhlIHdhbmRlcmluZyBkaXJlY3Rpb24gYXMgYSByYW5kb20gMkQgdmVjdG9yIHVzaW5nIHRoZVxuICAgICAgICAvLyAgICAgICBwcm92aWRlZCBmdW5jdGlvbiBcInJhbmRvbVBvaW50T25DaXJjbGVcIi5cbiAgICAgICAgLy8gMi4gVGhlIGFnZW50J3MgbW92ZW1lbnQgYXhlcyAodGhpcy5fbW92ZUF4aXMyRClcbiAgICAgICAgLy8gICAgc2hvdWxkIGJlIGVxdWFsIHRvIHRoZSB3YW5kZXIgdmVsb2NpdHkgKHRoaXMuX3dhbmRlclZlbG9jaXR5KSBiZWZvcmVcbiAgICAgICAgLy8gICAgdGhlIG5leHQgd2FpdCB0aW1lICh0aGlzLl9uZXh0V2FpdFRpbWUpIGFycml2ZXMuIFxuICAgICAgICAvLyAgICBPVEhFUldJU0UgaXQgc2hvdWxkIGJlIGVxdWFsIHRvIGNjLlZlYzIuWkVSTy5cbiAgICAgICAgLy8qfHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fCpcXFxcXG4gICAgICAgIGlmKGN1cnJlbnRUaW1lPj10aGlzLl9uZXh0TW92ZVRpbWUpXG4gICAgICAgIHtcbiAgICAgICAgICAgIHRoaXMuX25leHRXYWl0VGltZSA9IGN1cnJlbnRUaW1lK3RoaXMuX21vdmVEdXJhdGlvbjtcbiAgICAgICAgICAgIHRoaXMuX25leHRNb3ZlVGltZT10aGlzLl9uZXh0V2FpdFRpbWUgK3RoaXMuX3dhaXREdXJhdGlvbiooMSt0aGlzLl93YWl0UmFuZG9tRmFjdG9yKihNYXRoLnJhbmRvbSgpKjIuMC0xLjApKTtcbiAgICAgICAgICAgIHRoaXMuX3dhbmRlclZlbG9jaXR5PXJhbmRvbVBvaW50T25Vbml0Q2lyY2xlKCk7XG5cbiAgICAgICAgICAgIFxuICAgICAgICB9XG4gICAgICAgIGlmKGN1cnJlbnRUaW1lPHRoaXMuX25leHRXYWl0VGltZSlcbiAgICAgICAge1xuICAgICAgICAgICAgdGhpcy5fbW92ZUF4aXMyRD10aGlzLl93YW5kZXJWZWxvY2l0eTtcblxuICAgICAgICB9XG4gICAgICAgIGVsc2UgdGhpcy5fbW92ZUF4aXMyRD1jYy5WZWMyLlplcm87XG4gICAgICAgIFxuICAgICAgICAvLyNyZWdpb24gW1lPVVIgSU1QTEVNRU5UQVRJT04gSEVSRV1cbiAgICAgICAgXG4gICAgICAgIC8vI2VuZHJlZ2lvblxuICAgIH1cblxufVxuXG5mdW5jdGlvbiByYW5kb21Qb2ludE9uVW5pdENpcmNsZSgpIHtcbiAgICBsZXQgYW5nbGUgPSBNYXRoLnJhbmRvbSgpICogTWF0aC5QSSAqIDI7XG4gICAgcmV0dXJuIG5ldyBjYy5WZWMyKE1hdGguY29zKGFuZ2xlKSwgTWF0aC5zaW4oYW5nbGUpKTtcbn0iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/input/Controller.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '28ae2OQzsFN+6aNxTuvpevg', 'Controller');
// scripts/input/Controller.ts

// Learn TypeScript:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/typescript.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/life-cycle-callbacks.html
Object.defineProperty(exports, "__esModule", { value: true });
var IInputControls_1 = require("./IInputControls");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var Controller = /** @class */ (function (_super) {
    __extends(Controller, _super);
    function Controller() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.inputSource = null;
        return _this;
    }
    Controller.prototype.start = function () {
        this.registerInput(this.node.getComponents(cc.Component).find(function (component) { return IInputControls_1.hasImplementedInputControls(component); }));
    };
    Controller.prototype.registerInput = function (input) {
        if (input !== null)
            this.inputSource = input;
    };
    return Controller;
}(cc.Component));
exports.default = Controller;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcaW5wdXRcXENvbnRyb2xsZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsb0JBQW9CO0FBQ3BCLGtGQUFrRjtBQUNsRix5RkFBeUY7QUFDekYsbUJBQW1CO0FBQ25CLDRGQUE0RjtBQUM1RixtR0FBbUc7QUFDbkcsOEJBQThCO0FBQzlCLDRGQUE0RjtBQUM1RixtR0FBbUc7O0FBRW5HLG1EQUErRTtBQUV6RSxJQUFBLEtBQXNCLEVBQUUsQ0FBQyxVQUFVLEVBQWxDLE9BQU8sYUFBQSxFQUFFLFFBQVEsY0FBaUIsQ0FBQztBQUUxQztJQUFpRCw4QkFBWTtJQUE3RDtRQUFBLHFFQVdDO1FBVGEsaUJBQVcsR0FBbUIsSUFBSSxDQUFDOztJQVNqRCxDQUFDO0lBUkcsMEJBQUssR0FBTDtRQUNJLElBQUksQ0FBQyxhQUFhLENBQU0sSUFBSSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRSxDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFBLFNBQVMsSUFBSSxPQUFBLDRDQUEyQixDQUFNLFNBQVMsQ0FBQyxFQUEzQyxDQUEyQyxDQUFDLENBQUMsQ0FBQztJQUNsSSxDQUFDO0lBQ00sa0NBQWEsR0FBcEIsVUFBcUIsS0FBcUI7UUFDdEMsSUFBRyxLQUFLLEtBQUssSUFBSTtZQUNiLElBQUksQ0FBQyxXQUFXLEdBQUcsS0FBSyxDQUFDO0lBQ2pDLENBQUM7SUFFTCxpQkFBQztBQUFELENBWEEsQUFXQyxDQVhnRCxFQUFFLENBQUMsU0FBUyxHQVc1RCIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8vIExlYXJuIFR5cGVTY3JpcHQ6XG4vLyAgLSBbQ2hpbmVzZV0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC96aC9zY3JpcHRpbmcvdHlwZXNjcmlwdC5odG1sXG4vLyAgLSBbRW5nbGlzaF0gaHR0cDovL3d3dy5jb2NvczJkLXgub3JnL2RvY3MvY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3R5cGVzY3JpcHQuaHRtbFxuLy8gTGVhcm4gQXR0cmlidXRlOlxuLy8gIC0gW0NoaW5lc2VdIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvemgvc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcbi8vICAtIFtFbmdsaXNoXSBodHRwOi8vd3d3LmNvY29zMmQteC5vcmcvZG9jcy9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvcmVmZXJlbmNlL2F0dHJpYnV0ZXMuaHRtbFxuLy8gTGVhcm4gbGlmZS1jeWNsZSBjYWxsYmFja3M6XG4vLyAgLSBbQ2hpbmVzZV0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC96aC9zY3JpcHRpbmcvbGlmZS1jeWNsZS1jYWxsYmFja3MuaHRtbFxuLy8gIC0gW0VuZ2xpc2hdIGh0dHA6Ly93d3cuY29jb3MyZC14Lm9yZy9kb2NzL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9saWZlLWN5Y2xlLWNhbGxiYWNrcy5odG1sXG5cbmltcG9ydCB7IGhhc0ltcGxlbWVudGVkSW5wdXRDb250cm9scywgSUlucHV0Q29udHJvbHMgfSBmcm9tIFwiLi9JSW5wdXRDb250cm9sc1wiO1xuXG5jb25zdCB7Y2NjbGFzcywgcHJvcGVydHl9ID0gY2MuX2RlY29yYXRvcjtcblxuZXhwb3J0IGRlZmF1bHQgYWJzdHJhY3QgY2xhc3MgQ29udHJvbGxlciBleHRlbmRzIGNjLkNvbXBvbmVudCB7XG5cbiAgICBwcm90ZWN0ZWQgaW5wdXRTb3VyY2U6IElJbnB1dENvbnRyb2xzID0gbnVsbDtcbiAgICBzdGFydCgpOiB2b2lkIHtcbiAgICAgICAgdGhpcy5yZWdpc3RlcklucHV0KDxhbnk+dGhpcy5ub2RlLmdldENvbXBvbmVudHMoY2MuQ29tcG9uZW50KS5maW5kKGNvbXBvbmVudCA9PiBoYXNJbXBsZW1lbnRlZElucHV0Q29udHJvbHMoPGFueT5jb21wb25lbnQpKSk7XG4gICAgfVxuICAgIHB1YmxpYyByZWdpc3RlcklucHV0KGlucHV0OiBJSW5wdXRDb250cm9scykge1xuICAgICAgICBpZihpbnB1dCAhPT0gbnVsbClcbiAgICAgICAgICAgIHRoaXMuaW5wdXRTb3VyY2UgPSBpbnB1dDtcbiAgICB9XG5cbn1cbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/ai/strategies/Navigator.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '0dc98ixyLFFibjA0wrj35+d', 'Navigator');
// scripts/ai/strategies/Navigator.ts

// Learn TypeScript:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/typescript.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/life-cycle-callbacks.html
Object.defineProperty(exports, "__esModule", { value: true });
exports.Navigator = void 0;
var AgentStrategy_1 = require("./AgentStrategy");
var Navigator = /** @class */ (function (_super) {
    __extends(Navigator, _super);
    function Navigator(_agent, _waypointGraph) {
        var _this = _super.call(this) || this;
        _this.waypointGraph = null;
        _this.agent = null;
        _this.currentWaypoint = null;
        _this.agent = _agent;
        _this.waypointGraph = _waypointGraph;
        return _this;
    }
    Object.defineProperty(Navigator.prototype, "closestWaypoint", {
        //*||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||*\\
        // TODO (3.1): Implement closestWaypoint using this.waypointGraph.adjacencyList.
        // [SPECIFICATIONS]
        // - You need to iterate through this.waypointGraph.adjacencyList to find the
        //   waypoint that minimizes the distance between it and the agent's node.
        // - You can use Waypoint.distanceToNode defined in Waypoint.ts.
        //*||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||*\\
        /** The closest waypoint on the waypoint graph assigned to the Navigator. */
        get: function () {
            //#region [YOUR IMPLEMENTATION HERE]
            return this.waypointGraph.adjacencyList[0];
            //#endregion
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Navigator.prototype, "towardsNextWaypoint", {
        /** A unit 2D vector pointing from the agent's position
         * to the next waypoint's position */
        get: function () {
            return this.nextWaypoint.node.convertToWorldSpaceAR(cc.Vec2.ZERO).sub(this.agent.node.convertToWorldSpaceAR(cc.Vec2.ZERO)).normalize();
        },
        enumerable: false,
        configurable: true
    });
    /**
     * Navigator.ts's update method will check if the agent has reached past
     * the next waypoint and call onTransitionFinish() accordingly.
     *
     * Exactly how the agent should move to the next waypoint should be
     * implemented by the strategies that inherit Navigator.
     * @param dt
     */
    Navigator.prototype.update = function (dt) {
        var dist = this.nextWaypoint.distanceToNode(this.agent.node);
        if (dist < 1.0) {
            // This indicates that the agent is moving past the next waypoint.
            // Therefore, the agent has reached the waypoint.
            this.currentWaypoint = this.nextWaypoint;
            this.onTransitionFinish();
        }
    };
    return Navigator;
}(AgentStrategy_1.AI.Strategy));
exports.Navigator = Navigator;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcYWlcXHN0cmF0ZWdpZXNcXE5hdmlnYXRvci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7QUFBQSxvQkFBb0I7QUFDcEIsa0ZBQWtGO0FBQ2xGLHlGQUF5RjtBQUN6RixtQkFBbUI7QUFDbkIsNEZBQTRGO0FBQzVGLG1HQUFtRztBQUNuRyw4QkFBOEI7QUFDOUIsNEZBQTRGO0FBQzVGLG1HQUFtRzs7O0FBS25HLGlEQUFxQztBQUVyQztJQUF3Qyw2QkFBVztJQXlCL0MsbUJBQVksTUFBYSxFQUFFLGNBQTZCO1FBQXhELFlBQ0ksaUJBQU8sU0FHVjtRQTNCUyxtQkFBYSxHQUFrQixJQUFJLENBQUM7UUFDcEMsV0FBSyxHQUFVLElBQUksQ0FBQztRQUNwQixxQkFBZSxHQUFhLElBQUksQ0FBQztRQXVCdkMsS0FBSSxDQUFDLEtBQUssR0FBRyxNQUFNLENBQUM7UUFDcEIsS0FBSSxDQUFDLGFBQWEsR0FBRyxjQUFjLENBQUM7O0lBQ3hDLENBQUM7SUFoQkQsc0JBQWMsc0NBQWU7UUFSN0IsNEVBQTRFO1FBQzVFLGdGQUFnRjtRQUNoRixtQkFBbUI7UUFDbkIsNkVBQTZFO1FBQzdFLDBFQUEwRTtRQUMxRSxnRUFBZ0U7UUFDaEUsNEVBQTRFO1FBQzVFLDRFQUE0RTthQUM1RTtZQUNJLG9DQUFvQztZQUNwQyxPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQzNDLFlBQVk7UUFDaEIsQ0FBQzs7O09BQUE7SUFJRCxzQkFBYywwQ0FBbUI7UUFGakM7NkNBQ3FDO2FBQ3JDO1lBQ0ksT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsU0FBUyxFQUFFLENBQUM7UUFDM0ksQ0FBQzs7O09BQUE7SUFZRDs7Ozs7OztPQU9HO0lBQ0ksMEJBQU0sR0FBYixVQUFjLEVBQVU7UUFDcEIsSUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUM3RCxJQUFJLElBQUksR0FBRyxHQUFHLEVBQUU7WUFDWixrRUFBa0U7WUFDbEUsaURBQWlEO1lBQ2pELElBQUksQ0FBQyxlQUFlLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQztZQUN6QyxJQUFJLENBQUMsa0JBQWtCLEVBQUUsQ0FBQztTQUU3QjtJQUNMLENBQUM7SUFFTCxnQkFBQztBQUFELENBdERBLEFBc0RDLENBdER1QyxrQkFBRSxDQUFDLFFBQVEsR0FzRGxEO0FBdERxQiw4QkFBUyIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8vIExlYXJuIFR5cGVTY3JpcHQ6XG4vLyAgLSBbQ2hpbmVzZV0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC96aC9zY3JpcHRpbmcvdHlwZXNjcmlwdC5odG1sXG4vLyAgLSBbRW5nbGlzaF0gaHR0cDovL3d3dy5jb2NvczJkLXgub3JnL2RvY3MvY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3R5cGVzY3JpcHQuaHRtbFxuLy8gTGVhcm4gQXR0cmlidXRlOlxuLy8gIC0gW0NoaW5lc2VdIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvemgvc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcbi8vICAtIFtFbmdsaXNoXSBodHRwOi8vd3d3LmNvY29zMmQteC5vcmcvZG9jcy9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvcmVmZXJlbmNlL2F0dHJpYnV0ZXMuaHRtbFxuLy8gTGVhcm4gbGlmZS1jeWNsZSBjYWxsYmFja3M6XG4vLyAgLSBbQ2hpbmVzZV0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC96aC9zY3JpcHRpbmcvbGlmZS1jeWNsZS1jYWxsYmFja3MuaHRtbFxuLy8gIC0gW0VuZ2xpc2hdIGh0dHA6Ly93d3cuY29jb3MyZC14Lm9yZy9kb2NzL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9saWZlLWN5Y2xlLWNhbGxiYWNrcy5odG1sXG5cbmltcG9ydCBBZ2VudCBmcm9tIFwiLi4vQWdlbnRcIjtcbmltcG9ydCBXYXlwb2ludCBmcm9tIFwiLi4vbmF2aWdhdGlvbi9XYXlwb2ludFwiO1xuaW1wb3J0IFdheXBvaW50R3JhcGggZnJvbSBcIi4uL25hdmlnYXRpb24vV2F5cG9pbnRHcmFwaFwiO1xuaW1wb3J0IHsgQUkgfSBmcm9tIFwiLi9BZ2VudFN0cmF0ZWd5XCI7XG5cbmV4cG9ydCBhYnN0cmFjdCBjbGFzcyBOYXZpZ2F0b3IgZXh0ZW5kcyBBSS5TdHJhdGVneSB7XG5cbiAgICBwcm90ZWN0ZWQgd2F5cG9pbnRHcmFwaDogV2F5cG9pbnRHcmFwaCA9IG51bGw7XG4gICAgcHJvdGVjdGVkIGFnZW50OiBBZ2VudCA9IG51bGw7XG4gICAgcHJvdGVjdGVkIGN1cnJlbnRXYXlwb2ludDogV2F5cG9pbnQgPSBudWxsO1xuICAgIC8vKnx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHwqXFxcXFxuICAgIC8vIFRPRE8gKDMuMSk6IEltcGxlbWVudCBjbG9zZXN0V2F5cG9pbnQgdXNpbmcgdGhpcy53YXlwb2ludEdyYXBoLmFkamFjZW5jeUxpc3QuXG4gICAgLy8gW1NQRUNJRklDQVRJT05TXVxuICAgIC8vIC0gWW91IG5lZWQgdG8gaXRlcmF0ZSB0aHJvdWdoIHRoaXMud2F5cG9pbnRHcmFwaC5hZGphY2VuY3lMaXN0IHRvIGZpbmQgdGhlXG4gICAgLy8gICB3YXlwb2ludCB0aGF0IG1pbmltaXplcyB0aGUgZGlzdGFuY2UgYmV0d2VlbiBpdCBhbmQgdGhlIGFnZW50J3Mgbm9kZS5cbiAgICAvLyAtIFlvdSBjYW4gdXNlIFdheXBvaW50LmRpc3RhbmNlVG9Ob2RlIGRlZmluZWQgaW4gV2F5cG9pbnQudHMuXG4gICAgLy8qfHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fCpcXFxcXG4gICAgLyoqIFRoZSBjbG9zZXN0IHdheXBvaW50IG9uIHRoZSB3YXlwb2ludCBncmFwaCBhc3NpZ25lZCB0byB0aGUgTmF2aWdhdG9yLiAqL1xuICAgIHByb3RlY3RlZCBnZXQgY2xvc2VzdFdheXBvaW50KCk6IFdheXBvaW50IHtcbiAgICAgICAgLy8jcmVnaW9uIFtZT1VSIElNUExFTUVOVEFUSU9OIEhFUkVdXG4gICAgICAgIHJldHVybiB0aGlzLndheXBvaW50R3JhcGguYWRqYWNlbmN5TGlzdFswXTtcbiAgICAgICAgLy8jZW5kcmVnaW9uXG4gICAgfVxuICAgIHByb3RlY3RlZCBhYnN0cmFjdCBnZXQgbmV4dFdheXBvaW50KCk6IFdheXBvaW50O1xuICAgIC8qKiBBIHVuaXQgMkQgdmVjdG9yIHBvaW50aW5nIGZyb20gdGhlIGFnZW50J3MgcG9zaXRpb24gXG4gICAgICogdG8gdGhlIG5leHQgd2F5cG9pbnQncyBwb3NpdGlvbiAqL1xuICAgIHByb3RlY3RlZCBnZXQgdG93YXJkc05leHRXYXlwb2ludCgpOiBjYy5WZWMye1xuICAgICAgICByZXR1cm4gdGhpcy5uZXh0V2F5cG9pbnQubm9kZS5jb252ZXJ0VG9Xb3JsZFNwYWNlQVIoY2MuVmVjMi5aRVJPKS5zdWIodGhpcy5hZ2VudC5ub2RlLmNvbnZlcnRUb1dvcmxkU3BhY2VBUihjYy5WZWMyLlpFUk8pKS5ub3JtYWxpemUoKTtcbiAgICB9XG4gICAgXG4gICAgY29uc3RydWN0b3IoX2FnZW50OiBBZ2VudCwgX3dheXBvaW50R3JhcGg6IFdheXBvaW50R3JhcGgpIHtcbiAgICAgICAgc3VwZXIoKTtcbiAgICAgICAgdGhpcy5hZ2VudCA9IF9hZ2VudDtcbiAgICAgICAgdGhpcy53YXlwb2ludEdyYXBoID0gX3dheXBvaW50R3JhcGg7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIE5hdmlnYXRvciB3aWxsIGNhbGwgdGhpcyBtZXRob2Qgd2hlbiB0aGUgYWdlbnQgaGFzIHJlYWNoZWQgdGhlIG5leHQgd2F5cG9pbnQuXG4gICAgICovXG4gICAgcHJvdGVjdGVkIGFic3RyYWN0IG9uVHJhbnNpdGlvbkZpbmlzaCgpOiB2b2lkO1xuXG4gICAgLyoqXG4gICAgICogTmF2aWdhdG9yLnRzJ3MgdXBkYXRlIG1ldGhvZCB3aWxsIGNoZWNrIGlmIHRoZSBhZ2VudCBoYXMgcmVhY2hlZCBwYXN0XG4gICAgICogdGhlIG5leHQgd2F5cG9pbnQgYW5kIGNhbGwgb25UcmFuc2l0aW9uRmluaXNoKCkgYWNjb3JkaW5nbHkuXG4gICAgICogXG4gICAgICogRXhhY3RseSBob3cgdGhlIGFnZW50IHNob3VsZCBtb3ZlIHRvIHRoZSBuZXh0IHdheXBvaW50IHNob3VsZCBiZSBcbiAgICAgKiBpbXBsZW1lbnRlZCBieSB0aGUgc3RyYXRlZ2llcyB0aGF0IGluaGVyaXQgTmF2aWdhdG9yLlxuICAgICAqIEBwYXJhbSBkdCBcbiAgICAgKi9cbiAgICBwdWJsaWMgdXBkYXRlKGR0OiBudW1iZXIpIHtcbiAgICAgICAgbGV0IGRpc3QgPSB0aGlzLm5leHRXYXlwb2ludC5kaXN0YW5jZVRvTm9kZSh0aGlzLmFnZW50Lm5vZGUpO1xuICAgICAgICBpZiAoZGlzdCA8IDEuMCkge1xuICAgICAgICAgICAgLy8gVGhpcyBpbmRpY2F0ZXMgdGhhdCB0aGUgYWdlbnQgaXMgbW92aW5nIHBhc3QgdGhlIG5leHQgd2F5cG9pbnQuXG4gICAgICAgICAgICAvLyBUaGVyZWZvcmUsIHRoZSBhZ2VudCBoYXMgcmVhY2hlZCB0aGUgd2F5cG9pbnQuXG4gICAgICAgICAgICB0aGlzLmN1cnJlbnRXYXlwb2ludCA9IHRoaXMubmV4dFdheXBvaW50O1xuICAgICAgICAgICAgdGhpcy5vblRyYW5zaXRpb25GaW5pc2goKTtcblxuICAgICAgICB9XG4gICAgfVxuXG59XG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/ai/strategies/AgentStrategy.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '3ea0em2sJxENZ80TS3fnUNO', 'AgentStrategy');
// scripts/ai/strategies/AgentStrategy.ts

Object.defineProperty(exports, "__esModule", { value: true });
exports.AI = void 0;
var AI;
(function (AI) {
    /**
     * An abstraction over AI strategies.
     * An Agent can combine several strategies to create new strategies.
     * Remember to call their start and update methods.
     *
     * This is a technique called "object composition".
     */
    var Strategy = /** @class */ (function () {
        function Strategy() {
        }
        return Strategy;
    }());
    AI.Strategy = Strategy;
})(AI = exports.AI || (exports.AI = {}));

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcYWlcXHN0cmF0ZWdpZXNcXEFnZW50U3RyYXRlZ3kudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFDQSxJQUFpQixFQUFFLENBdUJsQjtBQXZCRCxXQUFpQixFQUFFO0lBQ2Y7Ozs7OztPQU1HO0lBQ0g7UUFBQTtRQWNBLENBQUM7UUFBRCxlQUFDO0lBQUQsQ0FkQSxBQWNDLElBQUE7SUFkcUIsV0FBUSxXQWM3QixDQUFBO0FBQ0wsQ0FBQyxFQXZCZ0IsRUFBRSxHQUFGLFVBQUUsS0FBRixVQUFFLFFBdUJsQiIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEJ1dHRvblN0YXRlLCBJSW5wdXRDb250cm9scyB9IGZyb20gXCIuLi8uLi9pbnB1dC9JSW5wdXRDb250cm9sc1wiO1xuZXhwb3J0IG5hbWVzcGFjZSBBSXtcbiAgICAvKipcbiAgICAgKiBBbiBhYnN0cmFjdGlvbiBvdmVyIEFJIHN0cmF0ZWdpZXMuXG4gICAgICogQW4gQWdlbnQgY2FuIGNvbWJpbmUgc2V2ZXJhbCBzdHJhdGVnaWVzIHRvIGNyZWF0ZSBuZXcgc3RyYXRlZ2llcy5cbiAgICAgKiBSZW1lbWJlciB0byBjYWxsIHRoZWlyIHN0YXJ0IGFuZCB1cGRhdGUgbWV0aG9kcy5cbiAgICAgKiBcbiAgICAgKiBUaGlzIGlzIGEgdGVjaG5pcXVlIGNhbGxlZCBcIm9iamVjdCBjb21wb3NpdGlvblwiLlxuICAgICAqL1xuICAgIGV4cG9ydCBhYnN0cmFjdCBjbGFzcyBTdHJhdGVneSBpbXBsZW1lbnRzIElJbnB1dENvbnRyb2xze1xuICAgICAgICBwdWJsaWMgYWJzdHJhY3QgZ2V0IGhvcml6b250YWxBeGlzKCk6IG51bWJlcjtcbiAgICAgICAgcHVibGljIGFic3RyYWN0IGdldCB2ZXJ0aWNhbEF4aXMoKTogbnVtYmVyO1xuICAgICAgICBwdWJsaWMgYWJzdHJhY3QgZ2V0IGF0dGFjaygpOiBCdXR0b25TdGF0ZTtcbiAgICAgICAgcHVibGljIGFic3RyYWN0IGdldCBpbnRlcmFjdCgpOiBCdXR0b25TdGF0ZTtcbiAgICAgICAgLyoqXG4gICAgICAgICAqIEltcGxlbWVudHMgaW5pdGlhbGl6YXRpb24gb2YgdGhlIHN0cmF0ZWd5LlxuICAgICAgICAgKi9cbiAgICAgICAgcHVibGljIGFic3RyYWN0IHN0YXJ0KCk6IHZvaWQ7XG4gICAgICAgIC8qKlxuICAgICAgICAgKiBJbXBsZW1lbnRzIHVwZGF0aW5nIG9mIHRoZSBzdHJhdGVneS5cbiAgICAgICAgICogQHBhcmFtIGR0IFRpbWUgZWxhcHNlZCBzaW5jZSBsYXN0IHVwZGF0ZS5cbiAgICAgICAgICovXG4gICAgICAgIHB1YmxpYyBhYnN0cmFjdCB1cGRhdGUoZHQ6IG51bWJlcik6dm9pZDtcbiAgICB9XG59XG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/utilities/ZSortOnLoad.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '1855dXZEzdGf7iIoaoAeRs6', 'ZSortOnLoad');
// scripts/utilities/ZSortOnLoad.ts

// Learn TypeScript:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/typescript.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/life-cycle-callbacks.html
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
/**
 * A component that makes every node below the node it is attached to render in a way
 * such that it appears behind nodes that are located below it.
 */
var ZSortOnLoad = /** @class */ (function (_super) {
    __extends(ZSortOnLoad, _super);
    function ZSortOnLoad() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    // LIFE-CYCLE CALLBACKS:
    ZSortOnLoad.prototype.onLoad = function () {
        for (var _i = 0, _a = this.node.children; _i < _a.length; _i++) {
            var node = _a[_i];
            node.zIndex = 10000 + -node.y;
        }
    };
    ZSortOnLoad = __decorate([
        ccclass
    ], ZSortOnLoad);
    return ZSortOnLoad;
}(cc.Component));
exports.default = ZSortOnLoad;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcdXRpbGl0aWVzXFxaU29ydE9uTG9hZC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7QUFBQSxvQkFBb0I7QUFDcEIsa0ZBQWtGO0FBQ2xGLHlGQUF5RjtBQUN6RixtQkFBbUI7QUFDbkIsNEZBQTRGO0FBQzVGLG1HQUFtRztBQUNuRyw4QkFBOEI7QUFDOUIsNEZBQTRGO0FBQzVGLG1HQUFtRzs7QUFFN0YsSUFBQSxLQUFzQixFQUFFLENBQUMsVUFBVSxFQUFsQyxPQUFPLGFBQUEsRUFBRSxRQUFRLGNBQWlCLENBQUM7QUFFMUM7OztHQUdHO0FBRUg7SUFBeUMsK0JBQVk7SUFBckQ7O0lBZUEsQ0FBQztJQWJHLHdCQUF3QjtJQUV4Qiw0QkFBTSxHQUFOO1FBQ0ksS0FBaUIsVUFBa0IsRUFBbEIsS0FBQSxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBbEIsY0FBa0IsRUFBbEIsSUFBa0IsRUFBRTtZQUFoQyxJQUFJLElBQUksU0FBQTtZQUNULElBQUksQ0FBQyxNQUFNLEdBQUcsS0FBSyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztTQUNqQztJQUNMLENBQUM7SUFSZ0IsV0FBVztRQUQvQixPQUFPO09BQ2EsV0FBVyxDQWUvQjtJQUFELGtCQUFDO0NBZkQsQUFlQyxDQWZ3QyxFQUFFLENBQUMsU0FBUyxHQWVwRDtrQkFmb0IsV0FBVyIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8vIExlYXJuIFR5cGVTY3JpcHQ6XG4vLyAgLSBbQ2hpbmVzZV0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC96aC9zY3JpcHRpbmcvdHlwZXNjcmlwdC5odG1sXG4vLyAgLSBbRW5nbGlzaF0gaHR0cDovL3d3dy5jb2NvczJkLXgub3JnL2RvY3MvY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3R5cGVzY3JpcHQuaHRtbFxuLy8gTGVhcm4gQXR0cmlidXRlOlxuLy8gIC0gW0NoaW5lc2VdIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvemgvc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcbi8vICAtIFtFbmdsaXNoXSBodHRwOi8vd3d3LmNvY29zMmQteC5vcmcvZG9jcy9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvcmVmZXJlbmNlL2F0dHJpYnV0ZXMuaHRtbFxuLy8gTGVhcm4gbGlmZS1jeWNsZSBjYWxsYmFja3M6XG4vLyAgLSBbQ2hpbmVzZV0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC96aC9zY3JpcHRpbmcvbGlmZS1jeWNsZS1jYWxsYmFja3MuaHRtbFxuLy8gIC0gW0VuZ2xpc2hdIGh0dHA6Ly93d3cuY29jb3MyZC14Lm9yZy9kb2NzL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9saWZlLWN5Y2xlLWNhbGxiYWNrcy5odG1sXG5cbmNvbnN0IHtjY2NsYXNzLCBwcm9wZXJ0eX0gPSBjYy5fZGVjb3JhdG9yO1xuXG4vKipcbiAqIEEgY29tcG9uZW50IHRoYXQgbWFrZXMgZXZlcnkgbm9kZSBiZWxvdyB0aGUgbm9kZSBpdCBpcyBhdHRhY2hlZCB0byByZW5kZXIgaW4gYSB3YXkgXG4gKiBzdWNoIHRoYXQgaXQgYXBwZWFycyBiZWhpbmQgbm9kZXMgdGhhdCBhcmUgbG9jYXRlZCBiZWxvdyBpdC5cbiAqL1xuQGNjY2xhc3NcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIFpTb3J0T25Mb2FkIGV4dGVuZHMgY2MuQ29tcG9uZW50IHtcblxuICAgIC8vIExJRkUtQ1lDTEUgQ0FMTEJBQ0tTOlxuXG4gICAgb25Mb2FkICgpIHtcbiAgICAgICAgZm9yIChsZXQgbm9kZSBvZiB0aGlzLm5vZGUuY2hpbGRyZW4pIHtcbiAgICAgICAgICAgIG5vZGUuekluZGV4ID0gMTAwMDAgKyAtbm9kZS55O1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLy8gc3RhcnQgKCkge1xuXG4gICAgLy8gfVxuXG4gICAgLy8gdXBkYXRlIChkdCkge31cbn1cbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/ai/strategies/NavWanderer.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '4bd90WqNlVPXYN8fxhe7dk4', 'NavWanderer');
// scripts/ai/strategies/NavWanderer.ts

Object.defineProperty(exports, "__esModule", { value: true });
exports.NavWanderer = void 0;
var Navigator_1 = require("./Navigator");
/**
 * An AI strategy that describes a random-walk behaviour on a waypoint graph.
 */
var NavWanderer = /** @class */ (function (_super) {
    __extends(NavWanderer, _super);
    function NavWanderer() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        /** The agent's output to IInput. */
        _this._moveAxis2D = cc.Vec2.ZERO;
        // constructor(_agent: Agent, _waypointGraph: WaypointGraph) {
        //     super(_agent, _waypointGraph);
        // }
        _this._nextWaypoint = null;
        return _this;
    }
    Object.defineProperty(NavWanderer.prototype, "nextWaypoint", {
        get: function () {
            return this._nextWaypoint;
        },
        enumerable: false,
        configurable: true
    });
    NavWanderer.prototype.onTransitionFinish = function () {
        this._nextWaypoint = this.currentWaypoint.adjacentWaypoints[Math.floor(Math.random() * this.currentWaypoint.adjacentWaypoints.length)];
    };
    Object.defineProperty(NavWanderer.prototype, "horizontalAxis", {
        get: function () {
            return this._moveAxis2D.x;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(NavWanderer.prototype, "verticalAxis", {
        get: function () {
            return this._moveAxis2D.y;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(NavWanderer.prototype, "attack", {
        get: function () {
            throw new Error("Method not implemented.");
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(NavWanderer.prototype, "interact", {
        get: function () {
            throw new Error("Method not implemented.");
        },
        enumerable: false,
        configurable: true
    });
    NavWanderer.prototype.start = function () {
        this._nextWaypoint = this.closestWaypoint;
    };
    //*||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||*\\
    // TODO (3.2): Implement NavWanderer.update().
    // [SPECIFICATIONS]
    // - Trace Navigator.ts to figure out what you can use to make NavWanderer
    //   move towards the next waypoint AND call onTransitionFinish() after
    //   arriving.
    // - Hint: Two lines of code!
    //*||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||*\\
    NavWanderer.prototype.update = function (dt) {
        //#region [YOUR IMPLEMENTATION HERE]
        //#endregion
    };
    return NavWanderer;
}(Navigator_1.Navigator));
exports.NavWanderer = NavWanderer;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcYWlcXHN0cmF0ZWdpZXNcXE5hdldhbmRlcmVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBSUEseUNBQXdDO0FBQ3hDOztHQUVHO0FBQ0g7SUFBaUMsK0JBQVM7SUFBMUM7UUFBQSxxRUE0Q0M7UUEzQ0csb0NBQW9DO1FBQzVCLGlCQUFXLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7UUFDbkMsOERBQThEO1FBQzlELHFDQUFxQztRQUNyQyxJQUFJO1FBRUksbUJBQWEsR0FBYSxJQUFJLENBQUM7O0lBcUMzQyxDQUFDO0lBcENHLHNCQUFjLHFDQUFZO2FBQTFCO1lBQ0ksT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDO1FBQzlCLENBQUM7OztPQUFBO0lBQ1Msd0NBQWtCLEdBQTVCO1FBQ0ksSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUMsZUFBZSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUMsaUJBQWlCLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQTtJQUMxSSxDQUFDO0lBQ0Qsc0JBQVcsdUNBQWM7YUFBekI7WUFDSSxPQUFPLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDO1FBQzlCLENBQUM7OztPQUFBO0lBQ0Qsc0JBQVcscUNBQVk7YUFBdkI7WUFDSSxPQUFPLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDO1FBQzlCLENBQUM7OztPQUFBO0lBQ0Qsc0JBQVcsK0JBQU07YUFBakI7WUFDSSxNQUFNLElBQUksS0FBSyxDQUFDLHlCQUF5QixDQUFDLENBQUM7UUFDL0MsQ0FBQzs7O09BQUE7SUFDRCxzQkFBVyxpQ0FBUTthQUFuQjtZQUNJLE1BQU0sSUFBSSxLQUFLLENBQUMseUJBQXlCLENBQUMsQ0FBQztRQUMvQyxDQUFDOzs7T0FBQTtJQUNNLDJCQUFLLEdBQVo7UUFDSSxJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUM7SUFDOUMsQ0FBQztJQUVELDRFQUE0RTtJQUM1RSw4Q0FBOEM7SUFDOUMsbUJBQW1CO0lBQ25CLDBFQUEwRTtJQUMxRSx1RUFBdUU7SUFDdkUsY0FBYztJQUNkLDZCQUE2QjtJQUM3Qiw0RUFBNEU7SUFDckUsNEJBQU0sR0FBYixVQUFjLEVBQVU7UUFDcEIsb0NBQW9DO1FBRXBDLFlBQVk7SUFDaEIsQ0FBQztJQUVMLGtCQUFDO0FBQUQsQ0E1Q0EsQUE0Q0MsQ0E1Q2dDLHFCQUFTLEdBNEN6QztBQTVDWSxrQ0FBVyIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEJ1dHRvblN0YXRlIH0gZnJvbSBcIi4uLy4uL2lucHV0L0lJbnB1dENvbnRyb2xzXCI7XG5pbXBvcnQgQWdlbnQgZnJvbSBcIi4uL0FnZW50XCI7XG5pbXBvcnQgV2F5cG9pbnQgZnJvbSBcIi4uL25hdmlnYXRpb24vV2F5cG9pbnRcIjtcbmltcG9ydCBXYXlwb2ludEdyYXBoIGZyb20gXCIuLi9uYXZpZ2F0aW9uL1dheXBvaW50R3JhcGhcIjtcbmltcG9ydCB7IE5hdmlnYXRvciB9IGZyb20gXCIuL05hdmlnYXRvclwiO1xuLyoqXG4gKiBBbiBBSSBzdHJhdGVneSB0aGF0IGRlc2NyaWJlcyBhIHJhbmRvbS13YWxrIGJlaGF2aW91ciBvbiBhIHdheXBvaW50IGdyYXBoLlxuICovXG5leHBvcnQgY2xhc3MgTmF2V2FuZGVyZXIgZXh0ZW5kcyBOYXZpZ2F0b3J7XG4gICAgLyoqIFRoZSBhZ2VudCdzIG91dHB1dCB0byBJSW5wdXQuICovXG4gICAgcHJpdmF0ZSBfbW92ZUF4aXMyRCA9IGNjLlZlYzIuWkVSTztcbiAgICAvLyBjb25zdHJ1Y3RvcihfYWdlbnQ6IEFnZW50LCBfd2F5cG9pbnRHcmFwaDogV2F5cG9pbnRHcmFwaCkge1xuICAgIC8vICAgICBzdXBlcihfYWdlbnQsIF93YXlwb2ludEdyYXBoKTtcbiAgICAvLyB9XG4gICAgXG4gICAgcHJpdmF0ZSBfbmV4dFdheXBvaW50OiBXYXlwb2ludCA9IG51bGw7XG4gICAgcHJvdGVjdGVkIGdldCBuZXh0V2F5cG9pbnQoKTogV2F5cG9pbnQge1xuICAgICAgICByZXR1cm4gdGhpcy5fbmV4dFdheXBvaW50O1xuICAgIH1cbiAgICBwcm90ZWN0ZWQgb25UcmFuc2l0aW9uRmluaXNoKCk6IHZvaWQge1xuICAgICAgICB0aGlzLl9uZXh0V2F5cG9pbnQgPSB0aGlzLmN1cnJlbnRXYXlwb2ludC5hZGphY2VudFdheXBvaW50c1tNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiB0aGlzLmN1cnJlbnRXYXlwb2ludC5hZGphY2VudFdheXBvaW50cy5sZW5ndGgpXVxuICAgIH1cbiAgICBwdWJsaWMgZ2V0IGhvcml6b250YWxBeGlzKCk6IG51bWJlciB7XG4gICAgICAgIHJldHVybiB0aGlzLl9tb3ZlQXhpczJELng7XG4gICAgfVxuICAgIHB1YmxpYyBnZXQgdmVydGljYWxBeGlzKCk6IG51bWJlciB7XG4gICAgICAgIHJldHVybiB0aGlzLl9tb3ZlQXhpczJELnk7XG4gICAgfVxuICAgIHB1YmxpYyBnZXQgYXR0YWNrKCk6IEJ1dHRvblN0YXRlIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiTWV0aG9kIG5vdCBpbXBsZW1lbnRlZC5cIik7XG4gICAgfVxuICAgIHB1YmxpYyBnZXQgaW50ZXJhY3QoKTogQnV0dG9uU3RhdGUge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJNZXRob2Qgbm90IGltcGxlbWVudGVkLlwiKTtcbiAgICB9XG4gICAgcHVibGljIHN0YXJ0KCk6IHZvaWQge1xuICAgICAgICB0aGlzLl9uZXh0V2F5cG9pbnQgPSB0aGlzLmNsb3Nlc3RXYXlwb2ludDtcbiAgICB9XG5cbiAgICAvLyp8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8KlxcXFxcbiAgICAvLyBUT0RPICgzLjIpOiBJbXBsZW1lbnQgTmF2V2FuZGVyZXIudXBkYXRlKCkuXG4gICAgLy8gW1NQRUNJRklDQVRJT05TXVxuICAgIC8vIC0gVHJhY2UgTmF2aWdhdG9yLnRzIHRvIGZpZ3VyZSBvdXQgd2hhdCB5b3UgY2FuIHVzZSB0byBtYWtlIE5hdldhbmRlcmVyXG4gICAgLy8gICBtb3ZlIHRvd2FyZHMgdGhlIG5leHQgd2F5cG9pbnQgQU5EIGNhbGwgb25UcmFuc2l0aW9uRmluaXNoKCkgYWZ0ZXJcbiAgICAvLyAgIGFycml2aW5nLlxuICAgIC8vIC0gSGludDogVHdvIGxpbmVzIG9mIGNvZGUhXG4gICAgLy8qfHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fCpcXFxcXG4gICAgcHVibGljIHVwZGF0ZShkdDogbnVtYmVyKTogdm9pZCB7XG4gICAgICAgIC8vI3JlZ2lvbiBbWU9VUiBJTVBMRU1FTlRBVElPTiBIRVJFXVxuICAgICAgICBcbiAgICAgICAgLy8jZW5kcmVnaW9uXG4gICAgfVxuXG59Il19
//------QC-SOURCE-SPLIT------
