"use strict";
cc._RF.push(module, '8b71eeKSnpJcaE9WtnE0IOv', 'NavChaser');
// scripts/ai/strategies/NavChaser.ts

// Learn TypeScript:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/typescript.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/life-cycle-callbacks.html
Object.defineProperty(exports, "__esModule", { value: true });
exports.NavChaser = void 0;
var Navigator_1 = require("./Navigator");
/**
 * An AI strategy that describes a behaviour in which the agent tries to move to the
 * waypoint on the waypoint graph closest to the target.
 *
 * It will not stray away from the graph beyond a distance equal to the shortest edge
 * on the graph's length.
 */
var NavChaser = /** @class */ (function (_super) {
    __extends(NavChaser, _super);
    function NavChaser(agent, waypointGraph, runTowards) {
        var _this = _super.call(this, agent, waypointGraph) || this;
        /** The agent's output to IInput. */
        _this._moveAxis2D = cc.Vec2.ZERO;
        _this._minGraphEdgeLength = Infinity;
        _this._runTowards = null;
        _this._nextWaypoint = null;
        _this._runTowards = runTowards;
        return _this;
    }
    Object.defineProperty(NavChaser.prototype, "nextWaypoint", {
        get: function () {
            return this._nextWaypoint;
        },
        enumerable: false,
        configurable: true
    });
    NavChaser.prototype.onTransitionFinish = function () {
        //*||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||*\\
        // TODO (4.2): Complete NavChaser's onTransitionFinish method.
        // [SPECIFICATIONS]
        // - NavChaser should move towards the waypoint on the waypoint graph 
        //   closest to this._runTowards.
        // - Assign your results to this._nextWaypoint.
        //*||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||*\\
        //#region [YOUR IMPLEMENTATION HERE]
        //#endregion
        // console.log(`NavChaser: Current: ${this.currentWaypoint.node.name}, Next: ${this.nextWaypoint.node.name}`);
    };
    Object.defineProperty(NavChaser.prototype, "horizontalAxis", {
        get: function () {
            return this._moveAxis2D.x;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(NavChaser.prototype, "verticalAxis", {
        get: function () {
            return this._moveAxis2D.y;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(NavChaser.prototype, "attack", {
        get: function () {
            throw new Error("Method not implemented.");
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(NavChaser.prototype, "interact", {
        get: function () {
            throw new Error("Method not implemented.");
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(NavChaser.prototype, "towardsTarget", {
        get: function () {
            return this._runTowards.position.sub(this.agent.node.position).normalize();
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(NavChaser.prototype, "distanceFromTarget", {
        get: function () {
            return this._runTowards.position.sub(this.agent.node.position).mag();
        },
        enumerable: false,
        configurable: true
    });
    NavChaser.prototype.start = function () {
        this._nextWaypoint = this.closestWaypoint;
        for (var _i = 0, _a = this.waypointGraph.adjacencyList; _i < _a.length; _i++) {
            var waypoint = _a[_i];
            for (var _b = 0, _c = waypoint.distances; _b < _c.length; _b++) {
                var dist = _c[_b];
                this._minGraphEdgeLength = Math.min(this._minGraphEdgeLength, dist);
            }
        }
    };
    NavChaser.prototype.update = function (dt) {
        if (this.distanceFromTarget < this._minGraphEdgeLength
            && this.currentWaypoint && this.currentWaypoint.distanceToNode(this.agent.node) < this._minGraphEdgeLength) {
            this._moveAxis2D = this.towardsTarget;
        }
        else {
            _super.prototype.update.call(this, dt);
            if (this.currentWaypoint === this.nextWaypoint) {
                this._moveAxis2D = cc.Vec2.ZERO;
                this.onTransitionFinish();
            }
            else
                this._moveAxis2D = this.towardsNextWaypoint;
        }
    };
    return NavChaser;
}(Navigator_1.Navigator));
exports.NavChaser = NavChaser;

cc._RF.pop();