"use strict";
cc._RF.push(module, '7aebaBbk2VOq7Q1SbCYHVIr', 'NavChaseAgent');
// scripts/ai/NavChaseAgent.ts

// Learn TypeScript:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/typescript.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/life-cycle-callbacks.html
Object.defineProperty(exports, "__esModule", { value: true });
var IInputControls_1 = require("../input/IInputControls");
var Agent_1 = require("./Agent");
var WaypointGraph_1 = require("./navigation/WaypointGraph");
var NavChaser_1 = require("./strategies/NavChaser");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var NavChaseAgent = /** @class */ (function (_super) {
    __extends(NavChaseAgent, _super);
    function NavChaseAgent() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.attack = IInputControls_1.ButtonState.Rest;
        _this.interact = IInputControls_1.ButtonState.Rest;
        _this.waypointGraph = null;
        _this.runTowards = null;
        _this._navChaser = null;
        return _this;
        // update (dt) {}
    }
    Object.defineProperty(NavChaseAgent.prototype, "horizontalAxis", {
        get: function () {
            if (!this._navChaser)
                return 0;
            return this._navChaser.horizontalAxis;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(NavChaseAgent.prototype, "verticalAxis", {
        get: function () {
            if (!this._navChaser)
                return 0;
            return this._navChaser.verticalAxis;
        },
        enumerable: false,
        configurable: true
    });
    NavChaseAgent.prototype.agentUpdate = function (dt) {
        this._navChaser.update(dt);
    };
    // LIFE-CYCLE CALLBACKS:
    NavChaseAgent.prototype.onLoad = function () {
        this._navChaser = new NavChaser_1.NavChaser(this, this.waypointGraph, this.runTowards);
    };
    NavChaseAgent.prototype.start = function () {
        this._navChaser.start();
    };
    __decorate([
        property(WaypointGraph_1.default)
    ], NavChaseAgent.prototype, "waypointGraph", void 0);
    __decorate([
        property(cc.Node)
    ], NavChaseAgent.prototype, "runTowards", void 0);
    NavChaseAgent = __decorate([
        ccclass
    ], NavChaseAgent);
    return NavChaseAgent;
}(Agent_1.default));
exports.default = NavChaseAgent;

cc._RF.pop();